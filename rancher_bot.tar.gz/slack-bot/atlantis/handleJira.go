package atlantis

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"strings"

	"github.com/andygrunwald/go-jira"
	"github.com/joho/godotenv"
)

func getIssue(jiraURL string) (*jira.Issue, *jira.Client, error) {
	//load file
	godotenv.Load(".env")
	var issue *jira.Issue
	JIRA_URL := os.Getenv("JIRA_URL")
	JIRA_ACC := os.Getenv("JIRA_ACC")
	JIRA_PWD := os.Getenv("JIRA_PWD")
	JIRA_PROJECT := os.Getenv("JIRA_PROJECT")
	tp := jira.BasicAuthTransport{
		Username: JIRA_ACC,
		Password: JIRA_PWD,
	}

	client, err := jira.NewClient(tp.Client(), JIRA_URL)

	if err != nil {
		return issue, nil, err
	}

	// JIRA_PROJECT = "DEVOPSSUP"
	project, _, err := client.Project.Get(JIRA_PROJECT)

	if err != nil {
		return issue, client, err
	}
	log.Println(project.ID)

	if jiraURL == "" {
		return issue, client, errors.New("cannot get jira url")
	}
	ID := strings.Split(jiraURL, "issue/")[1]
	issue, _, _ = client.Issue.Get(ID, nil)

	return issue, client, nil
}

func UpdateJiraTicket(approver, jiraURL string) error {

	issue, client, err := getIssue(jiraURL)

	if err != nil {
		return err
	}

	currentStatus := issue.Fields.Description
	fmt.Printf("Current status: %s\n", currentStatus)
	comment := jira.Comment{
		Author: jira.User{
			Name: approver,
		},
		Body: approver + " has approved the ticket",
	}
	_, _, err = client.Issue.AddComment(issue.ID, &comment)

	if err != nil {
		return err
	}
	return nil
}

func CloseJiraTicket(jiraURL string) error {

	issue, client, err := getIssue(jiraURL)

	if err != nil {
		return err
	}
	currentStatus := issue.Fields.Status.Name
	fmt.Printf("Current status: %s\n", currentStatus)

	var transitionID string
	ID := strings.Split(jiraURL, "issue/")[1]
	possibleTransitions, _, _ := client.Issue.GetTransitions(ID)

	log.Println("Possible ", possibleTransitions)
	for _, v := range possibleTransitions {
		//log.Println(v.Name)
		if v.Name == "Đã giải quyết" {
			transitionID = v.ID
			break
		}
	}

	//return nil if transition id is completed because of some one approve ticket
	if transitionID == "" {
		return nil
	}

	_, err = client.Issue.DoTransition(ID, transitionID)

	if err != nil {
		return err
	}
	return nil
}

func CreateTicketManageWL(managerUser, input, userRequest, desc string) (string, error) {

	inputSplit := strings.Split(input, " ")

	cluster := inputSplit[0]

	project := inputSplit[1]

	timeManage := inputSplit[3]

	summaryDescription := "Cấp quyền manage cluster " + cluster + " project " + project + " cho user " + userRequest

	description := "Cấp quyền manage cluster " + cluster + " project " + project + " cho user " + userRequest + " trong vòng " + timeManage + " giờ\n Manager: " + managerUser +
		"\nMục đích: " + strings.ReplaceAll(desc, "-", " ")
	jiraURL, err := createJiraTicket(description, summaryDescription, userRequest)

	if err != nil {
		return jiraURL, err
	}

	return jiraURL, nil
}

func createJiraTicket(description, summaryDes, userName string) (string, error) {
	var jiraTicketURL string
	//load file
	godotenv.Load(".env")

	JIRA_URL := os.Getenv("JIRA_URL")
	JIRA_ACC := os.Getenv("JIRA_ACC")
	JIRA_PWD := os.Getenv("JIRA_PWD")
	JIRA_PROJECT := os.Getenv("JIRA_PROJECT")

	tp := jira.BasicAuthTransport{
		Username: JIRA_ACC,
		Password: JIRA_PWD,
	}

	client, err := jira.NewClient(tp.Client(), JIRA_URL)

	if err != nil {
		return jiraTicketURL, err
	}
	// JIRA_PROJECT = "DEVOPSSUP"
	project, _, err := client.Project.Get(JIRA_PROJECT)

	if err != nil {
		return "", err
	}
	log.Println(project.ID)

	new_issue_dict := jira.Issue{

		Fields: &jira.IssueFields{
			Assignee: &jira.User{
				Name: "hiep.nguyenngoc",
			},
			Description: description,
			Type: jira.IssueType{
				Name: "Support",
				// Name: "Problem",
			},
			Project: jira.Project{
				ID: project.ID,
			},
			Summary:    summaryDes,
			Components: []*jira.Component{&jira.Component{Name: "Service"}},
			Reporter: &jira.User{
				Name: userName,
			},
		},
	}
	issues, _, err := client.Issue.Create(&new_issue_dict)

	// if err != nil {
	// 	log.Println(err)
	// 	return jiraTicketURL, err
	// }

	// kq, err := ioutil.ReadAll(body.Body)
	// bodyString := string(kq)
	// log.Println("Body", bodyString)

	// log.Printf("%+v", issues)

	jiraTicketURL = JIRA_URL + "/projects/" + JIRA_PROJECT + "/issue/" + issues.Key

	return jiraTicketURL, nil
}

func CreateTicket(commandType, deployment, userName, serectName, vaultDataInput string) (string, error) {
	var jiraTicketURL string

	if serectName == "" {
		serectName = "env-" + deployment
	}

	vaultKeys, err := common.GetKeyFromKeyValue(vaultDataInput)

	if err != nil {
		return jiraTicketURL, err
	}

	desciptionKey := ""
	summaryDes := ""
	if commandType == "update vault" {
		desciptionKey = "\nKey need to update:\n"
		summaryDes = "Update vault for deployment " + deployment
	} else if commandType == "create vault" {
		desciptionKey = "\nKey need to create:\n"
		summaryDes = "Create vault for deployment " + deployment
	}

	description := "User create request: " + userName + "\n" + commandType + " for deployment *" + deployment + "*, secretName: " + serectName + desciptionKey + vaultKeys

	jiraTicketURL, err = createJiraTicket(description, summaryDes, userName)

	if err != nil {
		return jiraTicketURL, err
	}

	return jiraTicketURL, nil
}
