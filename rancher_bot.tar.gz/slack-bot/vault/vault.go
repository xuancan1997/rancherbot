package vault

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path"
	"strings"
	"time"

	vault "github.com/hashicorp/vault/api"
	"github.com/joho/godotenv"
)

const (
	TOKENS_PATH          = "devops-tokens"
	KUBECONFIGS_PATH     = "devops-kubeconfigs"
	ALL_KUBECONFIGS_PATH = "all-kubeconfigs"
)

type User string
type Token struct {
	User  User   `json:"user"`
	Name  string `json:"name"`
	Token string `json:"token,omitempty"`
}

type VaultReponse struct {
	RequestID     string `json:"request_id"`
	LeaseID       string `json:"lease_id"`
	Renewable     bool   `json:"renewable"`
	LeaseDuration int    `json:"lease_duration"`
	Data          struct {
		Data struct {
		} `json:"data"`
		// Metadata struct {
		// 	CreatedTime    time.Time   `json:"created_time"`
		// 	CustomMetadata interface{} `json:"custom_metadata"`
		// 	DeletionTime   string      `json:"deletion_time"`
		// 	Destroyed      bool        `json:"destroyed"`
		// 	Version        int         `json:"version"`
		// } `json:"metadata"`
	} `json:"data"`
	WrapInfo interface{} `json:"wrap_info"`
	Warnings interface{} `json:"warnings"`
	Auth     interface{} `json:"auth"`
}

type Data struct {
	ID                string `json:"id"`
	Name              string `json:"name"`
	State             string `json:"state"`
	ProjectID         string `json:"projectId"`
	CurrentReplicas   int    `json:"currentReplicas"`
	DesiredReplicas   int    `json:"desiredReplicas"`
	MaxReplicas       int    `json:"maxReplicas"`
	MinReplicas       int    `json:"minReplicas"`
	NamespaceId       string `json:"namespaceId"`
	NormalMinReplicas int    `json:"normalMinReplicas"`
	NormalMaxReplicas int    `json:"normalMaxReplicas"`
	EventMinReplicas  int    `json:"eventMinReplicas"`
	EventMaxReplicas  int    `json:"eventMaxReplicas"`
	Enabled           string `json:"IsEnabled"`
	WorkloadID        string `json:"workloadId"`
	IsHpa             bool
	ClusterName       string
	TempMinReplicas   int
	TempMaxReplicas   int
	ProjectName       string
	Position          int
	Replicas          int
	ReplicaData       string
	CurrentRepData    string
}

func WriteTokenToVault(kvc *vault.KVv2, t Token) error {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*time.Duration(5))
	defer cancel()

	TOKENS_PATH := "devops-tokens"
	writePath := fmt.Sprintf("%s/%s", TOKENS_PATH, t.User)
	data := map[string]interface{}{
		"token":       fmt.Sprintf("%s:%s", t.Name, t.Token),
		"tokenName":   t.Name,
		"tokenSecret": t.Token,
	}
	// TODO: validate write status
	kvc.Put(ctx, writePath, data)
	return nil
}

func initVaultHttpReq(method, token, querryCmd, readerInput string) (*http.Response, error) {
	var httpResp *http.Response
	godotenv.Load(".env")

	apiUrl := os.Getenv("AUTH_VAULT_ADDR")
	querryCmd = strings.ReplaceAll(querryCmd, " ", "")
	querryCommmand := apiUrl + querryCmd

	log.Println("QuerryCommmand", querryCmd)

	client := &http.Client{Timeout: 10 * time.Second}

	reader := strings.NewReader(readerInput)

	request, err := http.NewRequest(method, querryCommmand, reader)

	if err != nil {
		return httpResp, errors.New("could not run request to vault")
	}

	request.Header.Add("Content-Type", "application/json; charset=UTF-8")
	request.Header.Add("Accept", "application/json")
	request.Header.Add("X-Vault-Token", token)

	//log.Println("request send ", request)
	httpResp, err = client.Do(request)

	if err != nil {
		fmt.Println(err.Error())
		return httpResp, errors.New("could not run request to vault, please check connection")
	}

	return httpResp, nil
}

func ClientTokenLogin(addr string) (*vault.Client, error) {
	c := vault.Config{Address: addr}
	c.ReadEnvironment()
	return vault.NewClient(&c)
}

func ClientK8sLogin(vaultAddr, loginPath, role string) (v *vault.Client, err error) {
	var (
		httpClient = &http.Client{
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
			},
		}
		config = &vault.Config{
			Address:    vaultAddr,
			HttpClient: httpClient,
		}
	)

	client, err := vault.NewClient(config)
	if err != nil {
		return nil, err
	}

	jwt, err := os.ReadFile("/var/run/secrets/kubernetes.io/serviceaccount/token")
	if err != nil {
		return nil, err
	}

	body := map[string]string{
		"role": role,
		"jwt":  string(jwt),
	}

	login := path.Clean("/v1/auth/" + loginPath + "/login")
	req := client.NewRequest("POST", login)
	req.SetJSONBody(body)

	resp, err := client.RawRequest(req)
	if err != nil {
		return nil, err
	}

	if respErr := resp.Error(); respErr != nil {
		return nil, respErr
	}

	var result vault.Secret
	if err := resp.DecodeJSON(&result); err != nil {
		return nil, err
	}

	client.SetToken(result.Auth.ClientToken)
	return client, nil

}
