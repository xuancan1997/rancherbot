package rancher

type EventRemindStruct struct {
	Author    string
	LineError string
	Data      []Data
}

type ManageWLProfile struct {
	Cluster        string
	ProjectName    string
	Manager        string
	Hour           string
	UserRequest    string
	DeploymentName string
	UserNameGit    string
}

type CmdStruct struct {
	Command string
	Value   string
}

type MapEventData struct {
	Author    string
	LineError string
	Data      []Data
}

type RancherProjects struct {
	Data []struct {
		ID          string `json:"id"`
		Name        string `json:"name"`
		State       string `json:"state"`
		ClusterID   string `json:"clusterId"`
		ClusterName string
	} `json:"data"`
}

type RancherProject struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	ClusterID   string `json:"clusterId"`
	ClusterName string
}

type RancherClusters struct {
	Data []struct {
		ID    string `json:"id"`
		Name  string `json:"name"`
		State string `json:"state"`
	} `json:"data"`
}

//use when rancher2.6
type ContainerData struct {
	Name string `json:"name"`
	ENV  []struct {
		Name  string `json:"name"`
		Value string `json:"value"`
	} `json:"env"`
	ENVFROM []struct {
		SECRETREF struct {
			Name string `json:"name"`
		} `json:"secretRef"`
	} `json:"envFrom"`
}

//use when rancher2.5
// type ContainerData struct {
// 	Name string `json:"name"`
// 	ENV  struct {
// 	} `json:"environment"`
// 	ENVFROM []struct {
// 		Source     string `json:"source"`
// 		SourceName string `json:"sourceName"`
// 	} `json:"environmentFrom"`
// 	Image string `json:"image"`
// }
type DeploymentContainers struct {
	Container []ContainerData `json:"containers"`
}

//resivion data
type RevisionData struct {
	Name       string               `json:"name"`
	Created    string               `json:"created"`
	Id         string               `json:"id"`
	Containers DeploymentContainers `json:"containers"`
}
type RevisionContainers struct {
	Type         string `json:"type"`
	RevisionData []struct {
		Name       string          `json:"name"`
		Created    string          `json:"created"`
		Id         string          `json:"id"`
		Containers []ContainerData `json:"containers"`
		Actions    RedeployAction  `json:"actions"`
	} `json:"data"`
}

type RedeployAction struct {
	Redeploy string `json::"redeploy"`
}

//use as rancher 2.6
type DeploymentContainer struct {
	Container struct {
		Name string `json:"name"`
		ENV  []struct {
			Name  string `json:"name"`
			Value string `json:"value"`
		} `json:"env"`
		ENVFROM []struct {
			SECRETREF struct {
				Name string `json:"name"`
			} `json:"secretRef"`
		} `json:"envFrom"`
	} `json:"containers"`
}

//use as rancher 2.5
// type DeploymentContainer struct {
// 	Container struct {
// 		Name string `json:"name"`
// 		ENV  struct {
// 		} `json:"environment"`
// 		ENVFROM []struct {
// 			Source     string `json:"source"`
// 			SourceName string `json:"sourceName"`
// 		} `json:"environmentFrom"`
// 	} `json:"containers"`
// }

type Deployment struct {
	ID               string `json:"id"`
	Name             string `json:"name"`
	State            string `json:"state"`
	ProjectID        string `json:"projectId"`
	Scale            int    `json:"scale"`
	DesiredReplicas  int    `json:"desiredReplicas"`
	NamespaceId      string `json:"namespaceId"`
	ClusterName      string
	ProjectName      string
	EnableForBot     string
	NormalReplicas   int
	EventReplicas    int
	Position         int
	Type             string
	DeploymentStatus struct {
		AvailableReplicas int `json: "availableReplicas"`
		ReadyReplicas     int `json: "readyReplicas"`
		Replicas          int `json: "replicas"`
	} `json: "deploymentStatus"`

	StatefulSetStatus struct {
		AvailableReplicas  int    `json:"availableReplicas"`
		CollisionCount     int    `json:"collisionCount"`
		CurrentReplicas    int    `json:"currentReplicas"`
		CurrentRevision    string `json:"currentRevision"`
		ObservedGeneration int    `json:"observedGeneration"`
		ReadyReplicas      int    `json:"readyReplicas"`
		Replicas           int    `json:"replicas"`
		Type               string `json:"type"`
		UpdateRevision     string `json:"updateRevision"`
		UpdatedReplicas    int    `json:"updatedReplicas"`
	} `json: "statefulSetStatus"`
}

type RancherDeployment struct {
	Deployment []struct {
		ID              string `json:"id"`
		Name            string `json:"name"`
		State           string `json:"state"`
		ProjectID       string `json:"projectId"`
		Scale           int    `json:"scale"`
		DesiredReplicas int    `json:"desiredReplicas"`
		NamespaceId     string `json:"namespaceId"`
		ClusterName     string
		ProjectName     string
		EnableForBot    string
		NormalReplicas  int
		EventReplicas   int
		Position        int
		Type            string

		DeploymentStatus struct {
			AvailableReplicas int `json: "availableReplicas"`
			ReadyReplicas     int `json: "readyReplicas"`
			Replicas          int `json: "replicas"`
		} `json: "deploymentStatus"`

		StatefulSetStatus struct {
			AvailableReplicas  int    `json:"availableReplicas"`
			CollisionCount     int    `json:"collisionCount"`
			CurrentReplicas    int    `json:"currentReplicas"`
			CurrentRevision    string `json:"currentRevision"`
			ObservedGeneration int    `json:"observedGeneration"`
			ReadyReplicas      int    `json:"readyReplicas"`
			Replicas           int    `json:"replicas"`
			Type               string `json:"type"`
			UpdateRevision     string `json:"updateRevision"`
			UpdatedReplicas    int    `json:"updatedReplicas"`
		} `json: "statefulSetStatus"`
	} `json:"data"`
}

type RancherObject struct {
	name    string
	id      string
	context string
}

type RancherUser struct {
	id          string
	name        string
	cluster     string
	clusterRole string
	project     string
	projectRole string
}

type Data struct {
	ID                 string `json:"id"`
	Name               string `json:"name"`
	State              string `json:"state"`
	ProjectID          string `json:"projectId"`
	CurrentReplicas    int    `json:"currentReplicas"`
	DesiredReplicas    int    `json:"desiredReplicas"`
	MaxReplicas        int    `json:"maxReplicas"`
	MinReplicas        int    `json:"minReplicas"`
	NamespaceId        string `json:"namespaceId"`
	NormalMinReplicas  int    `json:"normalMinReplicas"`
	NormalMaxReplicas  int    `json:"normalMaxReplicas"`
	EventMinReplicas   int    `json:"eventMinReplicas"`
	EventMaxReplicas   int    `json:"eventMaxReplicas"`
	Enabled            string `json:"IsEnabled"`
	WorkloadID         string `json:"workloadId"`
	IsHpa              bool
	ClusterName        string
	TempMinReplicas    int
	TempMaxReplicas    int
	ProjectName        string
	Position           int
	Replicas           int
	ReplicaData        string
	CurrentRepData     string
	CurrentMinReplicas string
	CurrentMaxReplicas string
	Type               string
}

type RancherHpas struct {
	Data []struct {
		ID              string `json:"id"`
		Name            string `json:"name"`
		State           string `json:"state"`
		ProjectID       string `json:"projectId"`
		CurrentReplicas int    `json:"currentReplicas"`
		DesiredReplicas int    `json:"desiredReplicas"`
		MaxReplicas     int    `json:"maxReplicas"`
		MinReplicas     int    `json:"minReplicas"`
		NamespaceId     string `json:"namespaceId"`
		WorkloadID      string `json:"workloadId"`
		ClusterName     string
		ProjectName     string
		Enabled         string
	} `json:"data"`
}

type HpaData struct {
	ID              string `json:"id"`
	Name            string `json:"name"`
	State           string `json:"state"`
	ProjectID       string `json:"projectId"`
	CurrentReplicas int    `json:"currentReplicas"`
	DesiredReplicas int    `json:"desiredReplicas"`
	MaxReplicas     int    `json:"maxReplicas"`
	MinReplicas     int    `json:"minReplicas"`
	NamespaceId     string `json:"namespaceId"`
	WorkloadID      string `json:"workloadId"`
	ClusterName     string
	ProjectName     string
	Enabled         string
}
