package github

import (
	"fmt"
	"slack-bot/common"
	"strconv"

	"github.com/slack-go/slack"
)

func HandleSelfAddUserToGit(input string) (slack.MsgOption, error) {
	var msg slack.MsgOption

	return msg, nil
}

func getAddToOrgsBlock() (slack.MsgOption, error) {
	var block slack.MsgOption

	headerGitText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerGitSection := slack.NewSectionBlock(headerGitText, nil, nil)

	userName := common.GetTxtInputBlock("add_to_orgs_git_username", "Enter git user email:", "Ex: xuan.can or xuan.can@tiki.vn")

	addUserButton := common.GetAprroveBtn("submit_add_to_orgs_git_btn")

	block = slack.MsgOptionBlocks(
		headerGitSection,
		userName,
		addUserButton,
	)

	return block, nil
}

func getCreateRepoBlock() (slack.MsgOption, error) {
	var block slack.MsgOption

	headerGitText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerGitSection := slack.NewSectionBlock(headerGitText, nil, nil)

	repoInputBlock := common.GetTxtInputBlock("git_repo_input", "Enter git repo name:", "Ex: newRepo")

	userInputBlock := common.GetTxtInputBlock("user_name_to_repo_input", "Enter user name, this user will be admin of this repo, could be empty, separate by `,` character", "Example: xuancanTiki, nguyendoanTiki")

	addUserButton := common.GetAprroveBtn("submit_addreopo_git_btn")

	block = slack.MsgOptionBlocks(
		headerGitSection,
		repoInputBlock,
		userInputBlock,
		addUserButton,
	)

	return block, nil
}

func GetGitBlock(seatsLeft int) (slack.MsgOption, error) {

	var block slack.MsgOption
	headerGitText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n`Currently, there are *"+strconv.Itoa(seatsLeft)+"* seats left`", false, false)
	headerGitSection := slack.NewSectionBlock(headerGitText, nil, nil)

	inputBlock := common.GetTxtInputBlock("git_user_name_input", "Enter git user name:", "Ex: xuancanTiki")

	teamInputBlock := common.GetTxtInputBlock("repos_name_input", "Enter repository name, max 5 repos:", "Ex: fullfilment, tikivn/test, https://github.com/tikivn/test.git, or just select a team if needed")

	ognTeams, err := getAllOgnTeam()

	addUserButton := common.GetAprroveBtn("submit_adduser_git_btn")

	//fmt.Println(ognTeams)

	if err != nil {
		fmt.Println("Error in get team")
		return block, err
	}

	selectTeamBlock, err := GetTeamOptions(ognTeams)
	if err != nil {

		fmt.Println("\nError in get team")
		return block, err
	}

	repoPermissionBlock, err := GetRepoPermissionBlocks()

	if err != nil {

		fmt.Println("\nError in get repo permission")
		return block, err
	}

	block = slack.MsgOptionBlocks(
		headerGitSection,
		inputBlock,
		teamInputBlock,
		repoPermissionBlock,
		selectTeamBlock,
		addUserButton,
	)

	return block, nil

}

func GetRepoPermissionBlocks() (*slack.ActionBlock, error) {
	repoPermissionOptions := []*slack.OptionBlockObject{}

	permissions := [5]string{"read", "triage", "write", "maintain", "admin"}

	var initialOption *slack.OptionBlockObject

	for i := 0; i < len(permissions); i++ {
		tempTxt := slack.NewTextBlockObject("plain_text", permissions[i], false, false)
		tempOption := slack.NewOptionBlockObject(permissions[i], tempTxt, nil)
		repoPermissionOptions = append(repoPermissionOptions, tempOption)

		if permissions[i] == "write" {
			initOption := slack.NewTextBlockObject("plain_text", permissions[i], false, false)
			initialOption = slack.NewOptionBlockObject(permissions[i], initOption, nil)
		}
	}

	availableOption := common.NewOptionsSelectBlockElementWithInitOptions("static_select", "permission_options", initialOption, repoPermissionOptions...)

	return_block := slack.NewActionBlock("permission_options", availableOption)

	return return_block, nil

}

func GetTeamOptions(ognTeams gitTeams) (*slack.ActionBlock, error) {

	//for loop to get options

	options := []*slack.OptionBlockObject{}

	//fmt.Printf("length of team, ", len(ognTeams))

	for _, team := range ognTeams {

		tempTxt := slack.NewTextBlockObject("plain_text", team.Name, false, false)
		tempOption := slack.NewOptionBlockObject(team.Name, tempTxt, nil)

		//fmt.Printf("\n" + strconv.Itoa(team.ID) + team.Name + "\n")
		options = append(options, tempOption)

	}

	selectObject := slack.NewTextBlockObject("plain_text", "select a team", false, false)

	availableOption := slack.NewOptionsSelectBlockElement("static_select", selectObject, "teamids", options...)

	return_block := slack.NewActionBlock("options", availableOption)

	return return_block, nil

}
