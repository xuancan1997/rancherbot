package github

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"strconv"
	"strings"

	"github.com/slack-go/slack"
)

type GitAddUserInfo struct {
	userName       string
	gitRepos       []string
	repoPermission string
	gitTeam        string
}

func CreateNewGitRepo(repoName, userName, permission string) error {

	if err := createNewRepo(repoName); err != nil {
		return err
	}

	if err := addUserToRepo(userName, repoName, permission); err != nil {
		return err
	}

	return nil
}

//check user has gitUserName or added to repo or not
func CheckUserAddToRepo(repoInput, userID string) error {

	if err := CheckExistUserGitName(userID); err != nil {
		return err
	}

	userGitName := GetUserGitName(userID)

	if userGitName == "" {
		return fmt.Errorf("cannot get git Username for userID %s, you may need to set it first with command `set git username <gitUsername>`", userID)
	}
	log.Print(userGitName)

	if !CheckRepoExist(repoInput) {
		return fmt.Errorf("repo %s is not exist", repoInput)
	}

	return nil
}

func GetUserGitName(userID string) string {

	log.Print(userID)
	v, err := common.GetViperClient("user_git.properties")
	if err != nil {
		return ""
	}

	if gitName := v.GetString(strings.ToLower(userID)); gitName != "" {
		return gitName
	} else {
		return ""
	}
}
func CheckExistUserGitName(userID string) error {
	v, err := common.GetViperClient("user_git.properties")
	if err != nil {
		return err
	}

	if gitName := v.GetString(strings.ToLower(userID)); gitName == "" {
		return fmt.Errorf("cannot find your git Username , you may need to add it first with command below:\n`set git username <yourUsername>`", userID)
	}

	return nil
}

func SetGitUserName(userInput, userID string) error {

	log.Println("user git input: ", userInput)

	if err := checkUserExist(userInput); err != nil {
		return err
	}

	if err := checkUserInOrgs(userInput); err != nil {
		return err
	}

	if err := setUserNameToFile(userInput, userID); err != nil {
		return err
	}

	return nil
}

func setUserNameToFile(userGit, userID string) error {

	v, err := common.GetViperClient("user_git.properties")
	if err != nil {
		return err
	}
	v.Set(userID, userGit)
	v.WriteConfig()
	return nil
}

func HandleGitAddToOrgsBtn(userName string) error {

	err := common.ValidateInput(userName, "gitName")
	if err != nil {
		return err
	}

	err = addUserToOrgs(userName)

	if err != nil {
		return err
	}

	return nil
}

func GetAddRepoData(blockAc map[string]map[string]slack.BlockAction) error {

	repoName := blockAc["git_repo_input"]["git_repo_input"].Value
	userAddGit := strings.TrimSpace(blockAc["user_name_to_repo_input"]["user_name_to_repo_input"].Value)

	err := common.ValidateInput(repoName, "gitRepos")

	if err != nil {
		return err
	}

	// if userAddGit != "" {
	// 	err = common.ValidateInput(userAddGit, "gitName")
	// }

	// if err != nil {
	// 	return err
	// }

	err = createNewRepo(repoName)

	if err != nil {
		return err
	}

	if userAddGit != "" {

		splitGitUser := strings.Split(userAddGit, ",")

		for _, user := range splitGitUser {
			var gitUserData GitAddUserInfo

			gitUserData.userName = user
			gitUserData.repoPermission = "admin"
			gitUserData.gitRepos = append(gitUserData.gitRepos, repoName)
			err = AddMemberToProject(gitUserData)
			if err != nil {
				return err
			}
		}

	}

	//add team deployment with read permission
	err = AddDeploymentTeamToNewRepo(repoName)
	if err != nil {
		return err
	}
	return nil

}

func GetAddToOrgsBlock() (slack.MsgOption, error) {

	var block slack.MsgOption
	block, err := getAddToOrgsBlock()
	if err != nil {
		return block, err
	}
	return block, nil
}

func GetCreateRepoBlock() (slack.MsgOption, error) {

	var block slack.MsgOption
	block, err := getCreateRepoBlock()
	if err != nil {
		return block, err
	}
	return block, nil
}

func GetGitMsg() (slack.MsgOption, error) {

	var msg slack.MsgOption
	seatAvailable, seatsLeft, err := checkSeatAvailable()

	if err != nil {
		return msg, err
	}

	fmt.Println("seat Info: ", seatAvailable, seatsLeft)
	if seatAvailable {
		msg, err = GetGitBlock(seatsLeft)
	} else {
		return msg, errors.New("No more seats available, please add seat following link below: \n https://github.com/organizations/tikivn/settings/billing/seats?return_to=%2Forgs%2Ftikivn%2Fpeople%23invite-member&seats=1")
	}

	if err != nil {
		return msg, err
	}

	return msg, nil
}

func AddMemberToProject(gitUserData GitAddUserInfo) error {
	ORG_TEAM := os.Getenv("ORG_TEAM")
	//var gitUserData GitAddUserInfo

	seatAvailable, seatsLeft, err := checkSeatAvailable()

	println("Number of seats avaiable:", seatsLeft)

	if err != nil {
		return err
	}

	if seatAvailable {
		if len(gitUserData.gitRepos) > 5 {
			return errors.New("currently work with max adding user to 5 repos")
		}

		//add user to project

		if gitUserData.gitRepos[0] != "" {
			for _, gitRepo := range gitUserData.gitRepos {

				// gitRepoId, err := getGitRepoIdByName(gitRepo)

				// if err != nil {
				// 	return err
				// }

				if strings.Contains(gitRepo, ORG_TEAM) {
					gitRepo = strings.Split(gitRepo, ORG_TEAM+"/")[1]
				}

				if strings.Contains(gitRepo, ".git") {
					gitRepo = strings.Split(gitRepo, ".")[0]
				}
				err = checkUserIsACollaborator(gitUserData.userName, gitRepo)

				if err == nil {
					return errors.New("user is already a collaborator")
				}

				err = addUserToRepo(gitUserData.userName, gitRepo, gitUserData.repoPermission)

				if err != nil {
					return err
				}
			}
		}

		if gitUserData.gitTeam != "" {

			ognTeams, err := getAllOgnTeam()

			if err != nil {
				return err
			}

			gitTeamID := 0
			for _, team := range ognTeams {
				if team.Name == gitUserData.gitTeam {
					gitTeamID = team.ID
					break
				}
			}
			//add user to team

			if gitTeamID == 0 {
				return errors.New("git team not found!!!")
			}
			err = addUserToTeam(gitUserData.userName, strconv.Itoa(gitTeamID))
			if err != nil {
				return err
			}
		}

		if err != nil {
			return err
		}

	} else {
		return errors.New("no more seat available")
	}

	return nil
}

func checkSeatAvailable() (bool, int, error) {
	companyData, err := getOrgsPlan()

	if err != nil {
		return false, 0, err
	}

	log.Println("Company data", companyData)
	log.Println("seats: ", companyData.Plan.Seats, companyData.Plan.FilledSeats)

	if companyData.Plan.Seats > companyData.Plan.FilledSeats {
		return true, (companyData.Plan.Seats - companyData.Plan.FilledSeats), nil
	} else {
		return false, 0, nil
	}

}

func GetUserGitInputData(blockAc map[string]map[string]slack.BlockAction) (GitAddUserInfo, error) {

	//if team is selected, repo can be empty, so need a var to check
	var isEmty bool

	var userInfo GitAddUserInfo
	userName := blockAc["git_user_name_input"]["git_user_name_input"].Value

	err := common.ValidateInput(userName, "gitName")

	if err != nil {
		return userInfo, err
	}

	userInfo.userName = userName

	gitRepos := blockAc["repos_name_input"]["repos_name_input"].Value

	err = common.ValidateInput(gitRepos, "gitRepos")

	if err != nil {
		return userInfo, err
	}

	userInfo.gitRepos = strings.Split(strings.Replace(strings.ToLower(gitRepos), " ", "", -1), ",")

	//get repo permission
	repoPermission := blockAc["permission_options"]["permission_options"].SelectedOption.Value

	// fmt.Println("permission choose: ", repoPermission)

	// fmt.Println("permission choose: ", blockAc["permission_options"])

	if repoPermission == "" {
		fmt.Printf("\nUser not choose permission options\n")
		if userName == "" {
			isEmty = true
		} else {
			return userInfo, errors.New("you must specific a role for user")
		}
	}

	userInfo.repoPermission = repoPermission

	//get user team
	option_team_block := blockAc["options"]["teamids"].SelectedOption.Value

	if option_team_block == "" {
		fmt.Printf("\nUser not choose team options")
		if isEmty {
			return userInfo, errors.New("you need to choose a team or a repo")
		}
	} else {
		fmt.Println("User choose team options", option_team_block)
		userInfo.gitTeam = option_team_block
	}

	return userInfo, nil

}
