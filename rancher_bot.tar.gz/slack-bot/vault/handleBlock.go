package vault

import (
	"errors"
	"log"
	"slack-bot/common"
	"slack-bot/rancher"
	"strings"

	"github.com/slack-go/slack"
)

func SearchVaultMsgBlock(data, userID, eventType string) (slack.MsgOption, error) {
	var msg slack.MsgOption
	var deploymentData rancher.Data
	deployment, projectNamespace, err := getDeploymentName(data)

	if err != nil {
		return msg, err
	}

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n`Search env for deployment *"+deployment+"*`\n*Please choose secrets you need to update:",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	deploymentData.Name = deployment
	dataSplit := strings.Split(projectNamespace, "|")
	deploymentData.ProjectID = dataSplit[0]
	deploymentData.NamespaceId = dataSplit[1]
	secrets, err := rancher.GetDeploymentSecrets(deploymentData)
	if err != nil {
		return msg, err
	}

	secretBlockElm, err := common.GetSelectedOptionBlock(secrets, secrets[0], "Choose secrets", "action_choose_secret", "")
	if err != nil {
		return msg, err
	}

	secretBlock := slack.NewActionBlock("action_choose_secret", secretBlockElm)
	input := common.GetTxtInputBlock("pattern_input_vault_check", "Enter pattern vault check", "Example: KAFKA")
	btn := common.GetAprroveBtnWithValue("pattern_vault_check_btn", deployment+" "+userID+" "+eventType)
	msg = slack.MsgOptionBlocks(
		headerSection,
		//deploymentBlock,
		secretBlock,
		input,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func getDeploymentName(input string) (string, string, error) {
	deployment := ""
	var projectID string
	dataSplit := strings.Split(input, " ")

	if len(dataSplit) != 3 {
		return deployment, "", errors.New("Format not correct, please type *help* for check")
	}

	deployment = dataSplit[2]

	err := common.ValidateInput(deployment, "name")

	if err != nil {
		return deployment, "", err
	}

	//check deployment is exist
	_, deploymentFound, projectID, err := rancher.GetDeploymentFindInputData(deployment)

	if err != nil {
		return deployment, "", err
	}

	deploySplit := strings.Split(deploymentFound, ",")

	deployFound := false
	for i := range deploySplit {
		if deploySplit[i] == deployment {
			deployFound = true
			break
		}
	}

	if !deployFound || deployment == "" {
		err = rancher.HandleDeploymentUpdateLocalFile()

		if err != nil {
			log.Println(err)
		}

		return deployment, projectID, errors.New("cannot find deployment, if it's new, please retry after 3 seconds")
	}

	return deployment, projectID, nil
}

func HandleUserSelfCreateVaultBlock(data, user string) (slack.MsgOption, error) {
	var msg slack.MsgOption

	deployment, _, err := getDeploymentName(data)
	if err != nil {
		return msg, err
	}

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n*Please note that this will create a new secret and environment variables, The value after create could show only if you mount the secret created to tikici first*\n`Create vault for deployment *"+deployment+"*`",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	//deploymentBlock := common.GetTxtInputBlockWithInitInput("user_update_deployment_input", "Deployment block", "example", deployment)

	secretBlock := common.GetTxtInputBlock("vault_self_create_secret_name", "Enter secret name", "Example: bulma-secrets")
	inputBlock2 := common.GetMultiLinesInputBlock("vault_self_create_value", "Enter vault create value", "Example:\na=b\nc:d\n\"c\":\"d\"")
	btn := common.GetAprroveBtnWithValue("user_self_create_vault", deployment+" "+user)
	msg = slack.MsgOptionBlocks(
		headerSection,
		//deploymentBlock,
		secretBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func HandleUserSelfUpdateVaultBlock(data, user string) (slack.MsgOption, error) {
	var msg slack.MsgOption
	var deploymentData rancher.Data
	deployment, projectNamespace, err := getDeploymentName(data)

	if err != nil {
		return msg, err
	}

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n`Update env for deployment *"+deployment+"*`\n*Please choose secrets you need to update:",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	deploymentData.Name = deployment
	dataSplit := strings.Split(projectNamespace, "|")
	deploymentData.ProjectID = dataSplit[0]
	deploymentData.NamespaceId = dataSplit[1]
	secrets, err := rancher.GetDeploymentSecrets(deploymentData)
	if err != nil {
		return msg, err
	}
	secretBlockElm, err := common.GetSelectedOptionBlock(secrets, secrets[0], "Choose secrets", "action_choose_secret", "")
	if err != nil {
		return msg, err
	}

	secretBlock := slack.NewActionBlock("action_choose_secret", secretBlockElm)

	//deploymentBlock := common.GetTxtInputBlockWithInitInput("user_update_deployment_input", "Deployment block", "example", deployment)

	inputBlock2 := common.GetMultiLinesInputBlock("vault_self_update_value", "Enter vault update value", "Example:\na=b\nc:d\n\"c\":\"d\"")
	btn := common.GetAprroveBtnWithValue("user_self_update_vault", deployment+" "+user)
	msg = slack.MsgOptionBlocks(
		headerSection,
		//deploymentBlock,
		secretBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func CheckVaultMsg() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetTxtInputBlock("vault_find_deployment", "Enter deployment need to update vault", "Example: bulma")
	secretBlock := common.GetTxtInputBlock("vault_secret_name", "Enter secret need to update, ignore if secret name is same as deployment", "Example: bulma-secrets")
	inputBlock2 := common.GetMultiLinesInputBlock("vault_check_value", "Enter vault check value", "Example:\nBULMAMA\nQUATA")

	btn := common.GetAprroveBtn("vault_check_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		secretBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func CreateVaultMsg() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetTxtInputBlock("vault_new_deployment", "Enter deployment need to create vault", "Example: bulma")
	secretBlock := common.GetTxtInputBlock("vault_secret_name", "Enter secret need to create, ignore if secret name is same as deployment", "Example: bulma-secrets")
	inputBlock2 := common.GetMultiLinesInputBlock("vault_new_value", "Enter vault value", "Example:\nBULMAMA=1\nQUATA:2")

	btn := common.GetAprroveBtn("create_vault_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		secretBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func UpdateVaultMsg() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetTxtInputBlock("vault_find_deployment", "Enter deployment need to update vault", "Example: bulma")
	secretBlock := common.GetTxtInputBlock("vault_secret_name", "Enter secret need to update, ignore if secret name is same as deployment", "Example: bulma-secrets")
	inputBlock2 := common.GetMultiLinesInputBlock("vault_update_value", "Enter vault update value", "Example:\na=b\nc:d")

	btn := common.GetAprroveBtn("vault_update_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		secretBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}
