package common

import (
	"errors"
	"log"
	"sort"
	"strconv"

	"github.com/slack-go/slack"
)

func NewPlainTextInputBlockElement(placeholder *slack.TextBlockObject, actionID, initValue string, multiLines bool) *slack.PlainTextInputBlockElement {
	return &slack.PlainTextInputBlockElement{
		Type:         slack.METPlainTextInput,
		ActionID:     actionID,
		Placeholder:  placeholder,
		InitialValue: initValue,
		Multiline:    multiLines,
	}
}

func GetRandomPasswordBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nGenerate random password:`",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	pwdLengthElm, err := GetSelectedOptionsNumberBlock(30, 12, "length", "pwd_length")

	if err != nil {
		return msg, err
	}

	specialCharacter, err := GetSelectedOptionsNumberBlock(10, 0, "Special char", "special_character")

	if err != nil {
		return msg, err
	}
	number, err := GetSelectedOptionsNumberBlock(10, 0, "Numbers", "number_count")

	if err != nil {
		return msg, err
	}
	upperCase, err := GetSelectedOptionsNumberBlock(10, 3, "UpperCases", "upperCase")

	if err != nil {
		return msg, err
	}
	blockAc := slack.NewActionBlock("random_password", pwdLengthElm, specialCharacter, number, upperCase)
	btn := GetAprroveBtn("pwd_approve_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		blockAc,
		btn,
	)
	return msg, nil
}

func GetInputBlock(command string) *slack.InputBlock {

	plainTextData := ""

	var plainInput *slack.TextBlockObject
	var placeholder *slack.TextBlockObject

	switch command {
	case "add_user":
		plainTextData = "Fill information to create user"
		placeholder = slack.NewTextBlockObject("plain_text", "Enter user name", true, false)

	case "grant_user":
		plainTextData = "Fill information to update user"
		placeholder = slack.NewTextBlockObject("plain_text", "Enter user need to update", true, false)

	case "add_kong_svc":
		plainTextData = "Fill information to create Kong svc"
		placeholder = slack.NewTextBlockObject("plain_text", "Enter services path", true, false)

	case "add_kong_route":
		plainTextData = "Fill information to create Kong Routes"
		placeholder = slack.NewTextBlockObject("plain_text", "Enter routes path", true, false)
	default:
	}

	plainInput = slack.NewTextBlockObject("plain_text", plainTextData, true, false)

	userInput := slack.NewPlainTextInputBlockElement(placeholder, "user_name")

	inputBlock := slack.NewInputBlock("input_ac", plainInput, nil, userInput)

	return inputBlock
}

func GetAprroveBtn(actionId string) *slack.ActionBlock {
	//button approve
	approveBtnTxt := slack.NewTextBlockObject("plain_text", "Apply", false, false)
	approveBtn := slack.NewButtonBlockElement(actionId, "submit", approveBtnTxt)

	//button approve

	actionBlock := slack.NewActionBlock(actionId, approveBtn)

	return actionBlock

}

func GetAprroveBtnWithValue(actionId, valueSubmit string) *slack.ActionBlock {
	//button approve
	approveBtnTxt := slack.NewTextBlockObject("plain_text", "Submit", false, false)
	approveBtn := slack.NewButtonBlockElement(actionId, valueSubmit, approveBtnTxt)

	//button approve

	actionBlock := slack.NewActionBlock(actionId, approveBtn)

	return actionBlock

}

// func NewOptionsSelectBlockElementWithInitOptions(optType string, placeholder *slack.TextBlockObject, actionID string, initOptions *OptionBlockObject, options ...*OptionBlockObject) *SelectBlockElement {
// 	return &slack.SelectBlockElement{
// 		Type:          optType,
// 		Placeholder:   placeholder,
// 		ActionID:      actionID,
// 		Options:       options,
// 		InitialOption: initOptions,
// 	}
// }

func GetMultiLinesInputBlockWithInitOption(blockID string, label string, placeholder string, initValue string) *slack.InputBlock {
	labelName := slack.NewTextBlockObject("plain_text", label, false, false)
	textBlockObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)
	blockElm := NewPlainTextInputBlockElement(textBlockObject, blockID, initValue, true)
	inputBlock := slack.NewInputBlock(blockID, labelName, nil, blockElm)

	return inputBlock
}

func GetMultiLinesInputBlock(blockID string, label string, placeholder string) *slack.InputBlock {
	labelName := slack.NewTextBlockObject("plain_text", label, false, false)
	textBlockObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)
	blockElm := NewMultiLinePlainTextInputBlockElement(textBlockObject, blockID, true)
	inputBlock := slack.NewInputBlock(blockID, labelName, nil, blockElm)

	return inputBlock
}

func NewMultiLinePlainTextInputBlockElement(placeholder *slack.TextBlockObject, actionID string, multiline bool) *slack.PlainTextInputBlockElement {
	return &slack.PlainTextInputBlockElement{
		Type:        slack.METPlainTextInput,
		ActionID:    actionID,
		Placeholder: placeholder,
		Multiline:   multiline,
	}
}

func GetOptionsNumberBlock(number int, placeholder string, actionID string) (*slack.SelectBlockElement, error) {
	options := []*slack.OptionBlockObject{}

	for i := 0; i < number; i++ {
		tempTxt := slack.NewTextBlockObject("plain_text", strconv.Itoa(i), false, false)
		tempOption := slack.NewOptionBlockObject(strconv.Itoa(i), tempTxt, nil)
		options = append(options, tempOption)
	}

	selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	availableOption := slack.NewOptionsSelectBlockElement("static_select", selectObject, actionID, options...)

	//return_block := slack.NewActionBlock(actionID, availableOption)

	return availableOption, nil

}

func GetOptionsBlock(input []string, selectType string, placeholder string, actionID string) (*slack.SelectBlockElement, error) {
	options := []*slack.OptionBlockObject{}

	sort.Strings(input)

	for i := 0; i < len(input); i++ {
		tempTxt := slack.NewTextBlockObject("plain_text", input[i], false, false)
		tempOption := slack.NewOptionBlockObject(input[i], tempTxt, nil)
		options = append(options, tempOption)
	}

	selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	availableOption := slack.NewOptionsSelectBlockElement(selectType, selectObject, actionID, options...)

	//return_block := slack.NewActionBlock(actionID, availableOption)

	return availableOption, nil

}

func GetSelectedOptionsNumberBlock(number int, selectVal int, placeholder string, actionID string) (*slack.SelectBlockElement, error) {
	options := []*slack.OptionBlockObject{}
	var availableOption *slack.SelectBlockElement
	if selectVal%10 != 0 && selectVal >= 100 {
		return availableOption, errors.New("if pods >= 100, then pod % 10 == 0, please use `hpa edits` to edit manually")
	}
	valueToString := strconv.Itoa(selectVal)
	initJumpNumber := 0

	if selectVal > 1000 {
		return availableOption, errors.New("Currently support max 1k pod")
	}

	if selectVal >= 50 {
		//create a jump number
		number = 490
		initJumpNumber = 4
	}
	if selectVal > number || selectVal >= 100 {
		//create a jump number
		number = 990
		initJumpNumber = 9

	}

	//round selectval
	if selectVal%(initJumpNumber+1) != 0 {
		selectVal = selectVal / (initJumpNumber + 1)
		selectVal *= (initJumpNumber + 1)

		valueToString = strconv.Itoa(selectVal)
		println(selectVal)
	}

	for i := 0; i < number; i++ {

		tempTxt := slack.NewTextBlockObject("plain_text", placeholder+": "+strconv.Itoa(i), false, false)
		tempOption := slack.NewOptionBlockObject(strconv.Itoa(i), tempTxt, nil)
		options = append(options, tempOption)
		i += initJumpNumber
	}

	initOption := slack.NewTextBlockObject("plain_text", placeholder+": "+valueToString, false, false)
	initialOption := slack.NewOptionBlockObject(valueToString, initOption, nil)

	//selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	availableOption = NewOptionsSelectBlockElementWithInitOptions("static_select", actionID, initialOption, options...)

	//return_block := slack.NewActionBlock(actionID, availableOption)

	return availableOption, nil

}
func GetSelectedOptionBlock(input []string, selectValue string, placeholder string, actionID string, additionStr string) (*slack.SelectBlockElement, error) {

	log.Println(input)
	log.Println(selectValue)

	if input[0] == selectValue {
		log.Println("same")
	}
	options := []*slack.OptionBlockObject{}

	for i := 0; i < len(input); i++ {
		tempTxt := slack.NewTextBlockObject("plain_text", additionStr+" "+input[i], true, false)
		tempOption := slack.NewOptionBlockObject(input[i], tempTxt, nil)
		options = append(options, tempOption)
	}

	initOption := slack.NewTextBlockObject("plain_text", additionStr+" "+selectValue, false, false)
	initialOption := slack.NewOptionBlockObject(selectValue, initOption, nil)

	//selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	availableOption := NewOptionsSelectBlockElementWithInitOptions("static_select", actionID, initialOption, options...)

	//return_block := slack.NewActionBlock(actionID, availableOption)

	return availableOption, nil

}

func GetSelectedOptionMultiInputBlock(input []string, selectValue string, placeholder string, actionID string, additionStr string) (*slack.SelectBlockElement, error) {

	log.Println(input)
	log.Println(selectValue)

	if input[0] == selectValue {
		log.Println("Same same")
	}
	options := []*slack.OptionBlockObject{}

	for i := 0; i < len(input); i++ {
		tempTxt := slack.NewTextBlockObject("plain_text", additionStr+" "+input[i], true, false)
		tempOption := slack.NewOptionBlockObject(input[i], tempTxt, nil)
		options = append(options, tempOption)
	}

	initOption := slack.NewTextBlockObject("plain_text", additionStr+" "+selectValue, false, false)
	initialOption := slack.NewOptionBlockObject(selectValue, initOption, nil)

	//selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	availableOption := NewOptionsSelectBlockElementWithInitOptions("static_select", actionID, initialOption, options...)

	//return_block := slack.NewActionBlock(actionID, availableOption)

	return availableOption, nil

}

func NewOptionsSelectBlockElementWithInitOptions(optType string, actionID string, initOptions *slack.OptionBlockObject, options ...*slack.OptionBlockObject) *slack.SelectBlockElement {
	return &slack.SelectBlockElement{
		Type:          optType,
		ActionID:      actionID,
		Options:       options,
		InitialOption: initOptions,
	}
}

func GetTxtInputBlock(blockID string, label string, placeholder string) *slack.InputBlock {
	labelName := slack.NewTextBlockObject("plain_text", label, false, false)
	textBlockObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)
	blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, blockID)
	inputBlock := slack.NewInputBlock(blockID, labelName, nil, blockElm)

	return inputBlock

}

func GetTxtInputBlockWithInitInput(blockID string, label string, placeholder string, initInput string) *slack.InputBlock {
	labelName := slack.NewTextBlockObject("plain_text", label, false, false)
	textBlockObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)
	blockElm := NewPlainTextInputBlockElement(textBlockObject, blockID, initInput, false)
	inputBlock := slack.NewInputBlock(blockID, labelName, nil, blockElm)
	return inputBlock
}

func GetTxtInputBlockElm(blockID string, placeholder string) *slack.PlainTextInputBlockElement {
	textBlockObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)
	blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, blockID)
	return blockElm

}

func GetButtonBlock(blockId string, label string, value string) *slack.ActionBlock {
	approveBtnTxt := slack.NewTextBlockObject("plain_text", label, false, false)
	approveBtn := slack.NewButtonBlockElement(blockId, value, approveBtnTxt)
	//button approve
	actionBlock := slack.NewActionBlock(blockId, approveBtn)

	return actionBlock
}
