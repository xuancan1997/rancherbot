package github

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

type gitTeams []struct {
	Name            string      `json:"name"`
	ID              int         `json:"id"`
	NodeID          string      `json:"node_id"`
	Slug            string      `json:"slug"`
	Description     string      `json:"description,omitempty"`
	Privacy         string      `json:"privacy,omitempty"`
	URL             string      `json:"url,omitempty"`
	HTMLURL         string      `json:"html_url,omitempty"`
	MembersURL      string      `json:"members_url"`
	RepositoriesURL string      `json:"repositories_url"`
	Permission      string      `json:"permission"`
	Parent          interface{} `json:"parent"`
}

type orgsDatas struct {
	ID                          int    `json:"id"`
	URL                         string `json:"url"`
	ReposURL                    string `json:"repos_url"`
	EventsURL                   string `json:"events_url"`
	HooksURL                    string `json:"hooks_url"`
	IssuesURL                   string `json:"issues_url"`
	MembersURL                  string `json:"members_url"`
	PublicMembersURL            string `json:"public_members_url"`
	AvatarURL                   string `json:"avatar_url"`
	Description                 string `json:"description"`
	Name                        string `json:"name"`
	BillingEmail                string `json:"billing_email"`
	DefaultRepositoryPermission string `json:"default_repository_permission"`
	Plan                        struct {
		Name         string `json:"name"`
		Space        int    `json:"space"`
		PrivateRepos int    `json:"private_repos"`
		FilledSeats  int    `json:"filled_seats"`
		Seats        int    `json:"seats"`
	} `json:"plan"`
}

type repoGit struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

func CheckRepoExist(repoInput string) bool {
	ORG_TEAM := os.Getenv("ORG_TEAM")
	data := make(map[string]interface{})
	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("GET", fmt.Sprintf("/repos/%s/%s", ORG_TEAM, repoInput), string(json_req))

	if err != nil {
		return false
	}

	if resp.StatusCode == 404 {
		log.Println("Status code: ", resp.StatusCode)
		return false

	} else {
		return true
	}

}

func checkUserInOrgs(userInput string) error {
	ORG_TEAM := os.Getenv("ORG_TEAM")
	data := make(map[string]interface{})
	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("GET", fmt.Sprintf("/orgs/%s/members/%s", ORG_TEAM, userInput), string(json_req))

	if err != nil {
		return err
	}

	if resp.StatusCode == 204 {
		log.Println("Status code: ", resp.StatusCode)
		return nil

	} else {
		errmsg := fmt.Sprintf("user %s not in %s!!!", userInput, ORG_TEAM)
		return errors.New(errmsg)
	}
}

func checkUserExist(userInput string) error {
	data := make(map[string]interface{})
	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("GET", fmt.Sprintf("/users/%s", userInput), string(json_req))

	if err != nil {
		return err
	}

	if resp.StatusCode == 200 {
		log.Println("Status code: ", resp.StatusCode)
		return nil

	} else {
		errmsg := fmt.Sprintf("user %s not found!!!", userInput)
		return errors.New(errmsg)
	}
}

func AddDeploymentTeamToNewRepo(repoName string) error {
	ORG_TEAM := os.Getenv("ORG_TEAM")
	data := make(map[string]interface{})

	data["permission"] = "pull"

	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("PUT", "/orgs/"+ORG_TEAM+"/teams/deployment/repos/tikivn/"+repoName, string(json_req))

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 204 {
		log.Println("Status code: ", resp.StatusCode)
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in add deployment team to " + repoName
		return errors.New(errmsg)
	}

}

func addUserToOrgs(userName string) error {
	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")
	data := make(map[string]interface{})

	log.Println("User: ", userName)
	if !strings.Contains(userName, "@tiki.vn") {
		userName = userName + "@tiki.vn"
		//return errors.New("Name must be end with @tiki.vn")
	}
	data["email"] = userName

	data["role"] = "direct_member"

	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("POST", "/orgs/"+ORG_TEAM+"/invitations", string(json_req))

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 201 {
		log.Println("Status code: ", resp.StatusCode)
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in add user to orgs " + ORG_TEAM
		return errors.New(errmsg)
	}
}

func createNewRepo(repoName string) error {
	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")
	data := make(map[string]interface{})

	data["name"] = repoName

	println("repoName: ", repoName)
	data["private"] = true

	json_req, _ := json.Marshal(data)
	resp, err := initGitHttpReq("POST", "/orgs/"+ORG_TEAM+"/repos", string(json_req))

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 201 {
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in create repo"
		return errors.New(errmsg)
	}

}

func checkUserIsACollaborator(userName string, repoName string) error {
	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")

	resp, err := initGitHttpReq("GET", "/repos/"+ORG_TEAM+"/"+repoName+"/collaborators/"+userName, `{}`)

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 204 {
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in add user to collaborator"
		return errors.New(errmsg)
	}

}

func addUserToTeam(userName string, gitTeam string) error {

	godotenv.Load(".env")

	log.Println("Team id: ", gitTeam)
	resp, err := initGitHttpReq("PUT", "/teams/"+gitTeam+"/members/"+userName, `{}`)

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 204 {
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in add user to team"
		return errors.New(errmsg)
	}
}

func AddUserToRepo(userName, repoName, repoPermission string) error {
	// if true {
	// 	return nil
	// }
	return addUserToRepo(userName, repoName, repoPermission)
}

func addUserToRepo(userName, repoName, repoPermission string) error {
	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")

	data := make(map[string]interface{})

	if repoPermission == "write" {
		repoPermission = "push"
	}

	if repoPermission == "read" {
		repoPermission = "pull"
	}

	data["permissions"] = repoPermission

	json_req, _ := json.Marshal(data)

	resp, err := initGitHttpReq("PUT", "/repos/"+ORG_TEAM+"/"+repoName+"/collaborators/"+userName, string(json_req))

	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode == 201 || resp.StatusCode == 204 {
		return nil

	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in add user to repo"
		return errors.New(errmsg)
	}

}

func getGitRepoIdByName(repoName string) (int, error) {

	var repo repoGit
	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")

	resp, err := initGitHttpReq("GET", "/repos/"+ORG_TEAM+"/"+repoName, `{}`)

	if err != nil {
		return 0, err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}

	json.Unmarshal(body, &repo)

	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		return repo.ID, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get repo id by name"
		return 0, errors.New(errmsg)
	}
}

func getOrgsPlan() (orgsDatas, error) {
	var orgsData orgsDatas

	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")

	resp, err := initGitHttpReq("GET", "/orgs/"+ORG_TEAM, `{}`)

	if err != nil {
		return orgsData, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return orgsData, err
	}
	json.Unmarshal(body, &orgsData)
	//fmt.Println(teams)

	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		return orgsData, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get orgs plan"
		return orgsData, errors.New(errmsg)
	}
}

func getAllOgnTeam() (gitTeams, error) {
	var teams gitTeams

	godotenv.Load(".env")

	ORG_TEAM := os.Getenv("ORG_TEAM")

	resp, err := initGitHttpReq("GET", "/orgs/"+ORG_TEAM+"/teams?per_page=200", `{}`)

	if err != nil {
		return teams, err
	}

	//respBody, err := ioutil.ReadAll(resp.Body)

	// fmt.Printf("Response: \n %s", respBody)

	// if err != nil {
	// 	return ognTeams, err
	// }

	// //anw data receied is like that [a, b, c, d, e ,f]
	// jsonDataName := gjson.GetBytes(respBody, "name")

	// jsonDataId := gjson.GetBytes(respBody, "id")

	// err = json.NewDecoder(resp.Body).Decode(&teams)
	// if err != nil {
	// 	panic(err)
	// }

	body, err := ioutil.ReadAll(resp.Body)

	json.Unmarshal(body, &teams)
	//fmt.Println(teams)

	defer resp.Body.Close()

	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		return teams, nil
	} else {

		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get orgs team"
		return teams, errors.New(errmsg)
	}
}

func initGitHttpReq(method string, querryCmd string, readerInput string) (*http.Response, error) {

	var httpResp *http.Response
	godotenv.Load(".env")

	apiUrl := os.Getenv("GIT_ENDPOINT")
	querryCommmand := apiUrl + querryCmd

	fmt.Printf(querryCommmand)

	accessKey := os.Getenv("GIT_TOKEN_KEY")

	//fmt.Printf(readerInput)

	client := &http.Client{Timeout: 10 * time.Second}

	reader := strings.NewReader(readerInput)

	request, err := http.NewRequest(method, querryCommmand, reader)

	if err != nil {
		fmt.Println(err)
		return httpResp, errors.New("could not run request to http")
	}

	//var bearer = "token " + accessKey

	request.Header.Add("Authorization", accessKey)

	//fmt.Println(request.Header)
	//request.SetBasicAuth("xuancanTiki", accessKey)
	request.Header.Add("Content-Type", "application/json; charset=UTF-8")
	request.Header.Add("Accept", "application/json")

	httpResp, err = client.Do(request)

	if err != nil {
		fmt.Println(err.Error())
		return httpResp, errors.New("could not run request to git, please check connection")
	}

	return httpResp, nil
}
