package kong

import (
	"slack-bot/common"

	"github.com/slack-go/slack"
)

func GetKongBlock(routerNumber int) (slack.MsgOption, error) {

	//blockResp := slack.NewActionBlock("kong_input", svcBlockElm)

	headerSvcText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\nPlease choose connection", false, false)
	headerSvcSection := slack.NewSectionBlock(headerSvcText, nil, nil)

	input := []string{"api.tala.xyz", "api.s14e.dev", "milo.tala.xyz", "api-sellercenter.tala.xyz"}

	selectConnection, err := common.GetSelectedOptionMultiInputBlock(input, input[0], "Choose connection", "kong_choose_conn", "")

	if err != nil {
		println(err)
	}

	selectConnectionBlock := slack.NewActionBlock("kong_choose_conn", selectConnection)

	svcNameInputBlock := common.GetTxtInputBlock("svc_name_input", "Enter service name:", "Example: Should be api-astra-v1")

	svcInputBlock := common.GetTxtInputBlock("svc_input", "Service path, set protocol http and port 80 by default", "Ex: http://zorba.services/v1/golden")

	firstRouteInputBlock := common.GetTxtInputBlock("first_route_input", "Enter route path, set protocol http, https by default:", "Ex: /v1/golden")

	firstRouteMethodInputBlock := common.GetTxtInputBlock("first_method_route_input", "Enter method route:", "Ex: get, put, post")

	//button approve
	actionBlock := common.GetButtonBlock("submit_kong", "Approve", "submit")

	block := slack.MsgOptionBlocks(
		headerSvcSection,
		selectConnectionBlock,
		svcNameInputBlock,
		svcInputBlock,
		firstRouteInputBlock,
		firstRouteMethodInputBlock,
		actionBlock,
	)

	// if routerNumber == 2 {

	// 	secondRouteNameInputBlock := common.GetTxtInputBlock("second_route_name_input", "Enter second route name:", "Ex: api_astra_v2")

	// 	secondRouteInputBlock := common.GetTxtInputBlock("second_route_input", "Enter second route path, set protocol http, https by default:", "Ex: /v2/golden")

	// 	secondRouteMethodInputBlock := common.GetTxtInputBlock("second_method_route_input", "Enter method route path:", "Ex: get, put, post")

	// 	block = slack.MsgOptionBlocks(
	// 		headerSvcSection,
	// 		svcNameInputBlock,
	// 		svcInputBlock,
	// 		firstRouteNameInputBlock,
	// 		firstRouteInputBlock,
	// 		firstRouteMethodInputBlock,
	// 		secondRouteNameInputBlock,
	// 		secondRouteInputBlock,
	// 		secondRouteMethodInputBlock,
	// 		actionBlock,
	// 	)
	// }

	return block, nil
}
