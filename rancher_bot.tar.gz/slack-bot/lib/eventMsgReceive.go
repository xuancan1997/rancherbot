package lib

import (
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"slack-bot/github"
	"slack-bot/rancher"
	"strconv"

	"github.com/slack-go/slack"
	"github.com/slack-go/slack/slackevents"
)

const red = "#eb4034"
const green = "#35fc03"
const blue = "#0c17e8"

var permissionList = map[string]bool{
	"read":     true,
	"write":    true,
	"admin":    true,
	"maintain": true,
}

var templateTextMsg = map[string]func(input []string, event *slackevents.MessageEvent, client *slack.Client) error{
	"^set git username (\\S+)":      setUsernameGit,
	"^set (\\S+) to repo (\\S+)":    addUserToRepo,
	"^set manager (\\S+)":           setManager,
	"^new git repo (\\S+)":          createNewGitRepo,
	"^manage (\\S+) (\\S+) -d (.*)": manageWorkload,
}

var attachment slack.Attachment

func manageWorkload(match []string, event *slackevents.MessageEvent, client *slack.Client) error {
	workload := match[1]
	hour := match[2]
	description := match[3]
	hourToInt, err := strconv.Atoi(hour)
	if err != nil {
		return err
	}

	if hourToInt > 4 || hourToInt < 1 {
		return fmt.Errorf("manage hour cannot greater than 4 or smaller than 1")
	}

	userSlack, err := client.GetUserInfo(event.User)

	if err != nil {
		return err
	}

	//check set git data
	userNameGit := github.GetUserGitName(userSlack.ID)
	if userNameGit == "" {
		return fmt.Errorf("cannot get git Username for user %s, you may need to set it first with command `set git username <gitUsername>`", userSlack.Name)
	}

	//get deployment profile
	rancherData, err := rancher.GetDeploymentWithDeploymentName(workload)
	if err != nil {
		return err
	}

	INFRA_CHANNEL_ID := os.Getenv("INFRA_CHANNEL_ID")

	manageConfig := ""
	if description == "Manage-Configmaps" {
		manageConfig = "Tiki Manage Workloads Configmaps"
	} else {
		manageConfig = "Tiki Developer (Manage workloads)"
	}

	attachment.Color = blue

	//clusterID, err := rancher.GetClusterIdWithClusterName(rancherData.ClusterName)

	// if err != nil {
	// 	return err
	// }

	//log.Println("Cluster ID: ", clusterID, rancherData.ProjectName, rancherData.ProjectID)

	project, err := rancher.GetProjectWithProjectID(rancherData.ProjectID)

	log.Printf("Current project %+v", project)
	if err != nil {
		return err
	}

	if managerList[userSlack.Name] {
		//send data to infras

		textSendToInfra := fmt.Sprintf(".rancher grant %s | %s | %s | %s | %s", rancherData.ClusterName, project.Name, userNameGit, manageConfig, hour)
		log.Println(textSendToInfra)

		client.PostMessage(INFRA_CHANNEL_ID, slack.MsgOptionText(textSendToInfra, false))

		client.PostMessage(userSlack.ID, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: "Your request have been send to infras team, you can manage your workload now"}))
		return nil
	} else {
		//send information to user

		userManager, err := common.GetUserManagerID(userSlack.ID)

		if userManager == "" {
			return fmt.Errorf("cannot get your manager, you may need to add him first with command `set manager <managerSlackName>`, example: `set manager phong.huynh`")
		}

		if !managerList[userManager] {
			return fmt.Errorf("your manager %s is not added to manager list, please call systemoi to add him", userManager)
		}
		if err != nil {
			return err
		}
		attachment.Color = blue
		attachment.Pretext = fmt.Sprintf("Sent request to your manager %s", userManager)
		attachment.Text = fmt.Sprintf("Request send: Manage workload %s for %s\nDescription: %s", workload, hour, description)
		client.PostMessage(userSlack.ID, slack.MsgOptionAttachments(attachment))

		//send infor to manager
		preText := fmt.Sprintf("New request manage workload from `%s` :tamtu:", userSlack.Name)
		text := fmt.Sprintf("*Workload:* `%s` \t*Time:* `%s` hour\n*Description:* `%s`", workload, hour, description)

		manageType := "normal"
		if manageConfig == "Tiki Manage Workloads Configmaps" {
			manageType = "manage-configmaps"
		}
		workloadManageAttachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "manager-approve-manage-wl", "manager-approve-manage-wl", fmt.Sprintf("%s %s %s %s %s", rancherData.ClusterName, project.Name, userSlack.ID, manageType, hour), "deny_common", true)

		if err != nil {
			return err
		}

		managerProfile, err := client.GetUserByEmail(fmt.Sprintf("%s@tiki.vn", userManager))

		if err != nil {
			return err
		}

		client.PostMessage(managerProfile.ID, slack.MsgOptionAttachments(workloadManageAttachment))

		return nil
	}
}

func createNewGitRepo(match []string, event *slackevents.MessageEvent, client *slack.Client) error {
	repoName := match[1]
	userSlack, err := client.GetUserInfo(event.User)
	if err != nil {
		return err
	}
	//check repo Exist
	if github.CheckRepoExist(repoName) {
		return fmt.Errorf("repo %s already exist", repoName)
	}

	//check user has user git
	err = github.CheckExistUserGitName(userSlack.ID)

	if err != nil {
		return err
	}

	//set default permission of user request is write
	defaultPermission := "write"

	if managerList[userSlack.Name] {
		//post msg to systemoi
		preText := "New Create Git Repo Request"
		text := fmt.Sprintf("<!subteam^SVALNFK27> User `%s` requests to create repo `%s`", userSlack.Name, repoName)
		attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "create-new-git-repo", "create-new-git-repo", fmt.Sprintf("%s %s %s", repoName, defaultPermission, userSlack.ID), "deny_common", true)
		if err != nil {
			log.Println(err)
		}

		CHANNEL := os.Getenv("CHANNEL_ID")

		client.PostMessage(CHANNEL, slack.MsgOptionAttachments(attachment))

		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: blue, Text: "Sent request to your systemoi, please wait for approving..."}))
		return nil
	} else {
		userManagerName, err := common.GetUserManagerID(event.User)

		log.Println("Manager is", userManagerName)
		if err != nil {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		}

		if userManagerName == "" {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: "Cannot find your manager ID, you may need to add him first with command below:\n`set manager <manager>` \nexample: `set manager trung.nguyenbao`"}))
			return nil
			//userManagerID = event.User
		}

		//post msg to manager
		preText := "New Create Repo Github Request:"
		text := fmt.Sprintf("User `%s` requests to create repo `%s`", userSlack.Name, repoName)
		attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "send-manager-create-repo", "send-manager-create-repo", fmt.Sprintf("%s %s %s", repoName, defaultPermission, userSlack.ID), "deny_common", true)
		if err != nil {
			log.Println(err)
		}

		managerUser, err := client.GetUserByEmail(fmt.Sprintf("%s@tiki.vn", userManagerName))

		if err != nil {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
			return nil
		}
		client.PostMessage(managerUser.ID, slack.MsgOptionAttachments(attachment))

		//send msg back to user
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: blue, Text: "Sent request to your manager, please wait for approving..."}))
	}

	return nil
}

func setManager(match []string, event *slackevents.MessageEvent, client *slack.Client) error {

	if !managerList[match[1]] {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: fmt.Sprintf("Your manager %s is not added into manager list, please tell systemoi to add him", match[1])}))
		return nil
	}
	err := common.SetManagerToUser(match[1], event.User, client)

	if err != nil {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		return nil
	}

	client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: fmt.Sprintf("Now your manager is set to %s, have fun :quay_nhe:", match[1])}))

	return nil
}

func setUsernameGit(match []string, event *slackevents.MessageEvent, client *slack.Client) error {

	err := github.SetGitUserName(match[1], event.User)

	if err != nil {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		return nil
	}

	client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: fmt.Sprintf("Now your git username is set to %s, have fun :quay_nhe:", match[1])}))

	return nil
}

func addUserToRepo(match []string, event *slackevents.MessageEvent, client *slack.Client) error {

	//err := github.AddUserToRepo(match[1], event.User)
	permission := match[1]

	//check permission ok
	if !permissionList[permission] {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: "permission input not correct!!!, permission avaiable is: `read, write or admin`"}))
		return nil
	}

	repoName := match[2]

	if err := github.CheckUserAddToRepo(match[2], event.User); err != nil {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		return nil
	}

	userGitName := github.GetUserGitName(event.User)
	//post msg is manager
	//log.Printf("user create event is %+v", event)

	userSlack, err := client.GetUserInfo(event.User)
	if err != nil {
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		return nil
	}

	if managerList[userSlack.Name] {
		//post msg to systemoi
		preText := "New GitHub Request"
		text := fmt.Sprintf("User `%s` requests to access repo `%s` with permission `%s`", userSlack.Name, repoName, permission)
		attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "add-user-to-repo", "add-user-to-repo", fmt.Sprintf("%s %s %s %s", repoName, userGitName, permission, userSlack.ID), "deny_common", true)
		if err != nil {
			log.Println(err)
		}

		CHANNEL := os.Getenv("CHANNEL_ID")

		client.PostMessage(CHANNEL, slack.MsgOptionAttachments(attachment))

		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: blue, Text: "Sent request to your systemoi, please wait for approving..."}))
		return nil
	} else {

		if err := github.CheckUserAddToRepo(match[2], event.User); err != nil {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
			return nil
		}

		userManagerName, err := common.GetUserManagerID(event.User)

		log.Println("Manager is", userManagerName)
		if err != nil {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		}

		if userManagerName == "" {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: "Cannot find your manager ID, you may need to add him first with command below:\n`set manager <manager>` \nexample: `set manager trung.nguyenbao`"}))
			return nil
			//userManagerID = event.User
		}

		//post msg to manager
		preText := "New Github Request:"
		text := fmt.Sprintf("User `%s` requests to access repo `%s` with permission `%s`", userSlack.Name, repoName, permission)
		attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "send-manager-add-repo", "send-manager-add-repo", fmt.Sprintf("%s %s %s %s", repoName, userGitName, permission, userSlack.ID), "deny_common", true)
		if err != nil {
			log.Println(err)
		}

		managerUser, err := client.GetUserByEmail(fmt.Sprintf("%s@tiki.vn", userManagerName))

		if err != nil {
			client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
			return nil
		}
		client.PostMessage(managerUser.ID, slack.MsgOptionAttachments(attachment))
		//send msg back to user
		client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: blue, Text: "Sent request to your manager, please wait for approving..."}))
		return nil
	}

}
