package rancher

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"slack-bot/common"
	"strconv"
	"strings"
	"time"

	"github.com/jedib0t/go-pretty/table"
	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/slack-go/slack/socketmode"
	"github.com/spf13/viper"
)

type ScaleDownProfile struct {
	Enable       bool
	CurrentEvent string
}

const (
	YYYYMMDD = "2006-01-02"
)

func getStatefulSetWithProjectID(projectID string, statefulSetName string, namespaceID string) (RancherDeployment, error) {
	var statefulSets RancherDeployment

	//log.Println("Project id", projectID, deploymentName, namespaceID)
	var err error
	var resp *http.Response
	if statefulSetName == "" || namespaceID == "" {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/statefulsets", `{}`)
	} else {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/statefulsets?name="+statefulSetName+"&namespaceId="+namespaceID, `{}`)
	}

	if err != nil {
		return statefulSets, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return statefulSets, err
	}
	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &statefulSets)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(hpas)
	if resp.StatusCode == 200 {
		return statefulSets, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get deployment " + statefulSetName
		return statefulSets, errors.New(errmsg)
	}
}

func scalePods(scale, deployment string) error {

	if strings.Contains(scale, "-") {

	}

	return nil
}

//becauseof rancher 502 problem, need to retry...
func RetryFunction(input string, numberRetry int, timeout int) error {
	var err error
	for i := 0; i < numberRetry; i++ {

		if input == "update google data" {
			err = HandleGoogleSheetUpdateData()
		}

		if err == nil {
			time.Sleep(time.Duration(timeout) * time.Second)
		}
		if err == nil {
			break
		}
	}

	return nil
}

func checkUserManageWLProfile(deploymentName, userID string) (ManageWLProfile, error) {
	var manageProfile ManageWLProfile

	manageProfile.DeploymentName = deploymentName
	manageProfile.UserRequest = userID

	godotenv.Load(".env")
	file_name := os.Getenv("MANAGE_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return manageProfile, errors.New("cannot get file, create new one")
	}

	value := v.GetString(userID + "-" + deploymentName)

	//if empty, need to add new
	if value == "" {
		return manageProfile, nil
	}

	valueSplit := strings.Split(value, "|")

	manageProfile.Cluster = valueSplit[0]
	manageProfile.ProjectName = valueSplit[1]
	manageProfile.Manager = valueSplit[2]
	manageProfile.UserNameGit = valueSplit[3]

	return manageProfile, nil
}

func ResetUserSelfRedeploy() error {

	godotenv.Load(".env")
	file_name := os.Getenv("REDEPLOY_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		return errors.New("cannot get file " + file_name)
	}

	keys := v.AllKeys()

	MAX_TIME_DEPLOY_PER_DAY := os.Getenv("MAX_TIME_DEPLOY_PER_DAY")
	log.Println("Total key:", len(keys), file_name, path)

	for key := range keys {
		v.Set(keys[key], MAX_TIME_DEPLOY_PER_DAY)
	}

	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	return nil
}

func checkTimeValid(typeCheck string) error {
	godotenv.Load(".env")
	currentHour := time.Now().Local().Hour()

	if typeCheck == "user redeploy" {

		allowStartTime := os.Getenv("USER_DEPLOY_START_TIME")
		allowEndTime := os.Getenv("USER_DEPLOY_END_TIME")

		startTime, err := strconv.Atoi(allowStartTime)
		if err != nil {
			return err
		}

		endTime, err := strconv.Atoi(allowEndTime)
		if err != nil {
			return err
		}

		//if in time, go process

		if currentHour >= startTime && currentHour <= endTime {
			return nil
		} else {
			return errors.New("you cannot do this action at this time, allow time to deploy is `" + strconv.Itoa(startTime) + "-" + strconv.Itoa(endTime) + "`")
		}
	}

	return nil
}

func getTimeAllowUser() (int, int, error) {
	godotenv.Load(".env")
	file_name := os.Getenv("CHAT_TO_BOT_CONF")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return 0, 0, errors.New("cannot get file, create new one")
	}

	startTime := v.GetString("allow_start_deploy_time")
	endTime := v.GetString("allow_end_deploy_time")

	startTimeToInt, err := strconv.Atoi(startTime)

	if err != nil {
		return 0, 0, err
	}

	endTimeToInt, err := strconv.Atoi(endTime)

	if err != nil {
		return 0, 0, err
	}
	return startTimeToInt, endTimeToInt, nil
}

func writeNewAddRedeploy(data string) error {

	godotenv.Load(".env")
	file_name := os.Getenv("REDEPLOY_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return errors.New("cannot get file, create new one")
	}
	dataSplit := strings.Split(data, " ")
	user := dataSplit[0]
	deployment := dataSplit[1]

	maxTimeDeployPerDay := os.Getenv("MAX_TIME_DEPLOY_PER_DAY")
	v.Set(user+"-"+deployment, maxTimeDeployPerDay)
	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil
}

func sendDataChanged(client *slack.Client, hpaList []Data, deploymentList []Deployment) error {

	attachment := slack.Attachment{}

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	t.AppendHeader(table.Row{"Deployment", "Old Scale", "New Scale"})
	//create table

	for _, data := range hpaList {
		//log.Printf("%v", data)
		t.AppendRow([]interface{}{data.Name, data.CurrentMinReplicas + "-" + data.CurrentMaxReplicas, data.ReplicaData})
	}

	for _, deploy := range deploymentList {
		//log.Printf("%v", deploymentList)
		t.AppendRow([]interface{}{deploy.Name, deploy.DesiredReplicas, deploy.Scale})
	}

	response := "```" + t.Render() + "```"

	attachment.Pretext = "Data scale changed: "
	attachment.Text = response
	attachment.Color = "#00cc00"

	CHANNALE_ID := os.Getenv("CHANNEL_ID")
	_, _, err := client.PostMessage(CHANNALE_ID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		return err
	}
	return nil
}

func startReducePodsWithProfile(client *slack.Client, scaleProfile ScaleDownProfile, scaleType string) ([]Data, []Deployment, error) {
	//load file
	godotenv.Load(".env")
	var hpaList []Data
	var deploymentList []Deployment
	//if not apply for scale -> return nil
	if scaleProfile.Enable == false {
		CHANNEL_ID := os.Getenv("CHANNEL_ID")
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Currently, scale optimize cost is not enable", false))
		return hpaList, deploymentList, nil
	}

	file_name := os.Getenv("SCALE_DOWN_INFO")
	path := os.Getenv("SCALE_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return hpaList, deploymentList, errors.New("cannot get file, create new one")
	}

	var scaleOpName string

	if scaleType == "reduce cost" {
		scaleOpName = strings.TrimSpace(os.Getenv("SCALE_OP_HEADER_NAME"))
	} else if scaleType == "reduce cost 2" {
		scaleOpName = strings.TrimSpace(os.Getenv("SCALE_OP_2_HEADER_NAME"))
	}

	scaleNormalName := strings.TrimSpace(os.Getenv("SCALE_NORMAL_HEADER_NAME"))

	if scaleOpName == "" && scaleNormalName == "" {
		return nil, nil, errors.New("error when getting header optimize cost")
	}
	log.Println(scaleOpName)

	log.Println(scaleProfile)

	currentDate := time.Now().UTC().Format(YYYYMMDD)
	log.Println("Current date ", currentDate)
	retry := 0

	if scaleType == "normal" {

		log.Println("Scale with header ", scaleNormalName)
		for {
			hpaList, deploymentList, err = HandleScaleEventData(scaleNormalName)

			log.Println("scale error is ", err)
			if err != nil {
				retry++
				log.Println("Scale error, retry ", retry)
				time.Sleep(300 * time.Second)
			} else {
				break
			}
			if retry == 3 {
				return hpaList, deploymentList, err
			}
		}

	} else if strings.HasPrefix(scaleType, "reduce cost") {

		for {
			hpaList, deploymentList, err = HandleScaleEventData(scaleOpName)

			if err != nil {
				retry++
				log.Println("Scale error, retry ", retry)
				time.Sleep(300 * time.Second)
			} else {
				break
			}
			if retry == 3 {
				return hpaList, deploymentList, err
			}
		}
	}

	//log.Println(hpaList, deploymentList)
	return hpaList, deploymentList, nil
}

func getScaleDownProfile() (ScaleDownProfile, error) {

	godotenv.Load(".env")
	var scaleProfile ScaleDownProfile
	file_name := os.Getenv("SCALE_DOWN_INFO")
	path := os.Getenv("SCALE_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return scaleProfile, errors.New("cannot get file, create new one")
	}

	// saveCostStartTime := strings.TrimSpace(v.GetString("save_cost_start_time"))
	// isEmpty := false
	// if saveCostStartTime == "" {
	// 	isEmpty = true
	// 	v.Set("save_cost_start_time", -99)
	// }
	// startTime, err := strconv.Atoi(saveCostStartTime)
	// if err != nil || startTime < 0 {
	// 	log.Println("cannot get start time")
	// 	return scaleProfile, err
	// }
	// saveCostEndTime := strings.TrimSpace(v.GetString("save_cost_end_time"))
	// if saveCostEndTime == "" {
	// 	isEmpty = true
	// 	v.Set("save_cost_end_time", -99)
	// }
	// endTime, err := strconv.Atoi(saveCostEndTime)
	// if err != nil || endTime < 0 {
	// 	log.Println("cannot get end time")
	// 	return scaleProfile, err
	// }
	// dateRunScaleNormal := strings.TrimSpace(v.GetString("date_run_scale_normal"))
	// if dateRunScaleNormal == "" {
	// 	isEmpty = true
	// 	v.Set("date_run_scale_normal", "1990-1-1")
	// }
	// dateRunScaleOptimize := strings.TrimSpace(v.GetString("date_run_scale_optimize"))
	// if dateRunScaleOptimize == "" {
	// 	isEmpty = true
	// 	v.Set("date_run_scale_optimize", "1990-1-1")
	// }
	// numberRunScaleNormal := strings.TrimSpace(v.GetString("number_run_scale_normal"))
	// if numberRunScaleNormal == "" {
	// 	isEmpty = true
	// 	v.Set("number_run_scale_normal", "0")
	// }
	// numberRunScaleNormalToInt, err := strconv.Atoi(numberRunScaleNormal)
	// if err != nil {
	// 	log.Println("cannot get numberRunScaleNormalToInt ")
	// 	return scaleProfile, err
	// }
	// NumberRunScaleOptimize := strings.TrimSpace(v.GetString("number_run_scale_optimize"))
	// if numberRunScaleOptimize == "" {
	// 	isEmpty = true
	// 	v.Set("number_run_scale_optimize", "0")
	// }
	// numberRunScaleOptimizeToInt, err := strconv.Atoi(numberRunScaleOptimize)
	// if err != nil {
	// 	log.Println("cannot get numberRunScaleOptimizeToInt ")
	// 	return scaleProfile, err
	// }
	// saveCostEnable := strings.TrimSpace(v.GetString("save_cost_enable"))
	// if saveCostEnable == "" {
	// 	isEmpty = true
	// 	v.Set("save_cost_enable", "false")
	// }
	// if isEmpty {
	// 	//write to file
	// 	v.WriteConfig()
	// 	//if file not exist, not write
	// 	v.WriteConfigAs(path + file_name)
	// }
	// log.Println("Start job time and end time is ", startTime, endTime)
	// scaleProfile.StartTime = startTime
	// scaleProfile.EndTime = endTime
	// log.Println("Save cost ", saveCostEnable)
	// if saveCostEnable == "true" {
	// 	scaleProfile.Enable = true
	// } else {
	// 	scaleProfile.Enable = false
	// }
	// scaleProfile.DateRunScaleNormal = dateRunScaleNormal
	// scaleProfile.DateRunScaleOptimize = dateRunScaleOptimize
	// scaleProfile.NumberRunScaleNormal = numberRunScaleNormalToInt
	// scaleProfile.NumberRunScaleOptimize = numberRunScaleOptimizeToInt

	enableOptimize := strings.TrimSpace(v.GetString("save_cost_enable"))

	if enableOptimize == "true" {
		scaleProfile.Enable = true
	}

	scaleProfile.CurrentEvent = strings.TrimSpace(v.GetString("current_event_running"))

	return scaleProfile, nil
}

func GetDeploymentWithDeploymentName(deploymentName string) (Data, error) {
	godotenv.Load(".env")
	var deployment Data
	file_name := os.Getenv("DEPLOYMENT_FIND_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return deployment, errors.New("file not exist, create an empty file")
	}

	keys := v.AllKeys()

	log.Println("Total key:", len(keys), file_name, path)

	for _, key := range keys {

		splitKey := strings.Split(key, "@")

		if len(splitKey) != 6 {
			return deployment, errors.New("key is not correct form, need to update")
		}

		//log.Println(splitKey[3])

		if splitKey[3] == deploymentName {

			deployment.ClusterName = splitKey[0]
			deployment.ProjectName = splitKey[1]
			deployment.NamespaceId = splitKey[2]
			deployment.Name = splitKey[3]
			deployment.ProjectID = splitKey[4]

			break
		}
	}

	if deployment.ClusterName == "" {
		return deployment, errors.New("deployment not found")
	}

	return deployment, nil
}

func HandleVerifedConsoleInput(client *slack.Client, channelID, timeStamp, input string) error {
	log.Println("user verify", input)

	if len(strings.Split(input, "\n")) != 1 {
		return errors.New("cannot handle more than 1 line")
	}

	INFRA_CHANNEL_ID := os.Getenv("INFRA_CHANNEL_ID")
	_, _, err := client.PostMessage(INFRA_CHANNEL_ID, slack.MsgOptionText(input, true))

	if err != nil {
		return err
	}

	return nil
}

func HandleSearchConsoleInput(client *slack.Client, channelID, timeStamp, input string) error {

	log.Println("user input ", input)

	infraConsole := os.Getenv("INFRA_CHANNEL_ID")
	param := slack.SearchParameters{
		Sort:  "timestamp",
		Count: 5,
	}

	//need user token to search message, so create new client
	appToken := os.Getenv("SLACK_APP_TOKEN")

	if appToken == "" {
		return errors.New("SLACK_APP_TOKEN must be set.")
	}
	botToken := os.Getenv("SLACK_USER_TOKEN")

	if botToken == "" {
		return errors.New("SLACK_BOT_TOKEN must be set.")
	}

	api := slack.New(
		botToken,
		slack.OptionDebug(false),
		slack.OptionAppLevelToken(appToken),
		slack.OptionLog(log.New(os.Stdout, "api: ", log.Lshortfile|log.LstdFlags)),
	)

	client2 := socketmode.New(
		api,
		socketmode.OptionDebug(false),
		socketmode.OptionLog(log.New(os.Stdout, "socketmode: ", log.Lshortfile|log.LstdFlags)),
	)

	inputSplit := strings.Split(input, "\n")

	if len(inputSplit) == 0 {
		return errors.New("input is empty")
	}

	for _, dataInput := range inputSplit {
		var inputSearch string
		var keyType int
		var userCheck string
		if strings.HasPrefix(dataInput, "/home/") {
			if strings.Contains(dataInput, " ") {
				//ignore data has spaces
				continue
			}

			splitInput := strings.Split(dataInput, "/")
			userCheck = splitInput[2]
			inputSearch = splitInput[0] + "/" + splitInput[1] + "/" + splitInput[2] + "/"
			log.Println("Search with ", inputSearch)
			//is genfile
			keyType = 2
		} else {
			inputSearch = dataInput
			if strings.Contains(dataInput, " ") {
				//ignore data has spaces
				return errors.New("Input cannot have any spaces")
			}
			//is deployment
			keyType = 4
		}

		datas, err := client2.SearchMessages(inputSearch+" in:infra-console", param)

		if err != nil {
			return err
		}
		listData := datas.Matches

		//verify listData again for wrong input user typed

		attachment := slack.Attachment{}
		if len(listData) == 0 {

			attachment.Text = "Empty matches with " + dataInput
			attachment.Color = "#ff0000"

			if strings.Contains(dataInput, "/home/") {
				attachment.Pretext = "Msg sent to infra-consle: .hera checkuser " + userCheck
				_, _, err = client.PostMessage(infraConsole, slack.MsgOptionText(".hera checkuser "+userCheck, true))
				if err != nil {
					return err
				}

			} else {
				attachment.Pretext = "Bot response: "
			}

			_, _, err = client.PostMessage(channelID, slack.MsgOptionTS(timeStamp), slack.MsgOptionAttachments(attachment))

			if err != nil {
				return err
			}

			return nil

		}
		//var listCmd []string

		cmdMaps := make(map[string]*CmdStruct)

		for _, data := range listData {

			key := ""
			value := ""
			if data.Username == "tifa" {
				continue
			}

			if !strings.Contains(data.Text, "grant") {
				if !strings.Contains(data.Text, "/home/") {
					continue
				}
			}
			splitData := strings.Split(data.Text, " ")

			//log.Println(splitData)
			for i := range splitData {

				//get key
				if i <= keyType {

					key += splitData[i] + " "
				}

				//get value
				if i > keyType {

					value += splitData[i] + " "
				}

			}

			tmpCmd := new(CmdStruct)

			tmpCmd.Command = key
			tmpCmd.Value = value

			verifyData := strings.TrimSpace(key + value)

			if strings.HasPrefix(verifyData, ".hera genfile") {

				//if format not correct as
				//.hera genfile team /home/name/Untitled.csv name
				log.Println("Verify data", verifyData)

				if len(strings.Split(strings.TrimSpace(key), " ")) != 3 {
					continue
				}

				if len(strings.Split(strings.TrimSpace(value), " ")) != 2 {
					continue
				}

				if len(strings.Split(verifyData, " ")) != 5 {
					continue
				}
			} else if strings.HasPrefix(verifyData, ".rancher grant") {
				//.rancher grant cluster | Ns | name | role | hour
				if len(strings.Split(verifyData, "|")) != 5 {
					continue
				}
			} else {
				continue
				//return errors.New("input is wrong format")
			}

			cmdMaps[key] = tmpCmd

		}

		var listOption []string
		for data := range cmdMaps {
			key := cmdMaps[data].Command

			if key == "" {
				continue
			}
			log.Println("Value key", key)
			value := ""
			splitDataInput := strings.Split(dataInput, "/")

			log.Println("Log key is", key)
			if !strings.HasPrefix(key, ".hera genfile ") {

				if !strings.HasPrefix(key, ".rancher grant") {
					return errors.New("data input has wrong format, please check")
				} else {
					value = cmdMaps[data].Value
				}
			} else {
				if len(splitDataInput) != 4 {
					return errors.New("data input for genfile has wrong format, please check")
				}

				value = dataInput + " " + splitDataInput[2]
			}

			if strings.Contains(key, "genfile") {

				if strings.Contains(key, "/home/") && !strings.Contains(value, "/home/") {
					continue
				}

				log.Println("Key is", key)
				log.Println("Value is", value)
				value = dataInput + " " + strings.Split(value, " ")[1]

				listOption = append(listOption, key+value)

			}

			if strings.Contains(key, "grant") {
				listOption = append(listOption, key+value)
				//log.Println(key + value)
			}
		}

		if len(listOption) == 0 {
			return errors.New("notthing to do with length = 0")
		}

		if len(listOption) == 1 && strings.Contains(listOption[0], "genfile") {

			//send msg to channel
			_, _, err = client.PostMessage(infraConsole, slack.MsgOptionText(listOption[0], false))

			if err != nil {
				log.Println(err)
				return err
			}

			attachment.Text = listOption[0]
			attachment.Color = "#34eb5b"
			attachment.Pretext = "Msg sent to infra-consle: "

			log.Println("Log send", listOption[0])
			_, _, err = client.PostMessage(channelID, slack.MsgOptionTS(timeStamp), slack.MsgOptionAttachments(attachment))
			if err != nil {
				log.Println(err)
				return err
			}

		} else {

			inputBlock := common.GetMultiLinesInputBlockWithInitOption("data_search_sent_to_channel", "Value found:", "Lazy", strings.Join(listOption, "\n"))

			approveBtnTxt := slack.NewTextBlockObject("plain_text", "Sent to infra-console", false, false)
			approveBtn := slack.NewButtonBlockElement("data_search_sent_to_channel_btn", "submit", approveBtnTxt)

			actionBlock := slack.NewActionBlock("data_search_sent_to_channel_btn", approveBtn)
			msg := slack.MsgOptionBlocks(
				inputBlock,
				actionBlock,
			)

			_, _, err = client.PostMessage(channelID, slack.MsgOptionTS(timeStamp), msg)

			if err != nil {
				log.Println(err)
				return err
			}

		}
	}

	//log.Println(data)
	return nil
}

func getMsgSearchOption(listOption []string) (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	chooseElm, err := common.GetSelectedOptionBlock(listOption, listOption[0], "select an option", "search_option_choose", "")

	chooseSearchAction := slack.NewActionBlock("select_search_ac", chooseElm)

	if err != nil {
		return msg, err
	}
	// textBlockObject := slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	// op := slack.NewOptionBlockObject("approved", textBlockObject, nil)

	// checkbox := slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm", op)

	// checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm", checkbox)
	btn := common.GetAprroveBtn("submit_searched_button")
	msg = slack.MsgOptionBlocks(
		headerSection,
		chooseSearchAction,

		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func GetSearchConsoleBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("search_console_input", "Enter search pattern", "Example:\n/home/xuan.can/test.csv\nxuancan-tiki")

	// textBlockObject := slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	// op := slack.NewOptionBlockObject("approved", textBlockObject, nil)

	// checkbox := slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm", op)

	// checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm", checkbox)
	btn := common.GetAprroveBtn("search_console_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,

		// checkBoxBlock,
		btn,
	)
	return msg, nil
}
