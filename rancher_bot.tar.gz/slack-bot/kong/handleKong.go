package kong

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/slack-go/slack"
)

type KongService struct {
	Connection  string
	svcName     string
	svcProtocol string
	svcHost     string
	svcPath     string
	svcPort     int
	kongRoutes  []KongRoutes
}

type KongRoutes struct {
	routeName     string
	routeHost     []string
	routePath     []string
	routeProtocol []string
	routeMethod   []string
}

func AddKongSvc(kongService KongService) error {

	querryCommmand := kongService.Connection + "/services"

	svcData := make(map[string]interface{})
	svcData["name"] = kongService.svcName
	svcData["protocol"] = kongService.svcProtocol
	svcData["host"] = kongService.svcHost
	svcData["port"] = kongService.svcPort
	svcData["path"] = kongService.svcPath

	json_req, _ := json.Marshal(svcData)

	fmt.Println(string(json_req))

	resp, err := initKongHttpReq("POST", querryCommmand, string(json_req))

	// TODO: check err
	fmt.Print(err)
	if err != nil {
		return err
	}

	defer resp.Body.Close()

	fmt.Println("Status code: ", resp.StatusCode)

	//respBody, err := ioutil.ReadAll(resp.Body)
	//log.Printf("Request %s", resp)
	//fmt.Printf(string(resp.Header)
	//fmt.Printf(string(respBody))

	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		fmt.Println("Add Service success with service name " + kongService.svcName)
		errCode := AddKongRoutes(kongService.kongRoutes, kongService.svcName, kongService.Connection)

		//just need 201
		if errCode == 201 || errCode == 200 {
			fmt.Println("Add routes success")
			return nil
		} else {
			fmt.Println("Add routes err")
			return err
		}
		//409 for duplicate service name
	} else if resp.StatusCode == 409 {
		return errors.New("unique constraint violation")
	} else {
		return errors.New("somethings when wrongs")

	}
}

func AddKongRoutes(kongRoutes []KongRoutes, svcName, svcConnection string) int {

	//fmt.Println("Number of routes: ", len(kongRoutes))

	for i := 0; i < len(kongRoutes); i++ {
		fmt.Println("Current i test ", i)
	}

	for i := 0; i < len(kongRoutes); i++ {

		fmt.Println("Current i ", i)
		querryCommmand := svcConnection + "/services/" + svcName + "/routes"
		data := make(map[string]interface{})

		data["name"] = kongRoutes[i].routeName
		data["protocols"] = kongRoutes[i].routeProtocol
		data["methods"] = kongRoutes[i].routeMethod

		//data["hosts"] = kongRoutes[i].routeHost
		data["paths"] = kongRoutes[i].routePath

		json_req, _ := json.Marshal(data)

		resp, err := initKongHttpReq("POST", querryCommmand, string(json_req))
		log.Println(resp.StatusCode)
		// TODO: check err

		if err != nil {
			return resp.StatusCode
		}

	}

	return 200
}

func GetKongData(blockAc map[string]map[string]slack.BlockAction) (KongService, error) {

	kongSvc, err := getKongSvc(blockAc)

	if err != nil {
		return kongSvc, err
	}

	kongRoutes, err := getKongRoutes(blockAc)

	if err != nil {
		return kongSvc, err
	}

	if len(kongRoutes) == 0 {
		err = errors.New("kongroute is empty")
		return kongSvc, err
	}

	kongSvc.kongRoutes = kongRoutes

	return kongSvc, nil
}

func getKongRoutes(blockAc map[string]map[string]slack.BlockAction) ([]KongRoutes, error) {

	var kongRoutes []KongRoutes

	firstRoute, err := getKongRoute(blockAc, "first")

	if err != nil {
		return kongRoutes, err
	}

	kongRoutes = append(kongRoutes, firstRoute)

	// if blockAc["second_route_name_input"]["second_route_name_input"].Value != "" {
	// 	secondRoute, err := getKongRoute(blockAc, "second")

	// 	if err != nil {
	// 		return kongRoutes, err
	// 	}

	// 	kongRoutes = append(kongRoutes, secondRoute)
	// }

	return kongRoutes, nil
}

func getKongRoute(blockAc map[string]map[string]slack.BlockAction, routeNumber string) (KongRoutes, error) {
	kongRoute := KongRoutes{}

	var routeData string
	var routeMethodData string
	switch routeNumber {
	case "first":

		kongRoute.routeName = blockAc["svc_name_input"]["svc_name_input"].Value + "-route"
		routeData = blockAc["first_route_input"]["first_route_input"].Value
		routeMethodData = blockAc["first_method_route_input"]["first_method_route_input"].Value

		// case "second":
		// 	kongRoute.routeName = blockAc["second_route_name_input"]["second_route_name_input"].Value
		// 	routeData = blockAc["second_route_input"]["second_route_input"].Value
		// 	routeMethodData = blockAc["second_method_route_input"]["second_method_route_input"].Value
	}

	// err := common.ValidateInput(kongRoute.routeName, "name")

	// if err != nil {
	// 	return kongRoute, err
	// }

	// err := common.ValidateInput(kongRoute.routeName, "kongRoute")

	// if err != nil {
	// 	return kongRoute, err
	// }

	// err = common.ValidateInput(routeMethodData, "kongMethod")

	// if err != nil {
	// 	return kongRoute, err
	// }

	if strings.ContainsAny(routeData, "!@#%^&()+? =,<>") {
		return kongRoute, errors.New("kong data has special character")
	}

	if !strings.HasPrefix(routeData, "/") {
		return kongRoute, errors.New("path must start with /")

	}

	//splitStr := strings.SplitN(data, "/", 2)
	//fmt.Printf("Data %+v", splitStr)

	//count := 0
	//kongRoute.routeHost = append(kongRoute.routeHost, splitStr[count])

	//count++

	kongRoute.routePath = append(kongRoute.routePath, routeData)

	//split then upper then remove whitespace
	kongRoute.routeMethod = strings.Split(strings.Replace(strings.ToUpper(routeMethodData), " ", "", -1), ",")

	kongRoute.routeProtocol = append(kongRoute.routeProtocol, "http")
	kongRoute.routeProtocol = append(kongRoute.routeProtocol, "https")

	//kongRoute.routeProtocol =

	return kongRoute, nil
}

func getConnectionAPI(host string) string {
	connection := ""

	switch host {
	case "api.tala.xyz":
		return "http://kong-talaria-gw.dev.tiki.services"
	case "api.s14e.dev":
		return "http://kong-s14e-gw.dev.tiki.services"
	case "milo.tala.xyz":
		return "http://kong-milo-gw.dev.tiki.services"
	case "api-sellercenter.tala.xyz":
		return "http://kong-microhub-gw.dev.tiki.services"
	default:

	}

	return connection
}

func getKongSvc(blockAc map[string]map[string]slack.BlockAction) (KongService, error) {

	kongSvc := KongService{}

	hostConnection := blockAc["kong_choose_conn"]["kong_choose_conn"].SelectedOption.Value

	kongSvc.Connection = getConnectionAPI(hostConnection)

	if kongSvc.Connection == "" {
		return kongSvc, fmt.Errorf("cannot get connection")
	}

	kongSvc.svcName = blockAc["svc_name_input"]["svc_name_input"].Value

	data := blockAc["svc_input"]["svc_input"].Value

	// err := common.ValidateInput(data, "kongRoute")

	// if err != nil {
	// 	return kongSvc, err
	// }

	splitStr := strings.Split(data, "/")

	//ssfmt.Printf("Data %+v", splitStr)

	if strings.Contains(splitStr[0], "http") {

		count := 0
		kongSvc.svcProtocol = strings.Split(data, ":")[count]

		//jump to "//" character
		count++
		count++
		hostPort := strings.Split(splitStr[count], ":")

		// regex if user type api.xyz:80 @@
		if len(hostPort) == 1 {
			kongSvc.svcHost = hostPort[0]
			kongSvc.svcPort = 80
		} else {
			kongSvc.svcHost = hostPort[0]
			port, err := strconv.Atoi(hostPort[1])

			if err != nil {
				return kongSvc, err
			}

			kongSvc.svcPort = port
		}

		kongSvc.svcPath = ""
		for i := count + 1; i < len(splitStr); i++ {
			kongSvc.svcPath += "/" + splitStr[i]
		}

		//fmt.Println("\n" + kongSvc.svcHost + "\n" + kongSvc.svcPath)
	} else {
		return kongSvc, errors.New("service must start with http or https")
	}

	return kongSvc, nil
}
