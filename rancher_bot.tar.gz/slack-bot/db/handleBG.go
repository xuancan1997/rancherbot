package db

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"cloud.google.com/go/bigquery"
	quickchartgo "github.com/henomis/quickchart-go"
	"github.com/huandu/go-sqlbuilder"
	"github.com/slack-go/slack"
	"google.golang.org/api/iterator"
	"google.golang.org/api/option"
)

func DisplayCostCheckDaily(client *slack.Client) error {

	//CHANNEL_ID := os.Getenv("CHANNEL_ID")

	//channel ID for report cost
	CHANNEL_ID := "C04G10VF4RK"
	NUMBER_DATE_CHECK := 13

	eventsDate, eventDay, err := getEventDate(NUMBER_DATE_CHECK)

	if eventDay {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`<!subteam^SVALNFK27> Today is event next day, not check cost of projects`", false))
		return nil
	}
	log.Println(eventsDate)

	if err != nil {
		return err
	}

	//return nil
	qcURL, err := checkCost(validProject, eventsDate, NUMBER_DATE_CHECK, true)

	if err != nil {
		return err
	}

	log.Println("QC URL", qcURL)

	for _, data := range qcURL {

		dataSplit := strings.Split(data, " ")

		project := dataSplit[0]
		url := dataSplit[1]
		attachment := slack.Attachment{}
		projectName := ""
		if strings.Contains(project, "-prod-") {
			projectNameSplit := strings.SplitN(project, "-prod-", 2)

			// if len(projectName) != 2 {
			// 	return errors.New("cannot get project name: " + project)
			// }

			projectName = projectNameSplit[1]
		} else if strings.Contains(project, "tnsl-dwh") {
			projectName = "special-" + project
		} else {
			projectName = project
		}

		if projectName == "" {
			return errors.New("cannot get project name " + project)
		}
		userMail := validProject[strings.ToLower(projectName)] + "@tiki.vn"

		if userMail == "" {
			return errors.New("cannot get user " + userMail)
		}

		userPIC, err := client.GetUserByEmail(userMail)

		if err != nil {
			return err
		}
		attachment.Pretext = "<!subteam^SVALNFK27> <@" + userPIC.ID + "> Daily cost checking report"
		attachment.Color = "#1e81b0"
		attachment.Text = "Project " + project + " need to check cost increasing in latest day"
		attachment.ImageURL = url
		_, _, err = client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))

		if err != nil {
			return err
		}
	}

	return nil
}

func checkCost(projects map[string]string, eventDate []string, NUMBER_DATE_CHECK int, checkEvent bool) ([]string, error) {
	var qcURLs []string

	projectsData, err := queryData(projects, eventDate, NUMBER_DATE_CHECK)

	if err != nil {
		return qcURLs, err
	}

	log.Println("len project data", len(projectsData))

	lastProjectName := projectsData[0].Name
	var bqData []ProjectData
	for i, data := range projectsData {

		//add last data to project
		if i == (len(projectsData) - 1) {
			bqData = append(bqData, data)

		}

		if data.Name != lastProjectName || i == (len(projectsData)-1) {
			log.Println(lastProjectName, data.Name)

			qcURL := ""
			if checkEvent {
				qcURL, err = checkData(bqData, checkEvent)
			} else {
				qcURL, err = getQCUrl(bqData)
			}

			if err != nil {
				return qcURLs, err
			}
			if qcURL != "" {
				qcURLs = append(qcURLs, lastProjectName+" "+qcURL)
			}
			//reset bqData
			lastProjectName = data.Name
			bqData = nil

		}

		bqData = append(bqData, data)
	}

	return qcURLs, nil
}

func checkData(bqData []ProjectData, checkEvent bool) (string, error) {
	qcURL := ""
	var err error
	if len(bqData) < 2 {
		return qcURL, nil
	}

	latestData := bqData[len(bqData)-1].RealPaid
	needAlert := false
	for i := 0; i < len(bqData)-1; i++ {

		//", latestData, bqData[i].RealPaid)

		// if strings.Contains(bqData[i].Name, "marketplace") {
		// 	latestData = 250.32
		// }
		value := latestData / bqData[i].RealPaid

		//log.Println("value is ", value)
		if value > 1.05 {
			needAlert = true
			break
		}
	}

	if needAlert {
		qcURL, err = getQCUrl(bqData)
		if err != nil {
			return qcURL, err
		}
	}

	return qcURL, nil
}

func queryData(projectInput map[string]string, eventDate []string, NUMBER_DATE_CHECK int) ([]ProjectData, error) {
	//get bq client
	var bqData []ProjectData
	client, err := getClient()

	if err != nil {
		return bqData, err
	}
	//hour := -24 * dateCount * time.Hour
	countDate := time.Now().Add(-24 * time.Duration(NUMBER_DATE_CHECK+1) * time.Hour)

	beginDate := time.Date(2022, 12, 1, 0, 0, 0, 0, time.Now().Location())
	if countDate.Before(beginDate) {
		countDate = beginDate
	}

	sqlCmd := sqlbuilder.NewSelectBuilder()

	prjName := "project.name"
	cost := "IFNULL(ROUND(SUM(cost),2),0)"
	day := "DATE(usage_start_time, 'America/Los_Angeles')"
	credits := "IFNULL(ROUND(SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)"
	realpaid := "IFNULL(ROUND(SUM(cost) + IFNULL(ROUND(SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)),0)"
	BQ_SHEET_QR := os.Getenv("BQ_SHEET")
	usageDate := "DATE(usage_start_time,'America/Los_Angeles')"
	//tmpEventDate := ""
	//checkEvent := false
	//var nextEventDate string
	//if len(eventDate) > 0 {
	//tmpEventDate = eventDate[0]
	//checkEvent = true
	//curEventDate, err := time.Parse("2006-01-02", tmpEventDate)

	// if err != nil {
	// 	return bqData, err
	// }

	//nextEventDate = curEventDate.Add(24 * time.Hour).Format("2006-01-02")
	//}

	maxDate := time.Now().Add(-24 * time.Hour).Format("2006-01-02")
	projectQuery := ""
	count := 0
	addHeader := "tiki-prod-"

	for projectKey := range projectInput {

		splitProject := strings.SplitN(projectKey, "-", 2)

		log.Println(splitProject)

		if len(splitProject) > 1 {

			if splitProject[0] == "tiki" {
				//dot nothing

			} else if splitProject[0] == "special" {
				log.Println("validating")
				projectKey = splitProject[1]
			} else if projectKey == "dev-tiki-infra" {
				projectKey = "DEV-TIKI-INFRA"
			} else {
				projectKey = addHeader + projectKey
			}

		} else {
			projectKey = addHeader + projectKey
		}

		log.Println("project key ", projectKey)
		if count == 0 {
			projectQuery += " AND project.name = " + "'" + projectKey + "'"
		} else {
			projectQuery += " OR project.name = " + "'" + projectKey + "'"
		}
		count++
	}

	//log.Println("Project query ", projectQuery)
	if err != nil {
		return bqData, err
	}

	sqlCmd.Select(sqlCmd.As(prjName, "name"), sqlCmd.As(day, "time"), sqlCmd.As(cost, "cost"), sqlCmd.As(credits, "credits"), sqlCmd.As(realpaid, "realpaid"))
	sqlCmd.From(BQ_SHEET_QR)

	// if checkEvent {
	// 	sqlCmd.Where(sqlCmd.GreaterThan(usageDate, countDate), sqlCmd.NotEqual(usageDate, tmpEventDate), sqlCmd.NotEqual(usageDate, nextEventDate), sqlCmd.LessThan(usageDate, maxDate))

	// } else {
	// 	sqlCmd.Where(sqlCmd.GreaterThan(usageDate, countDate), sqlCmd.LessThan(usageDate, maxDate))
	// }
	sqlCmd.Where(sqlCmd.GreaterThan(usageDate, countDate.Format("2006-01-02")), sqlCmd.LessThan(usageDate, maxDate))

	sqlCmd.GroupBy(prjName, "time")
	sqlCmd.Having("cost > 1" + projectQuery)
	sqlCmd.OrderBy("project.name", "time")
	sqlCmd.Limit(1000)
	sqlCmd.Asc()
	sql, args := sqlCmd.Build()

	//log.Println(sql)
	//log.Println(args)

	for _, argsData := range args {
		sql = strings.Replace(sql, "?", "'"+argsData.(string)+"'", 1)
	}

	log.Println(sql)
	bqData, err = queryBasic(sql, client)

	if err != nil {
		log.Println(err)
		return bqData, err
	}

	if len(bqData) == 0 {
		return bqData, errors.New("cannot get any data")
	}

	return bqData, nil
}

func getQCUrl(bqData []ProjectData) (string, error) {

	qC_URL := ""

	qc := quickchartgo.New()
	var chartConfig ChartConfig
	chartConfig.Type = "bar"

	var chartDataSet []ChartDataset
	var chartData ChartData
	var sampleChartDataSet ChartDataset
	sampleChartDataSet.Label = bqData[0].Name
	for _, data := range bqData {
		sampleChartDataSet.Data = append(sampleChartDataSet.Data, fmt.Sprintf("%.0f", data.RealPaid))

		chartData.Labels = append(chartData.Labels, data.Time.String())
		// if len(chartData.Labels) == 0 {
		// 	chartData.Labels = append(chartData.Labels, data.Time.String())
		// }
		// if chartData.Labels[len(chartData.Labels)-1] != data.Name {
		// 	chartData.Labels = append(chartData.Labels, data.Time.String())
		// }

	}

	chartDataSet = append(chartDataSet, sampleChartDataSet)

	chartData.Datasets = chartDataSet

	chartConfig.Data = chartData

	// options: {
	// 	plugins: {
	// 	  datalabels: {
	// 		anchor: 'end',
	// 		align: 'top',
	// 		color: '#fff',
	// 		backgroundColor: 'rgba(34, 139, 34, 0.6)',
	// 		borderWidth: 1,
	// 		borderRadius: 5,
	// 		formatter: (value) => {
	// 		  return value + 'k';
	// 		},
	// 	  },
	// 	},
	// },
	chartConfig.Options.Title.Display = true
	chartConfig.Options.Title.Text = "Report cost of project " + bqData[0].Name + " (USD)"
	chartConfig.Options.Plugins.Datalabels.Anchor = "end"
	chartConfig.Options.Plugins.Datalabels.Align = "top"
	chartConfig.Options.Plugins.Datalabels.Color = "#fff"
	chartConfig.Options.Plugins.Datalabels.BackgroundColor = "rgba(34, 139, 34, 0.6)"
	chartConfig.Options.Plugins.Datalabels.BorderRadius = "5"
	chartConfig.Options.Plugins.Datalabels.BorderWidth = "1"

	log.Println("bq Data length", len(bqData))

	if len(bqData) > 20 {
		chartConfig.Options.Plugins.Datalabels.Formatter = "(value) => {return value;},"
	} else {
		chartConfig.Options.Plugins.Datalabels.Formatter = "(value) => {return '$' + value + '$';},"

	}
	b, err := json.Marshal(chartConfig)

	//log.Println(b)
	if err != nil {
		log.Println(err)
		return qC_URL, err
	}
	qc.Config = string(b)

	//log.Println(string(b))

	if len(bqData) > 20 {
		lenAdd := 1000 + 20*(len(bqData)-20)
		qc.Width = int64(lenAdd)
	} else {
		qc.Width = 1000

	}

	qc.Height = 600
	qc.Version = "2.9.4"

	urlRender, err := qc.GetShortUrl()

	//log.Println("Render", urlRender)

	if urlRender == "" {
		return qC_URL, errors.New("cannot gen url image")
	}
	qC_URL = urlRender
	if err != nil {
		return qC_URL, err
	}

	return qC_URL, nil
}

func GetListProject(clientSlack *slack.Client, eventTs string) error {

	var projectList []string
	for k := range validProject {
		projectList = append(projectList, k)
	}
	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	attachment := slack.Attachment{}

	attachment.Pretext = "*Current project supported*"
	attachment.Color = "#1e81b0"
	attachment.Text = "```" + strings.Join(projectList, "\n") + "```"
	_, _, err := clientSlack.PostMessage(CHANNEL_ID, slack.MsgOptionTS(eventTs), slack.MsgOptionAttachments(attachment))

	if err != nil {
		return err
	}

	return nil
}

func GetProjectCostData(clientSlack *slack.Client, timeStamp, input string) error {

	splitInput := strings.Split(input, " ")

	if len(splitInput) != 4 {
		return errors.New("format not correct, please check")
	}

	projectInput := splitInput[2]

	projectList, err := checkProjectValue(projectInput)

	log.Println("project input", projectList)

	if err != nil {
		return err
	}
	dateCountString := splitInput[3]
	dateCount, err := strconv.Atoi(dateCountString)

	if err != nil {
		return err
	}

	if dateCount > 90 {
		return errors.New("cannot get data more than 90 days")
	}

	log.Println(dateCount)

	qcURL, err := checkCost(projectList, nil, dateCount, false)

	if err != nil {
		return err
	}

	log.Println("QC URL", qcURL)

	for _, data := range qcURL {

		dataSplit := strings.Split(data, " ")

		project := dataSplit[0]
		url := dataSplit[1]
		attachment := slack.Attachment{}
		//projectName := strings.Split(project, "-prod-")

		// if len(projectName) != 2 {
		// 	return errors.New("cannot get projectName")
		// }

		//userPIC, err := clientSlack.GetUserByEmail(validProject[projectName[1]] + "@tiki.vn")

		if err != nil {
			return err
		}
		attachment.Pretext = "GCP cost checking report"
		attachment.Color = "#1e81b0"
		attachment.Text = "Project " + project + " cost data "
		attachment.ImageURL = url
		CHANNEL_ID := os.Getenv("CHANNEL_ID")
		_, _, err = clientSlack.PostMessage(CHANNEL_ID, slack.MsgOptionTS(timeStamp), slack.MsgOptionAttachments(attachment))

		if err != nil {
			return err
		}
	}

	// for _, project := range projectList {

	// 	chartUrl, err := getChartUrl(project, dateCount)

	// 	if err != nil {
	// 		return err
	// 	}

	// 	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	// 	attachment := slack.Attachment{}

	// 	attachment.Text = "Report cost of " + project
	// 	attachment.Color = "#1e81b0"
	// 	attachment.ImageURL = chartUrl
	// 	_, _, err = clientSlack.PostMessage(CHANNEL_ID, slack.MsgOptionTS(timeStamp), slack.MsgOptionAttachments(attachment))

	// 	if err != nil {
	// 		log.Println(err)
	// 		return err
	// 	}
	// }
	return nil
}

// func getChartUrl(projectInput string, dateCount int) (string, error) {
// 	returnChartUrl := ""

// 	//get bq client
// 	client, err := getClient()

// 	if err != nil {
// 		return returnChartUrl, err
// 	}
// 	//hour := -24 * dateCount * time.Hour
// 	countDate := time.Now().Add(-24 * time.Duration(dateCount+1) * time.Hour).Format("2006-01-02")

// 	sqlCmd := sqlbuilder.NewSelectBuilder()

// 	prjName := "project.name"
// 	cost := "IFNULL(ROUND(SUM(cost),2),0)"
// 	day := "DATE(usage_start_time, 'America/Los_Angeles')"
// 	credits := "IFNULL(ROUND(SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)"
// 	realpaid := "IFNULL(ROUND(SUM(cost) + SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)"
// 	BQ_SHEET_QR := os.Getenv("BQ_SHEET")

// 	sqlCmd.Select(sqlCmd.As(prjName, "name"), sqlCmd.As(day, "time"), sqlCmd.As(cost, "cost"), sqlCmd.As(credits, "credits"), sqlCmd.As(realpaid, "realpaid"))
// 	sqlCmd.From(BQ_SHEET_QR)
// 	sqlCmd.Where(sqlCmd.Like(prjName, "tiki-prod-"+projectInput), sqlCmd.GreaterThan("DATE(usage_start_time,'America/Los_Angeles')", countDate))
// 	sqlCmd.GroupBy(prjName, "time")
// 	sqlCmd.Having("cost > 1")
// 	sqlCmd.OrderBy("time")
// 	sqlCmd.Limit(100)
// 	sqlCmd.Asc()
// 	sql, args := sqlCmd.Build()

// 	//log.Println(args)

// 	for _, argsData := range args {
// 		sql = strings.Replace(sql, "?", "'"+argsData.(string)+"'", 1)
// 	}

// 	log.Println(sql)
// 	bqData, err := queryBasic(sql, client)

// 	if err != nil {
// 		log.Println(err)
// 		return returnChartUrl, err
// 	}

// 	if len(bqData) == 0 {
// 		return returnChartUrl, errors.New("cannot get any data")
// 	}

// 	qcUrl, err := getQCUrl(bqData)

// 	if err != nil {
// 		return returnChartUrl, err
// 	}
// 	returnChartUrl = qcUrl
// 	return returnChartUrl, nil
// }

func GetDailyProjectCostData(clientSlack *slack.Client) error {

	client, err := getClient()

	if err != nil {
		return err
	}

	currentDate := time.Now().Add(-24 * 1 * time.Hour).Format("2006-01-02")

	countDate := time.Now().Add(-24 * 8 * time.Hour).Format("2006-01-02")
	log.Println(currentDate)

	sqlCmd := sqlbuilder.NewSelectBuilder()

	prjName := "project.name"
	cost := "IFNULL(ROUND(SUM(cost),2),0)"
	day := "DATE(usage_start_time, 'America/Los_Angeles')"
	credits := "IFNULL(ROUND(SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)"
	realpaid := "IFNULL(ROUND(SUM(cost) + SUM((SELECT SUM(amount) FROM UNNEST(credits) where name like 'Committed Usage Discount%')),2),0)"
	BQ_SHEET_QR := os.Getenv("BQ_SHEET")

	sqlCmd.Select(sqlCmd.As(prjName, "name"), sqlCmd.As(day, "time"), sqlCmd.As(cost, "cost"), sqlCmd.As(credits, "credits"), sqlCmd.As(realpaid, "realpaid"))
	sqlCmd.From(BQ_SHEET_QR)
	sqlCmd.Where(sqlCmd.Like(prjName, "tiki-prod-marketplace"), sqlCmd.GreaterThan("DATE(usage_start_time,'America/Los_Angeles')", countDate))
	sqlCmd.GroupBy(prjName, "time")
	sqlCmd.Having("cost > 0")
	sqlCmd.OrderBy("time")
	sqlCmd.Limit(100)
	sqlCmd.Asc()
	sql, args := sqlCmd.Build()

	//log.Println(args)

	for _, argsData := range args {
		sql = strings.Replace(sql, "?", "'"+argsData.(string)+"'", 1)
	}

	log.Println(sql)
	bqData, err := queryBasic(sql, client)

	if err != nil {
		log.Println(err)
		//return err
	}

	if len(bqData) == 0 {
		return errors.New("cannot get any data")
	}

	qcUrl, err := getQCUrl(bqData)

	if err != nil {
		return err
	}

	log.Println(qcUrl)

	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	attachment := slack.Attachment{}

	attachment.Text = "Report cost of " + prjName
	attachment.Color = "#1e81b0"
	attachment.ImageURL = qcUrl
	_, _, err = clientSlack.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		log.Println(err)
	}
	return nil
}

func getClient() (*bigquery.Client, error) {
	ctx := context.Background()
	var client *bigquery.Client
	PROJECT_NAME := os.Getenv("PROJECT_NAME")

	if PROJECT_NAME == "" {
		return client, errors.New("cannot get project name")
	}

	// //log.Println("Sa locate: ", GGSHEET_SA)
	BQ_EXPORTER := os.Getenv("BQ_EXPORTER")

	if BQ_EXPORTER != "" {
		data, err := ioutil.ReadFile(BQ_EXPORTER)
		if err != nil {
			return client, err
		}
		client, err = bigquery.NewClient(ctx, PROJECT_NAME, option.WithCredentialsJSON(data))
		if err != nil {
			return nil, errors.New("could not get client bq, please check")
		}
	} else {
		var err error
		client, err = bigquery.NewClient(ctx, PROJECT_NAME)
		if err != nil {
			return nil, errors.New("could not get client bq, please check")
		}
	}

	defer client.Close()
	//it := client.Datasets(ctx)
	// it := client.Datasets(ctx)

	println("logged in")
	return client, nil
}

// queryBasic demonstrates issuing a query and reading results.
func queryBasic(querryCommmand string, client *bigquery.Client) ([]ProjectData, error) {

	var projectsData []ProjectData
	ctx := context.Background()

	q := client.Query(querryCommmand)
	q.Location = "us"
	it, err := q.Read(ctx)
	if err != nil {
		// TODO: Handle error.
		log.Println("error read ctx")
		return projectsData, err
	}

	for {
		var projectData ProjectData
		err := it.Next(&projectData)
		if err == iterator.Done {
			break
		}
		if err != nil {
			log.Println("error read project")

			return projectsData, err
		}

		//fmt.Printf("%+v", projectData)

		projectsData = append(projectsData, projectData)
	}

	return projectsData, nil
}
