package lib

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"slack-bot/db"
	"slack-bot/github"
	"slack-bot/jsonconvert"
	"slack-bot/kong"
	"slack-bot/rancher"
	"slack-bot/vault"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/slack-go/slack/slackevents"
)

// handleEventMessage will take an event and handle it properly based on the type of event
func HandleEventMessage(event slackevents.EventsAPIEvent, client *slack.Client) error {
	switch event.Type {

	// First we check if this is an CallbackEvent
	case slackevents.CallbackEvent:

		innerEvent := event.InnerEvent
		// Yet Another Type switch on the actual Data to see if its an AppMentionEvent
		switch ev := innerEvent.Data.(type) {
		case *slackevents.AppMentionEvent:
			// The application has been mentioned since this Event is a Mention event
			err := handleAppMentionEvent(ev, client)
			if err != nil {
				return err
			}
			//log.Println(ev)

		case *slackevents.MessageEvent:

			err := handleAppMessageEvent(ev, client)
			if err != nil {
				log.Println(err)
				return err
			}
			//log.Println(ev)

		default:
			//log.Println(ev)
			//log.Printf(event.Type)
		}

	default:
		return errors.New("unsupported event type")

	}
	return nil
}

//handle Button event
func handleSubmitButtonEvent(event *slackevents.MessageAction, client *slack.Client) error {

	fmt.Printf("Go to here")
	return nil
}

// handleAppMessage

func handleAppMessageEvent(event *slackevents.MessageEvent, client *slack.Client) error {

	text := strings.ToLower(event.Text)
	//var listOnlyHpaActive bool
	var err error
	//log.Println("User: " + event.BotID + " type: " + event.Text)

	isBot := false
	if event.BotID != "" {
		isBot = true
	}

	//create key db vault

	if strings.HasPrefix(text, "create keydb vault") {
		log.Println("Begin create keydb vault")
		err = vault.CreateNewVaultForKeyDB(client, text, event.Channel, event.TimeStamp)
		if err != nil {
			log.Println(err)
			sendEventResponse(client, event.Channel, event.TimeStamp, err, "error", "post")
		}
		return nil
	}

	if !isBot {
		user, err := client.GetUserInfo(event.User)

		if err != nil {
			return err
		}
		godotenv.Load(".env")

		if !user.IsBot {
			log.Println("User: " + user.Name + " type command " + event.Text)
		}

		//check if event not im
		if event.ChannelType != "im" {
			CHANNEL_ID := os.Getenv("CHANNEL_ID")

			if CHANNEL_ID != event.Channel {
				log.Println("Message not come from channel, so continue")
				return nil
			}
		}
	}

	//set pods manually
	if strings.HasPrefix(text, "set deploy") {
		err = rancher.SetDeploymentReplica(client, text, event.Channel, event.TimeStamp)
		if err != nil {
			log.Println(err)
			sendEventResponse(client, event.Channel, event.TimeStamp, err, "error", "post")
		}
		return nil
	}

	//test daily
	if strings.HasPrefix(text, "dailycost") {
		err = db.DisplayCostCheckDaily(client)

		log.Println(err)

		return nil
	}
	//list project
	if strings.HasPrefix(text, "list project cost") {
		err = db.GetListProject(client, event.TimeStamp)

		if err != nil {
			log.Println(err)
			sendEventResponse(client, event.Channel, event.TimeStamp, err, "error", "post")
		}
		return nil
	}
	//report cost manually
	if strings.HasPrefix(text, "report cost") {
		err = db.GetProjectCostData(client, event.TimeStamp, text)

		if err != nil {
			log.Println(err)
			sendEventResponse(client, event.Channel, event.TimeStamp, err, "error", "post")
		}
		return nil
	}
	//report daily cost
	if strings.HasPrefix(text, "report dailycost") {
		err = db.GetDailyProjectCostData(client)

		if err != nil {
			log.Println(err)
		}
		return nil
	}
	//go to search vault
	if strings.HasPrefix(text, "search vault") {
		handleSearchVault(client, event, text, event.ChannelType)
		return nil
	}

	//redeploy stateful set
	if strings.HasPrefix(text, "redeploy stateful") {
		handleRedeployStateful(client, event, text)
		return nil
	}
	//event chat to bot
	if event.ChannelType == "im" {
		//log.Println("user " + user.Name + " chat to bot")
		err = handleReplyBotMsg(client, event)
		log.Println(err)
		return nil
	}

	environmentExec := os.Getenv("ENDPOINT")
	var isDev bool

	if strings.Contains(environmentExec, "dev") {
		isDev = true
	}

	//switch key
	switch text {
	case "help":
		printHelp(client, event, isDev)
	// case "hpa list":
	// 	//listOnlyHpaActive = true
	// 	handleHpaList(client, event, "active", "all")
	// case "hpa list all":
	// 	handleHpaList(client, event, "all", "all")
	// case "hpa list --all":
	// 	handleHpaList(client, event, "all", "all")
	// case "hpa edit":
	// 	handleHpaEdit(client, event)
	// case "hpa edits":
	// 	handleHpaEdits(client, event)
	// case "hpa scale event":
	// 	handleHpaScale(client, event, "event")
	// case "hpa scale normal":
	// 	handleHpaScale(client, event, "normal")
	// case "deploy list":
	// 	//listOnlyHpaActive = true
	// 	handleDeploymentListActive(client, event, "active", "all")
	// case "deploy list all":
	// 	//list all
	// 	handleDeploymentList(client, event, "all", "all")
	// case "deploy edit":
	// 	handleDeploymentEdit(client, event)
	// case "deploy add":
	// 	handleDeploymentAdd(client, event)
	case "deploy find":
		handleDeploymentFind(client, event)
	// case "deploy scale event":
	// 	handleDeploymentScale(client, event, "event")
	// case "deploy scale normal":
	// 	handleDeploymentScale(client, event, "normal")
	case "deploy update local file":
		handleDeploymentUpdateLocalFile(client, event)
	case "clear deploy local file":
		handleClearLocalFile(client, event, "deployment")
	case "scale manually":
		handleScaleManually(client, event)
	case "redeploy":
		fmt.Println("----------------------Submit to redeploy---------------- ")
		handleRedeployDeployment(client, event)
	case "update rancherdata":
		fmt.Println("----------------------Submit to get ggdata---------------- ")
		handleGoogleSheetUpdateData(client, event)
	case "scale":
		fmt.Println("----------------------Submit to get scale---------------- ")
		handleScale(client, event)
	case "remind event":
		fmt.Println("----------------------Submit to get remind---------------- ")
		handleRemindEvent(client, event)
	case "rerun":
		fmt.Println("----------------------Submit to get rerun---------------- ")
		handleReRunRancherPod(client, event)
	case "enable remind sys":
		fmt.Printf("Remind system if replicas data not back to normal")
		handleRemindSysAboutReplicas(client, event, true)
	case "disable remind sys":
		fmt.Printf("disable Remind system if replicas data not back to normal")
		handleRemindSysAboutReplicas(client, event, false)
	case "update normal scale data":
		fmt.Printf("Update scale normal data beyond current rancher data")
		handleUpdateScaleNormalData(client, event)
	case "update vault":
		fmt.Printf("update vault")
		handleUpdateVault(client, event)
	case "uv":
		fmt.Printf("update vault")
		handleUpdateVault(client, event)
	case "check vault":
		fmt.Printf("check vault")
		handleCheckVault(client, event)
	case "cv":
		fmt.Printf("check vault")
		handleCheckVault(client, event)
	case "scale down job":
		fmt.Printf("scale down cron")
		handleCheckVault(client, event)
	case "nv":
		fmt.Printf("new vault")
		handleCreateVault(client, event)
	case "new vault":
		fmt.Printf("new vault")
		handleCreateVault(client, event)
	case "init scale optimize":
		fmt.Println("int scale optimize")
		handleInitScaleOptimizeCost(client, event)
	default:
	}

	if isDev {
		switch text {
		case "bot":
			handleCallBot(client, event)
		case "rancher adduser":
			handleAddUserCommand(client, event)

		case "rancher grantuser":
			handleGrantUserCommand(client, event)

		case "rancher resetpwd":
			handleResetUserPwd(client, event)

		case "kong addsvc":
			//log.Println("Somethings in here :yaoming:")
			handleKongAddService(client, event, 1)

		case "kong addsvc 2":
			//log.Println("Somethings in here :yaoming:")
			handleKongAddService(client, event, 2)

		case "git adduser":
			handleGitAddUser(client, event)

		case "git new repo":
			handleGitAddRepo(client, event)

		case "git to orgs":
			handleGitAddToOrgs(client, event)
		case "to json":
			handleJsonConvert(client, event)

		case "test block":
			testBlock(client, event)
		case "random pwd":
			handleRandomPassword(client, event)
		case "search console":
			handleSearchConsole(client, event)
		case "sc":
			handleSearchConsole(client, event)
		default:
		}
	}

	return nil
}

func handleInitScaleOptimizeCost(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := rancher.HandleInitScaleOptimizeCostMsg()

	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), msg)

	if err != nil {
		log.Println(err)
	}
	return nil
}

func handleCreateVault(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := vault.CreateVaultMsg()

	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), msg)

	if err != nil {
		log.Println(err)
	}

	return nil
}

func handleCheckVault(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := vault.CheckVaultMsg()

	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), msg)

	if err != nil {
		log.Println(err)
	}

	return nil
}

func handleUpdateVault(client *slack.Client, event *slackevents.MessageEvent) error {

	msg, err := vault.UpdateVaultMsg()

	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), msg)

	if err != nil {
		log.Println(err)
	}

	return nil
}

func handleUpdateScaleNormalData(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := rancher.UpdateScaleNormalData()

	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), slack.MsgOptionAttachments(msg))

	if err != nil {
		log.Println(err)
	}

	return nil
}

func handleSearchConsole(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := rancher.GetSearchConsoleBlock()
	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		log.Println(err)
	}
	return nil
}

func handleReRunRancherPod(client *slack.Client, event *slackevents.MessageEvent) error {
	msg, err := rancher.GetReRunDeploymentBlock()
	ts := event.TimeStamp
	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		log.Println(err)
	}
	return nil
}

func handleRemindSysAboutReplicas(client *slack.Client, event *slackevents.MessageEvent, isEnable bool) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	err := rancher.HandleEnableRemindSysReplicas(client, isEnable)
	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		if err != nil {
			log.Println(err)
		}
		return nil
	}
	if isEnable {
		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText("Enabled remind bot if data is not back to normal replicas value", true))

	} else {
		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText("disabled remind system", true))

	}

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}

func handleRemindEvent(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.HandleRemindEvent()
	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}

func handleScale(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.HandleScaleMsg()
	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleGoogleSheetUpdateData(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	err := rancher.HandleGoogleSheetUpdateData()
	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp
	attachment.Text = fmt.Sprintf("Successfully update google sheet data")
	attachment.Color = "#4af030"
	attachment.Pretext = "Bot response:"

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleGoogleSheetData(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options
	var err error

	rancher.GetGoogleSheetData()
	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp
	attachment.Text = fmt.Sprintf("Get google sheet success")
	attachment.Color = "#4af030"
	attachment.Pretext = "Bot response:"

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}

func handleClearLocalFile(client *slack.Client, event *slackevents.MessageEvent, typeFile string) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	err := rancher.HandleClearLocalFile(typeFile)

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp
	attachment.Text = fmt.Sprintf("Success clear " + typeFile + " informartion")
	attachment.Color = "#4af030"
	attachment.Pretext = "Bot response:"

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleRandomPassword(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := common.GetRandomPasswordBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleDeploymentUpdateLocalFile(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//log.Println("Update local file")
	err := rancher.HandleDeploymentUpdateLocalFile()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp
	attachment.Text = fmt.Sprintf("Success update deployment informartion")
	attachment.Color = "#4af030"
	attachment.Pretext = "Bot response:"

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleGitAddRepo(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := github.GetCreateRepoBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#4af030"
		attachment.Pretext = ":mag: Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleGitAddToOrgs(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := github.GetAddToOrgsBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#4af030"
		attachment.Pretext = ":mag: Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleCallBot(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetCallBotBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func printHelp(client *slack.Client, event *slackevents.MessageEvent, isDev bool) error {
	ts := event.TimeStamp

	// Create the attachment and assigned based on the message
	attachment := slack.Attachment{}

	if isDev {
		attachment.Text = "rancher adduser | rancher grantuser | rancher resetpwd |" +
			"\n ------------------------------------------\n" +
			"search console | sc (get genfile and add manage workload to rancher)" +
			"\n ------------------------------------------\n" +
			"kong addsvc | kong addsvc 2 (to add 2 routes)" +
			"\n-------------------------------------------\n" +
			"git adduser | git new repo | git to orgs" +
			"\n-------------------------------------------\n" +
			"redeploy (redeploy deployment, need to find deployment first :monkathink:)" +
			"\n-------------------------------------------\n" +
			"to json (convert some vaults format from dev)" +
			"\n-------------------------------------------\n" +
			"random pwd (generate random password)"
	} else {
		attachment.Text = "*scale*\nscale for event\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*update rancherdata*\nupdate googlesheet event file\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*remind event*\nremind event to dev\n" +
			//"\n -------------------------------------------------------------------\n" +
			//"scale manually (scale a deployment/hpa listed/not listed manually)" +
			//"\n -------------------------------------------------------------------\n" +
			//"redeploy (redeploy deployment, need to find deployment first :monkathink:)" +
			//"\n -------------------------------------------------------------------\n" +
			"*deploy update local file | clear deploy local file*\nneed to update deployment local check value\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*deploy find*\nfind a deployment\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*rerun*\nRedeploy a deployment\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*update normal scale data*\nupdate normal column beyond current replicas data\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*uv | cv | nv | search vault <deployment>*\nInteractive with vaul\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*disable remind sys | enable remind sys*\nremind system if normal not stable\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*init scale optimize*\nEnable/Disable scale low traffic\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*list project cost*\nShow project on gcp\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*report cost <project> <day>*\nReport cost project, project = all will show all project cost\n" +
			//"\n -------------------------------------------------------------------\n" +
			"*set deploy <deployment> <pods_number>*\nSet number of pod running of a deployment"
	}

	attachment.Pretext = "*Current support command: *"
	attachment.Color = "#4af030"

	_, _, err := client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	if err != nil {
		fmt.Println(err.Error())
	}

	return nil
}

func handleRedeployDeployment(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetRedeployDeploymentBlock()

	if err != nil {
		sendEventResponse(client, event.Channel, ts, err, "error", "post")
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}
func testBlock(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options
	var strArr []string
	strArr = append(strArr, "1")
	strArr = append(strArr, "2")
	msg, err := common.GetOptionsBlock(strArr, "static_select", "choose one", "actiontest")

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	textBlockObject := slack.NewTextBlockObject("plain_text", "choose one", false, false)
	input := slack.NewInputBlock("test", textBlockObject, nil, msg)
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionBlocks(input))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}
func handleScaleManually(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetScaleManuallyBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}

func handleDeploymentFind(client *slack.Client, event *slackevents.MessageEvent) error {

	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetDeploymentFindBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		if err != nil {
			log.Println(err)
		}
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleDeploymentScale(client *slack.Client, event *slackevents.MessageEvent, scaleInput string) error {

	ts := event.TimeStamp
	msgConfimBlock, msgData, err := rancher.GetDeploymentScale(scaleInput)

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	//inputBl := common.GetTxtInputBlock("testBlock", "test", "test")

	if err != nil {
		fmt.Printf(err.Error())
	}
	attachment.Color = "#ff0000"
	attachment.Pretext = ":mag: Please *Confirm* to approve this deployment scale:"

	//textBlockObject := slack.NewTextBlockObject("plain_text", "b", false, false)
	//blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, "c")

	// Create the Accessory that will be included in the Block and add the checkbox to it

	attachment = slack.Attachment{
		CallbackID: "deployment_approve_scale_btn",
		Fallback:   "deployment_approve_scale_btn",
		Color:      "#2484BE",
		Fields: []slack.AttachmentField{
			slack.AttachmentField{
				Title: "Apply this deployment value to server",
				Short: true,
			},
		},
		// Blocks: slack.Blocks{
		// 	BlockSet: []slack.Block{
		// 		// Create a new section block element and add some text and the accessory to it
		// 		common.GetInputBlock("data"),
		// 	},
		// },
		Actions: []slack.AttachmentAction{
			slack.AttachmentAction{
				Name:  "deployment_approve_scale_btn",
				Text:  "Apply",
				Style: "primary",
				Type:  "button",
				Value: msgData,
				Confirm: &slack.ConfirmationField{
					Title:  "Confirm",
					Text:   "Are you sure to apply this? \n",
					OkText: "Apply",
				},
			},
		},

		MarkdownIn: []string{"text"},
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgConfimBlock[0], slack.MsgOptionAttachments(attachment))

	//_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgHpaConfim[0])

	if err != nil {
		fmt.Printf(err.Error())
	}
	return nil

}

func handleDeploymentList(client *slack.Client, event *slackevents.MessageEvent, inputType string, scaleType string) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msgTextResponse, _, err := rancher.GetDeploymentList("all", "all")

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msgTextResponse, true))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleDeploymentAdd(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetDeploymentAddBlock()

	if err != nil {
		fmt.Println(err)
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil

}

func handleDeploymentEdit(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetDeploymentEditBlock()

	if err != nil {
		fmt.Println(err)
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil

}

func handleDeploymentListActive(client *slack.Client, event *slackevents.MessageEvent, deployOption string, scaleType string) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, _, err := rancher.GetDeploymentList(deployOption, scaleType)

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	//fmt.Println("still here ")

	// options

	// Send the message to the channel
	// The Channel is available in the event message

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msg, true))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleHpaEdits(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	msg, err := rancher.GetHpaMultiEditBlock()

	if err != nil {
		fmt.Println(err)
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil

}
func handleHpaScale(client *slack.Client, event *slackevents.MessageEvent, scaleInput string) error {

	ts := event.TimeStamp
	msgHpaText, msgHpaData, err := rancher.GetHpaScale(scaleInput)

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
	}

	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	//inputBl := common.GetTxtInputBlock("testBlock", "test", "test")

	if err != nil {
		fmt.Printf(err.Error())
	}
	attachment.Color = "#ff0000"
	attachment.Pretext = ":mag: Please *Confirm* to approve this hpa scale:"

	//textBlockObject := slack.NewTextBlockObject("plain_text", "b", false, false)
	//blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, "c")

	// Create the Accessory that will be included in the Block and add the checkbox to it

	attachment = slack.Attachment{
		CallbackID: "btn_hpa_approve",
		Fallback:   "btn_hpa_approve",
		Color:      "#2484BE",
		Fields: []slack.AttachmentField{
			slack.AttachmentField{
				Title: "Apply this Hpa value to server",
				Short: true,
			},
		},
		// Blocks: slack.Blocks{
		// 	BlockSet: []slack.Block{
		// 		// Create a new section block element and add some text and the accessory to it
		// 		common.GetInputBlock("data"),
		// 	},
		// },
		Actions: []slack.AttachmentAction{
			slack.AttachmentAction{
				Name:  "hpa_approve_btn",
				Text:  "Apply",
				Style: "primary",
				Type:  "button",
				Value: msgHpaData,
				Confirm: &slack.ConfirmationField{
					Title:  "Confirm",
					Text:   "Are you sure to apply this? \n",
					OkText: "Apply",
				},
			},
		},

		MarkdownIn: []string{"text"},
	}

	count := 0

	if len(msgHpaText) > 1 {
		for count = 0; count < len(msgHpaText)-1; count++ {
			_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msgHpaText[count], true))
		}
		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msgHpaText[count+1], true), slack.MsgOptionAttachments(attachment))
	} else {
		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msgHpaText[count], true), slack.MsgOptionAttachments(attachment))
	}

	//_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgHpaConfim[0])

	if err != nil {
		fmt.Printf(err.Error())
	}
	return nil

}

func handleHpaEdit(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, err := rancher.GetHpaEditBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
	}
	// options

	//buttonAprove := GetAprroveBtn("submit_kong_add_service")

	// Send the message to the channel
	// The Channel is available in the event message

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleHpaList(client *slack.Client, event *slackevents.MessageEvent, hpaOption string, scaleType string) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, _, err := rancher.GetHpaList(hpaOption, scaleType)

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}

	//fmt.Println("still here ")

	// options

	// Send the message to the channel
	// The Channel is available in the event message

	for i := range msg {
		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionText(msg[i], true))
	}

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleJsonConvert(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, err := jsonconvert.GetJsonConverterBlock()

	if err != nil {
		fmt.Println(err)
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}
	// options

	//buttonAprove := GetAprroveBtn("submit_kong_add_service")

	// Send the message to the channel
	// The Channel is available in the event message

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

func handleResetUserPwd(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, err := rancher.GetResetUserPwdBlock()

	if err != nil {
		fmt.Println(err)
	}
	// options

	//buttonAprove := GetAprroveBtn("submit_kong_add_service")

	// Send the message to the channel
	// The Channel is available in the event message

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}
func handleGitAddUser(client *slack.Client, event *slackevents.MessageEvent) error {
	//get ts
	ts := event.TimeStamp

	msg, err := github.GetGitMsg()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return err
	}

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil

}

func handleKongAddService(client *slack.Client, event *slackevents.MessageEvent, routesNumber int) error {
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	//inputBlock := GetInputBlock("add_kong_svc")

	msg, err := kong.GetKongBlock(routesNumber)

	if err != nil {
		fmt.Println(err)
	}
	// options

	//buttonAprove := GetAprroveBtn("submit_kong_add_service")

	// Send the message to the channel
	// The Channel is available in the event message

	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msg)

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}

func handleGrantUserCommand(client *slack.Client, event *slackevents.MessageEvent) error {
	err := errors.New("error in grant user command")

	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	inputBlock := common.GetTxtInputBlock("user_name", "Enter rancher user name:", "Ex: xuan.can")

	blockOption, err := rancher.GetRancherOptionBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}
	// options

	buttonAprove := common.GetAprroveBtn("submit_grant_user")

	// Send the message to the channel
	// The Channel is available in the event message
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionBlocks(inputBlock, blockOption, buttonAprove))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}
func handleAddUserCommand(client *slack.Client, event *slackevents.MessageEvent) error {

	err := errors.New("error in add user command")

	fmt.Println(err)
	//get ts
	ts := event.TimeStamp
	// Shared Available Options

	//create plain text block
	inputBlock := common.GetTxtInputBlock("user_name", "Enter rancher user name:", "Ex: xuan.can")

	blockOption, err := rancher.GetRancherOptionBlock()

	if err != nil {
		attachment := slack.Attachment{}
		//ts := event.TimeStamp
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
		attachment.Pretext = "Bot response:"

		_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
		return nil
	}
	// options

	buttonAprove := common.GetAprroveBtn("submit_ac_create_user")

	// Send the message to the channel
	// The Channel is available in the event message
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionBlocks(inputBlock, blockOption, buttonAprove))

	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}
	return nil
}

// handleAppMentionEvent is used to take care of the AppMentionEvent when the bot is mentioned
func handleAppMentionEvent(event *slackevents.AppMentionEvent, client *slack.Client) error {

	// Grab the user name based on the ID of the one who mentioned the bot
	user, err := client.GetUserInfo(event.User)
	if err != nil {
		return err
	}
	// Check if the user said Hello to the bot
	text := strings.ToLower(event.Text)

	//get ts to ans user in thread
	ts := event.TimeStamp

	// Create the attachment and assigned based on the message
	attachment := slack.Attachment{}
	// Add Some default context like user who mentioned the bot
	attachment.Fields = []slack.AttachmentField{
		{
			Title: "Date",
			Value: time.Now().String(),
		}, {
			Title: "Initializer",
			Value: user.Name,
		},
	}
	if strings.Contains(text, "hello") {
		// Greet the user
		attachment.Text = fmt.Sprintf("Hello %s", user.Name)
		attachment.Pretext = "Greetings"
		attachment.Color = "#4af030"
	} else {
		// Send a message to the user
		attachment.Text = fmt.Sprintf("How can I help you %s?", user.Name)
		attachment.Pretext = "How can I be of service"
		attachment.Color = "#3d3d3d"
	}

	// Send the message to the channel
	// The Channel is available in the event message
	_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))
	if err != nil {
		return fmt.Errorf("failed to post message: %w", err)
	}

	return nil
}
