package common

import (
	"errors"
	"fmt"
	"log"
	"os"

	"github.com/slack-go/slack"
	"github.com/spf13/viper"
)

func GetUserManagerID(userID string) (string, error) {

	v, err := GetViperClient("user_manager.properties")
	if err != nil {
		return "", err
	}
	managerID := v.GetString(userID)
	return managerID, nil
}
func SetManagerToUser(managerName, userID string, client *slack.Client) error {

	_, err := client.GetUserByEmail(fmt.Sprintf("%s@tiki.vn", managerName))

	if err != nil {
		return err
	}

	v, err := GetViperClient("user_manager.properties")

	if err != nil {
		return err
	}

	v.Set(userID, managerName)
	v.WriteConfig()
	return nil
}

func getGenFileProfile(userID string) string {
	serverGenfile := ""

	return serverGenfile
}

func GetViperClient(fileName string) (*viper.Viper, error) {

	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(fileName)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {
		log.Println("file invalid, create new file", path+fileName)
		os.Create(path + fileName)
		return v, errors.New("cannot get config, create new one or path is invalid")
	}
	return v, nil
}
