package rancher

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"reflect"
	"regexp"
	"slack-bot/common"
	"slack-bot/sheet"
	"strconv"
	"strings"
	"time"

	"github.com/jedib0t/go-pretty/table"
	"github.com/joho/godotenv"
	"github.com/robfig/cron/v3"
	"github.com/slack-go/slack"
	"github.com/spf13/viper"
	"github.com/tidwall/gjson"
	"gopkg.in/Iwark/spreadsheet.v2"
)

func SendSetPodNumberToRancher(input string) error {

	//data input curDeployment.ProjectID+"|"+curDeployment.ID+"|"+podNumber+"|"+curHpa.ID+"|"+hpaMaxPod

	inputSplit := strings.Split(input, "|")

	index := 0
	projectID := inputSplit[index]
	index++
	deploymentID := inputSplit[index]
	index++
	podNumber := inputSplit[index]
	index++
	hpaID := inputSplit[index]
	index++
	hpaMaxPod := inputSplit[index]

	podNumberToInt, err := strconv.Atoi(podNumber)

	if err != nil {

		log.Println("error with pod number to int ", podNumber)
		return err
	}

	//update deployment
	var deployment Deployment
	deployment.ProjectID = projectID
	deployment.ID = deploymentID
	deployment.Name = strings.Split(deployment.ID, ":")[2]
	deployment.NamespaceId = strings.Split(deployment.ID, ":")[1]
	deployment.Scale = podNumberToInt

	statusCode := updateDeploymentDataCommand(deployment)

	//update hpa
	if hpaID != "" && podNumberToInt != 0 {
		var hpa Data
		hpa.ProjectID = projectID
		hpa.ID = hpaID
		hpa.TempMinReplicas = podNumberToInt

		hpaMaxPodToInt, err := strconv.Atoi(hpaMaxPod)

		if err != nil {
			return err
		}

		if hpaMaxPodToInt < podNumberToInt {
			hpaMaxPodToInt = podNumberToInt
		}
		hpa.TempMaxReplicas = hpaMaxPodToInt

		statusCode = updateHpaDataCommand(hpa)
	}

	if statusCode != 200 {
		return errors.New("error when send deployment update request to rancher")
	}

	return nil
}

func SetDeploymentReplica(client *slack.Client, input, channel, timestamp string) error {
	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	//ignore if message from another channel
	if CHANNEL_ID != channel {
		return nil
	}

	splitData := strings.Split(input, " ")

	if len(splitData) != 4 {
		return errors.New("format not correct, *set deploy <deployment> <pod number>*")
	}

	deploymentName := splitData[2]
	podNumber := splitData[3]

	rancherData, err := GetDeploymentWithDeploymentName(deploymentName)

	if err != nil {
		return err
	}

	podNumberToInt, err := strconv.Atoi(podNumber)

	if err != nil {
		return err
	}

	if podNumberToInt < 0 || podNumberToInt > 200 {
		return errors.New("pods number cannot below than 0 or more than 200")
	}

	deploymentsData, err := getDeploymentWithProjectId(rancherData.ProjectID, rancherData.Name, rancherData.NamespaceId)

	if err != nil {
		return err
	}

	var curDeployment Deployment
	for _, deployment := range deploymentsData.Deployment {

		if deployment.Name == deploymentName {
			curDeployment = deployment
			break
		}
	}

	//check number of current pods

	if curDeployment.Scale == podNumberToInt {
		return errors.New("notthing to do, pod number is as same as current pod number: " + podNumber)
	}
	deploymentHpa, err := getHpaWithProjectId(curDeployment.ProjectID, curDeployment.ID)

	if err != nil {
		return err
	}

	var curHpa HpaData
	for _, hpa := range deploymentHpa.Data {

		log.Println(hpa.WorkloadID)
		if hpa.WorkloadID == curDeployment.ID {
			curHpa = hpa
			break
		}
	}

	if curDeployment.ID == "" {
		return errors.New("cannot get deployment and hpa of " + deploymentName)
	}

	hasHpa := false
	hpaMaxPod := ""
	if curHpa.ID != "" {
		hasHpa = true
		hpaMaxPod = strconv.Itoa(curHpa.MaxReplicas)
	}

	preText := ""

	if hasHpa {
		preText = "*Warnings: This deployment has HPA, so I will set min Hpa to " + podNumber + ", if maxReplicas is small than " + podNumber + ", it will be set equal to this*"
	}

	preText += "\nCurrent deployment status\nDeployment ID: `" + curDeployment.ID + "`\nReplicas: `" + strconv.Itoa(curDeployment.DeploymentStatus.Replicas) + "`"
	text := "\nIf you approve, this deployment pod number will be set to " + podNumber

	attachment, err := common.CreateAttachment("approve_set_deployment_pod", preText, text, "approve_set_deployment_pod", curDeployment.ProjectID+"|"+curDeployment.ID+"|"+podNumber+"|"+curHpa.ID+"|"+hpaMaxPod)

	if err != nil {
		return err
	}

	client.PostMessage(channel, slack.MsgOptionTS(timestamp), slack.MsgOptionAttachments(attachment))

	return nil
}

func SendRequeststRollbackToSystem(description, urlRedeploy, deploymentName string, client *slack.Client, user *slack.User) error {

	attacchment, err := common.CreateAttachment("system_approve_rollback", "<!subteam^SVALNFK27> User `"+user.Name+"` has submitted request for rollback deployment "+description, "", "system_approve_rollback", user.ID+" "+urlRedeploy+" "+deploymentName)

	if err != nil {
		return err
	}

	CHANNEL := os.Getenv("CHANNEL_ID")
	client.PostMessage(CHANNEL, slack.MsgOptionAttachments(attacchment))
	return nil
}

func HandleScaleArgs(input []string) error {

	log.Println(input)

	podScale := input[1]

	listDeployment := input[2]

	err := scalePods(podScale, listDeployment)

	if err != nil {
		return err
	}
	return nil
}

func GetDeploymentSecrets(deployment Data) ([]string, error) {
	var secrets []string

	curContainer, _, err := GetRancherContainers(deployment)

	if err != nil {
		return secrets, err
	}

	log.Printf("container data: %+v", curContainer.ENVFROM)

	for _, secretRef := range curContainer.ENVFROM {
		if secretRef.SECRETREF.Name == "" {
			continue
		}
		secrets = append(secrets, secretRef.SECRETREF.Name)
	}

	if len(secrets) == 0 {
		return secrets, errors.New("cannot find any mount secret")
	}
	return secrets, nil
}
func AddDeployToUser(data string) error {

	err := writeNewAddRedeploy(data)

	if err != nil {
		return err
	}

	return nil
}

func VerifyAddRedeployData(user, input string) (string, error) {

	data := strings.TrimSpace(input)

	dataSplit := strings.Split(data, " ")

	if len(dataSplit) != 3 {
		return "", errors.New("input wrong format redeploy deployment ")
	}

	deployment := dataSplit[2]

	err := common.ValidateInput(deployment, "name")

	if err != nil {
		return "", err
	}

	//check profile has add deployment or not

	_, err = checkUserValid(user, deployment)

	if err == nil {
		return "", errors.New("This deployment's already added to you, please redeploy if needed :tamtu:")
	}
	//check deployment is exist
	_, deploymentFound, _, err := GetDeploymentFindInputData(deployment)

	if err != nil {
		return "", err
	}

	deploySplit := strings.Split(deploymentFound, ",")

	deployFound := false
	for i := range deploySplit {
		if deploySplit[i] == deployment {
			deployFound = true
			break
		}
	}

	if !deployFound {
		err = HandleDeploymentUpdateLocalFile()
		if err != nil {
			log.Println(err)
		}
		return deployment, errors.New("cannot find deployment\nUpdating local file, please retry after 10 seconds if your deployment is new")
	}

	return deployment, nil
}

//redeploy deployment
func HandleRedeployMsg(user, input string, client *slack.Client) error {

	data := strings.TrimSpace(input)

	dataSplit := strings.Split(data, " ")

	if len(dataSplit) != 2 {
		return errors.New("input wrong format redeploy deployments")
	}

	deployment := dataSplit[1]
	err := common.ValidateInput(deployment, "name")

	if err != nil {
		return err
	}

	deployLeft, err := checkUserValid(user, deployment)

	if err != nil {
		return err
	}

	if deployLeft == 0 {
		return errors.New("You redeploy per day has run out, please call systemoi to help")
	}

	//only accept redeploy in specific time
	err = checkTimeValid("user redeploy")

	if err != nil {
		return err
	}
	msg, err := HandleReRunDeploymentBtn(deployment)
	if err != nil {
		return err
	}

	//only person who type command could view this message
	_, _, err = client.PostMessage(user, slack.MsgOptionAttachments(msg))

	if err != nil {
		return err
	}

	err = updateTimeUserRedeploy(user, deployment, deployLeft)

	if err != nil {
		return err
	}

	attachment := slack.Attachment{}
	attachment.Color = "#f59042"
	attachment.Text = "You have `" + strconv.Itoa(deployLeft-1) + "` time left to redeploy this deployment today"

	client.PostMessage(user, slack.MsgOptionAttachments(attachment))

	return nil
}

func updateTimeUserRedeploy(user, deployment string, deployLeft int) error {
	//load file
	godotenv.Load(".env")
	file_name := os.Getenv("REDEPLOY_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return errors.New("cannot get file, create new one")
	}

	dataValue := v.GetString(user + "-" + deployment)

	if dataValue == "" {
		return errors.New("cannot get deployment data, please check file")
	}

	deployLeft -= 1
	v.Set(user+"-"+deployment, deployLeft)

	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	return nil
}

func checkUserValid(user, deployment string) (int, error) {
	//load file
	godotenv.Load(".env")
	file_name := os.Getenv("REDEPLOY_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return 0, errors.New("cannot get file, create new one")
	}

	dataValue := v.GetString(user + "-" + deployment)

	if dataValue == "" {
		return 0, errors.New("cannot get deployment " + deployment + "\n you should use `add deploy " + deployment + "` to get permission first")
	}

	if dataValue == "0" {
		return 0, nil
	}
	dataValueToInt, err := strconv.Atoi(dataValue)

	if err != nil {
		return 0, err
	}
	return dataValueToInt, nil
}

// update info to cronjob scale down for optimize cost, not run when event is trigger
func UpdateScaleProfileLocal(currentEvent string) error {
	//load file
	godotenv.Load(".env")
	file_name := os.Getenv("SCALE_DOWN_INFO")
	path := os.Getenv("SCALE_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return errors.New("cannot get file, create new one")
	}

	v.Set("current_event_running", currentEvent)
	//write to file
	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil
}
func SendConfirmOptimizeData(enableOptimize, eventScaling string) error {
	//load file
	godotenv.Load(".env")
	file_name := os.Getenv("SCALE_DOWN_INFO")
	path := os.Getenv("SCALE_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		os.Create(path + file_name)
		return errors.New("cannot get file, create new one")
	}

	//v.Set("save_cost_enable", enableOptimize)

	//time := strings.Split(timeScaleInfo, "-")

	// if len(time) != 2 {
	// 	return errors.New("time data not correct")
	// }
	// timeRunNormal := time[0]
	// timeRunOptimize := time[1]

	v.Set("save_cost_enable", enableOptimize)
	v.Set("current_event_running", eventScaling)
	// v.Set("time_run_scale_optimize", timeRunOptimize)
	// v.Set("time_run_scale_normal", timeRunNormal)
	//write to file
	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil
}

func UpdateOptimizeCostProfile(enableOptimize, timeRunOptimizeCost string) error {

	log.Println("Data input", enableOptimize, timeRunOptimizeCost)

	return nil
}

func HandleInitScaleOptimizeCostMsg() (slack.MsgOption, error) {
	//var msg slack.MsgOption

	msg, err := getScaleOptimizeBlock()

	if err != nil {
		return msg, err
	}
	return msg, nil
}

func ScaleDownCronJob(client *slack.Client, scaleType string) error {
	godotenv.Load(".env")
	fmt.Println("This task will run periodically")

	log.Println("Current hour time is ", time.Now().UTC())

	//log.Println(sheet.Columns[1])

	scaleProfile, err := getScaleDownProfile()

	if err != nil {
		return err
	}

	Channel := os.Getenv("CHANNEL_ID")

	if scaleProfile.CurrentEvent == "" {
		_, _, err = client.PostMessage(Channel, slack.MsgOptionText("`Current Event "+scaleProfile.CurrentEvent+" is empty, please init this value`", false))
		if err != nil {
			return err
		}

		return nil
	}

	if scaleProfile.CurrentEvent != "Scale Normal" {

		_, _, err := client.PostMessage(Channel, slack.MsgOptionText("`Current Event "+scaleProfile.CurrentEvent+" is running, not scale optimize cost for today`", false))

		if err != nil {
			return err
		}

		return nil

	}

	log.Println("save cost enable is ", scaleProfile.Enable)

	hpaList, deploymentList, err := startReducePodsWithProfile(client, scaleProfile, scaleType)

	if err != nil {
		return err
	}

	//sendData
	if len(hpaList) > 0 || len(deploymentList) > 0 {
		err = sendDataChanged(client, hpaList, deploymentList)

		if err != nil {
			return err
		}
	}
	//log.Println(hpaList, deploymentList)

	//now update google data, retry 3 times

	err = RetryFunction("update google data", 5, 120)

	if err != nil {
		return err
	}

	return nil

}

func updateSaveCostInfo(runSaveCost bool) error {
	file_name := os.Getenv("SCALE_DOWN_INFO")
	path := os.Getenv("SCALE_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("file invalid, create new file", path+file_name)
		return errors.New("cannot get file, create new one")
	}

	layout := "2022-08-20"
	lastRunOp := v.GetString("last_run")

	time, err := time.Parse(layout, lastRunOp)

	log.Println(time)
	if runSaveCost {

	} else {

	}
	return nil
}

func UpdateScaleNormalData() (slack.Attachment, error) {

	log.Println("go to update scale normal data")
	var msg slack.Attachment

	err := RetryFunction("update google data", 5, 120)

	if err != nil {
		return msg, err
	}

	scaleProfile, err := getScaleDownProfile()

	if err != nil {
		return msg, err
	}

	if scaleProfile.CurrentEvent == "" {

		return msg, errors.New("cannot get current event running, please check")
	}

	if scaleProfile.CurrentEvent != "Scale Normal" {
		msg.Text = "Current event " + scaleProfile.CurrentEvent + " is running, not update normal data"
		return msg, nil
	}

	sheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		return msg, err
	}

	desiredReplicasPos := -1
	minReplicasPos := -1
	maxReplicasPos := -1
	scaleNormalPos := -1
	scaleNormalAfterEventPos := -1
	deloymentPos := -1
	//get eventPos position

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	t.AppendHeader(table.Row{"Line", "Deployment", "Old Scale", "New Scale"})
	needChange := false
	for i, row := range sheet.Rows {

		if i == 0 {
			for j, cell := range row {

				switch strings.TrimSpace(cell.Value) {
				case "Desired Replicas":
					desiredReplicasPos = j
				case "Deployment":
					deloymentPos = j
				case "Scale Normal":
					scaleNormalPos = j
				case "Scale After Event":
					scaleNormalAfterEventPos = j
				case "Min Replicas":
					minReplicasPos = j
				case "Max Replicas":
					maxReplicasPos = j
				}
			}

			if desiredReplicasPos == -1 {
				return msg, errors.New("cannot find header Desired Replicas,please check and try again")
			}
			if deloymentPos == -1 {
				return msg, errors.New("cannot find header Deployment,please check and try again")
			}
			if scaleNormalPos == -1 {
				return msg, errors.New("cannot find header Scale Normal,please check and try again")
			}
			if scaleNormalAfterEventPos == -1 {
				return msg, errors.New("cannot find header Scale After Event,please check and try again")
			}
			if minReplicasPos == -1 {
				return msg, errors.New("cannot find header Min Replicas,please check and try again")
			}
			if maxReplicasPos == -1 {
				return msg, errors.New("cannot find header Max Replicas,please check and try again")
			}
			continue
		}

		//log.Println("position ", deloymentPos, desiredReplicasPos, minReplicasPos)

		deployment := row[deloymentPos].Value
		desiredRep := row[desiredReplicasPos].Value
		minRep := row[minReplicasPos].Value
		maxRep := row[maxReplicasPos].Value
		scaleNormal := row[scaleNormalPos].Value
		scaleNormalAE := row[scaleNormalAfterEventPos].Value

		if deployment == "" {
			//log.Println("Deployment ", deployment)
			break
		}

		if desiredRep == "" {
			return msg, errors.New("cannot get desired replica data at line " + strconv.Itoa(i+1))
		}

		//log.Println(deployment, desiredRep, minRep, maxRep, scaleNormal, scaleNormalAE)
		//if deployment has no hpa
		if minRep == "" && maxRep == "" {

			if scaleNormal != desiredRep {
				sheet.Update(i, scaleNormalPos, desiredRep)
				sheet.Update(i, scaleNormalAfterEventPos, desiredRep)

				t.AppendRow([]interface{}{i + 1, deployment, scaleNormal, desiredRep})

				needChange = true
			}

			//if deployment has hpa
		} else if minRep != "" && maxRep != "" {

			hpaData := minRep + "-" + maxRep
			if scaleNormal != hpaData {
				sheet.Update(i, scaleNormalPos, hpaData)

				if strings.ToLower(scaleNormalAE) != "n/a" {
					sheet.Update(i, scaleNormalAfterEventPos, hpaData)
				}

				t.AppendRow([]interface{}{i + 1, deployment, scaleNormal, hpaData})
				needChange = true
			}

			// if none of above is oke, somethings wrong
		} else {
			return msg, errors.New("somethings wrong with min/max replicas line " + strconv.Itoa(i+1))
		}

	}

	//update google data
	if needChange {
		sheet.Synchronize()

		msg.Pretext = ":mag: Bot response after update, data has changed:"

		msg.Text = "```" + t.Render() + "```"

		msg.Color = "#34eb5b"
	} else {

		msg.Pretext = ":mag: Bot response"

		msg.Text = "``` All scale normal data is up to date```"

		msg.Color = "#34eb5b"
	}

	return msg, nil
}

// func GetFieldRancherUserString(user *RancherUser, field string) string {
// 	r := reflect.ValueOf(user)
// 	f := reflect.Indirect(r).FieldByName(field)
// 	return f.String()
// }

func GetFieldString(rancherObj *RancherObject, field string) string {
	r := reflect.ValueOf(rancherObj)
	f := reflect.Indirect(r).FieldByName(field)
	return f.String()
}

func (obj RancherObject) IsEmpty() bool {
	return reflect.DeepEqual(obj, RancherObject{})
}

func HandleEnableRemindSysReplicas(client *slack.Client, isEnable bool) error {
	godotenv.Load(".env")
	file_name := os.Getenv("REMIND_SYS_FILE_NAME")
	path := os.Getenv("REMIND_SYS_PATH_NAME")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		log.Println("path", path+file_name)
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}

	isRemind := v.Get("enable_remind_sys")

	if isRemind == "" {
		return errors.New("cannot get remind data")
	}

	if isEnable {
		err = HandleRemindSysAboutReplicas(client)

		if err != nil {
			return err
		}
		v.Set("enable_remind_sys", "true")
	} else {
		v.Set("enable_remind_sys", "false")
	}

	//write to file
	//v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil
}
func HandleRemindSysAboutReplicas(client *slack.Client) error {

	log.Println("Begin of remind sys about replicas")

	//var c *cron.Cron

	c := cron.New()

	errorCode := -1

	_, err := c.AddFunc("0 8 * * *", func() {
		godotenv.Load(".env")
		file_name := os.Getenv("REMIND_SYS_FILE_NAME")
		path := os.Getenv("REMIND_SYS_PATH_NAME")
		v := viper.New()
		v.SetConfigName(file_name)
		v.SetConfigType("properties")
		v.AddConfigPath(path)
		err := v.ReadInConfig() // Find and read the config file
		if err != nil {         // Handle errors reading the config file
			log.Println("path", path+file_name)
			os.Create(path + file_name)

		}
		isRemind := v.Get("enable_remind_sys")

		if isRemind != "true" {
			c.Stop()
		} else {
			picUsers := make(map[string]*EventRemindStruct)
			countDeploymentChanged := 0
			//update google data first
			//now update google data, retry 3 times

			//retry handle google update

			err = RetryFunction("update google data", 5, 120)

			if err != nil {
				log.Println("somethings wrong when update gg data")
				log.Println(err)
				//errorCode = 0
			}
			fmt.Println("Check replias hourly")

			sheet, err := sheet.GetGoogleSheetData()

			if err != nil {
				//errorCode = 0
				log.Println(err)
			}

			normalRepPos := -1
			curRepPos := -1
			deploymentPos := -1
			picUserPos := -1

			for i, row := range sheet.Rows {

				if i == 0 {
					for j, cell := range row {
						if strings.TrimSpace(cell.Value) == "Scale Normal" {
							normalRepPos = j
						}

						if strings.TrimSpace(cell.Value) == "Current Replicas" {
							curRepPos = j
						}

						if strings.TrimSpace(cell.Value) == "Deployment" {
							deploymentPos = j
						}

						if strings.TrimSpace(cell.Value) == "PIC" {
							picUserPos = j
						}
					}

					continue
				}

				if normalRepPos == -1 || curRepPos == -1 || deploymentPos == -1 || picUserPos == -1 {
					log.Println("Somethings wrong with data header")
					errorCode = 0
					break
				}

				if row[normalRepPos].Value == "" || row[curRepPos].Value == "" || row[deploymentPos].Value == "" {
					errorCode = 0
					log.Println("Row data is empty ", row[normalRepPos].Value, row[curRepPos].Value)
					break
				}

				needAdd := false
				if row[normalRepPos].Value != row[curRepPos].Value {

					tmpEvent := new(EventRemindStruct)
					//log.Println("Deployment checking ", row[deploymentPos].Value, row[normalRepPos].Value, row[curRepPos].Value)
					//log.Println("Normal value ", row[normalRepPos].Value)
					//log.Println("Current value ", row[curRepPos].Value)
					tmpEvent.Author = row[picUserPos].Value
					tmpEvent.LineError = strconv.Itoa(i + 1)
					tmpData := new(Data)
					tmpData.Name = row[deploymentPos].Value

					tmpData.Position = i + 1
					//is hpa
					if strings.Contains(row[normalRepPos].Value, "-") {
						//get min hpa replicas

						minValue := strings.Split(row[normalRepPos].Value, "-")[0]
						maxValue := strings.Split(row[normalRepPos].Value, "-")[1]

						log.Println(" Min max value ", minValue, maxValue)
						minValueToNum, err := strconv.Atoi(minValue)
						if err != nil {
							log.Println(" Error ", minValue, maxValue)
							errorCode = 0
							break
						}

						maxValueToNum, err := strconv.Atoi(maxValue)

						if err != nil {
							log.Println(" Error ", minValue, maxValue)
							errorCode = 0
							break
						}

						curRepToNum, err := strconv.Atoi(row[curRepPos].Value)

						if err != nil {
							log.Println(" Error ", minValue, maxValue)
							errorCode = 0
							break
						}

						if curRepToNum < minValueToNum || curRepToNum >= maxValueToNum {
							log.Println("value min max ")
							//if hpa set as 10-10 and cur Rep is 10, continue
							log.Println(minValueToNum, maxValueToNum, curRepToNum)
							if minValueToNum == maxValueToNum && minValueToNum == curRepToNum {
								log.Println("is true ")
								continue
							}
							tmpData.CurrentRepData = row[curRepPos].Value
							tmpData.ReplicaData = row[normalRepPos].Value
							log.Println("append to replica data", row[normalRepPos].Value)
							countDeploymentChanged++
							needAdd = true

						}

						// is deployment
					} else {
						tmpData.CurrentRepData = row[curRepPos].Value
						tmpData.ReplicaData = row[normalRepPos].Value
						countDeploymentChanged++
						needAdd = true

					}

					//tmpEvent.Data = append(tmpEvent.Data, *tmpData)

					if needAdd {
						if picUsers[row[picUserPos].Value] != nil {
							picUsers[row[picUserPos].Value].Data = append(picUsers[row[picUserPos].Value].Data, *tmpData)

						} else {
							tmpEvent.Data = append(tmpEvent.Data, *tmpData)
							picUsers[row[picUserPos].Value] = tmpEvent
						}
					}

				}
			}

			channel := os.Getenv("CHANNEL_ID")
			if countDeploymentChanged < 30 && len(picUsers) > 0 {

				log.Println("Count change and length pic ", countDeploymentChanged, len(picUsers))
				attachment := slack.Attachment{}
				//ts := event.TimeStamp

				//picUsers, err := common.GetPicUsers(client)
				attachment.Color = "#f57402"
				attachment.Pretext = ":mag: Bot response:\n *Warning: Data following lines have current Replicas different with Normal Replicas*"
				for _, user := range picUsers {

					t := table.NewWriter()
					t.SetOutputMirror(os.Stdout)
					t.AppendHeader(table.Row{"Deployment", "Current Replicas", "Normal Replicas Value"})

					for _, data := range user.Data {
						t.AppendRow([]interface{}{strconv.Itoa(data.Position) + ". " + data.Name, data.CurrentRepData, data.ReplicaData})
					}

					slackUser, err := client.GetUserByEmail(user.Author + "@tiki.vn")
					if err != nil {
						log.Println(err)
						errorCode = 0
						break
					}

					reponseText := "<@" + slackUser.ID + "> Your cluster have deployments need to be awared following this table below:"

					reponseText += "```" + t.Render() + "```\n"
					attachment.Text += fmt.Sprintf(reponseText)

				}

				_, _, err = client.PostMessage(channel, slack.MsgOptionAttachments(attachment))

				if err != nil {
					errorCode = 0
				}

			} else {
				attachment := slack.Attachment{}
				//ts := event.TimeStamp
				attachment.Text = "Current Replicas of all deployments are equal to Normal Replicas Value or an Event is lauching"
				attachment.Pretext = "Bot response:"
				attachment.Color = "#32a852"
				_, _, err = client.PostMessage(channel, slack.MsgOptionAttachments(attachment))

				if err != nil {
					errorCode = 0
				}
			}
			if errorCode == 0 {
				log.Println("Current error Code = ", errorCode)
				log.Println("Stop cronjob")
				attachment := slack.Attachment{}

				//ts := event.TimeStamp
				attachment.Text = "Stopped cronjob due to error"
				attachment.Pretext = "Bot response:"
				attachment.Color = "#ed210e"
				_, _, err = client.PostMessage(channel, slack.MsgOptionAttachments(attachment))

				if err != nil {
					errorCode = 0
				}
				c.Stop()
			}

		}

	})

	if err != nil {
		return err
	}
	//start cronjob
	c.Start()

	return nil
}

func GetUserApproveReRunData(input string) error {

	inputSplit := strings.Split(input, "@")

	if len(inputSplit) != 2 {
		return errors.New("input rerun not correct")
	}
	projectID := inputSplit[0]

	deploymentID := inputSplit[1]

	log.Println("deploymentID: ", deploymentID, projectID)
	err := redeployDeploymentWithProjectIdAndDeploymentID(projectID, deploymentID)

	if err != nil {
		//retry one more time
		time.Sleep(1 * time.Second)
		err := redeployDeploymentWithProjectIdAndDeploymentID(projectID, deploymentID)
		if err != nil {
			return err
		}
		return nil
	}

	return nil
}

func HandleReRunDeploymentBtn(deploymentValue string) (slack.Attachment, error) {
	var attachment slack.Attachment
	var valueSubmit string
	godotenv.Load(".env")
	file_name := os.Getenv("DEPLOYMENT_FIND_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return attachment, errors.New("file not exist, create an empty file")
	}

	keys := v.AllKeys()

	log.Println("Total key:", len(keys), file_name, path)

	var deployments []Data
	for _, key := range keys {

		splitKey := strings.Split(key, "@")

		if len(splitKey) != 6 {
			return attachment, errors.New("key is not correct form, need to update")
		}

		//log.Println(splitKey[3])

		if splitKey[3] == deploymentValue {
			var deployment Data

			deployment.ClusterName = splitKey[0]
			deployment.ProjectName = splitKey[1]
			deployment.NamespaceId = splitKey[2]
			deployment.Name = splitKey[3]
			deployment.ProjectID = splitKey[4]
			deployment.Type = splitKey[5]
			deployments = append(deployments, deployment)
			break
		}
	}

	if len(deployments) == 0 {
		return attachment, errors.New("Deployment not found")
	}
	attachment.Color = "#2484BE"

	attachment.Pretext = "Confirm redeploy deployment following beblow:\n"
	attachment.CallbackID = "user_rerun_btn"
	attachment.Fallback = "user_rerun_btn"

	var cluster slack.AttachmentAction

	cluster.Name = "cluster_rerun_choosen"
	cluster.Type = "select"
	cluster.Text = "Select cluster"

	var project slack.AttachmentAction

	project.Name = "project_rerun_choosen"
	project.Type = "select"
	project.Text = "Select Project"

	var deploymentData slack.AttachmentAction

	deploymentData.Name = "deployment_rerun_choosen"
	deploymentData.Type = "select"
	deploymentData.Text = "Select Deployment"

	for i, deployment := range deployments {

		var clusterOption slack.AttachmentActionOption
		clusterOption.Text = deployment.ClusterName
		clusterOption.Value = deployment.ClusterName
		cluster.Options = append(cluster.Options, clusterOption)

		var projectOption slack.AttachmentActionOption
		projectOption.Text = deployment.ProjectName + ":" + deployment.NamespaceId
		projectOption.Value = deployment.ProjectID
		project.Options = append(project.Options, projectOption)

		var deploymentOption slack.AttachmentActionOption
		deploymentOption.Text = deployment.Name
		deploymentOption.Value = deployment.NamespaceId + ":" + deployment.Name
		deploymentData.Options = append(deploymentData.Options, deploymentOption)

		if i == 0 {
			cluster.SelectedOptions = append(cluster.SelectedOptions, clusterOption)
			project.SelectedOptions = append(project.SelectedOptions, projectOption)
			deploymentData.SelectedOptions = append(deploymentData.SelectedOptions, deploymentOption)
		}

		valueSubmit += deployment.ProjectID + "@" + deployment.Type + ":" + deployment.NamespaceId + ":" + deployment.Name + " "
	}

	attachment.Actions = append(attachment.Actions, cluster)
	attachment.Actions = append(attachment.Actions, project)
	attachment.Actions = append(attachment.Actions, deploymentData)
	buttonAction := slack.AttachmentAction{
		Name:  "user_rerun_apply_btn",
		Text:  "Approve",
		Style: "primary",
		Type:  "button",
		Value: valueSubmit,
		Confirm: &slack.ConfirmationField{
			Title:  "Confirm",
			Text:   "Are you sure? \n",
			OkText: "Apply",
		},
	}

	attachment.Actions = append(attachment.Actions, buttonAction)

	return attachment, nil
}

func GetRemindEventOkBlock(input string) error {

	err := RetryFunction("update google data", 5, 120)

	if err != nil {
		return err
	}
	return nil
}

func HandleUserSubmitEditRemindEventBtn(blocks map[string]map[string]slack.BlockAction) (slack.Attachment, error) {

	//log.Println(blocks)

	var deployments []Data
	var responseAttValue string
	var err error
	var attachment slack.Attachment
	if len(blocks) == 0 {
		return attachment, errors.New("notthing to do with empty blocks")
	}

	// sheet, err := sheet.GetGoogleSheetData()
	// if err != nil {
	// 	return err
	// }

	//table for display att

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	t.AppendHeader(table.Row{"Deployment", "Scale"})

	eventName := blocks["remind_event_header"]["choose_event_remind"].SelectedOption.Value
	responseAttValue += strings.ReplaceAll(eventName, " ", "-") + " "
	for i, block := range blocks {

		log.Println("What is", i)
		re := regexp.MustCompile("[0-9]+")
		getKey := re.FindAllString(i, -1)
		if block["choose_event_remind"].SelectedOption.Value != "" {
			log.Println("data event", block["choose_event_remind"].SelectedOption.Value)
			continue
		}

		// log.Println("Loop 1 time ", count)

		deploymentData := block["remind_deployment_choose_"+getKey[0]].SelectedOption.Value

		replicas := block["remind_replicas_choose_"+getKey[0]].SelectedOption.Value

		minRep := block["remind_replicas_choose_min_"+getKey[0]].SelectedOption.Value

		maxRep := block["remind_replicas_choose_max_"+getKey[0]].SelectedOption.Value

		minRepInt, _ := strconv.Atoi(minRep)
		maxRepInt, _ := strconv.Atoi(maxRep)
		replicaInt, _ := strconv.Atoi(replicas)
		if minRepInt == 0 && replicaInt == 0 {
			return attachment, errors.New("Min Replicas cannot smaller than 1")

		}

		if minRepInt > maxRepInt {
			return attachment, errors.New("Min Replicas cannot greater than Max Replicas")
		}

		dataSplit := strings.Split(deploymentData, ". ")

		if len(dataSplit) != 2 {
			return attachment, errors.New("deploymentData is not correct")
		}

		position := dataSplit[0]
		deploymentName := dataSplit[1]
		replicaData := ""

		if replicas == "" {
			replicaData = minRep + "-" + maxRep
		} else {
			replicaData = replicas
		}

		if replicaData == "" || position == "" || deploymentName == "" {
			return attachment, errors.New("cannot get replica data")
		}

		var deployment Data

		deployment.Name = deploymentName
		deployment.Position, err = strconv.Atoi(position)

		if err != nil {
			return attachment, err
		}

		deployment.ReplicaData = replicaData

		deployments = append(deployments, deployment)
		//log.Println(block["remind_deployment_choose_1"].SelectedOption.Value)

		responseAttValue += position + ":" + deployment.Name + ":" + replicaData + " "
		t.AppendRow([]interface{}{position + ". " + deployment.Name, replicaData})
	}

	attachment, err = common.CreateAttachment("confirm_user_edit_deployment_ac", ":mag: Please confirm deployment value for "+eventName, "```"+t.Render()+"```", "confirm_user_edit_deployment_btn", responseAttValue)

	//err = updateGoogleSheetData(deployments, eventName, sheet)

	if err != nil {
		return attachment, err
	}

	return attachment, nil
}

func UpdateGoogleSheetData(input string) error {

	sheet, err := sheet.GetGoogleSheetData()
	if err != nil {
		return err
	}

	inputSplit := strings.Split(input, " ")

	if len(inputSplit) < 2 {
		return errors.New("Notthing to do")
	}

	log.Println("eventName: ", inputSplit)
	eventName := strings.ReplaceAll(inputSplit[0], "-", " ")

	eventPos := -1
	deploymentPos := -1
	normalRepPos := -1
	//get eventPos position
	for i, row := range sheet.Rows {
		if i == 0 {
			for j, cell := range row {
				if strings.TrimSpace(cell.Value) == eventName {
					eventPos = j

				}

				if strings.TrimSpace(cell.Value) == "Deployment" {
					deploymentPos = j
				}

				if strings.TrimSpace(cell.Value) == "Scale Normal" {
					normalRepPos = j
				}
			}
		} else {
			break
		}
	}

	if eventPos == -1 || deploymentPos == -1 {
		return errors.New("Cannot find header " + eventName + " or header Deployment")

	}

	for i, inputData := range inputSplit {

		if i == 0 {
			continue
		}

		inputDataSplit := strings.Split(inputData, ":")

		if len(inputDataSplit) != 3 {
			return errors.New("Data wrong length, need to check value " + inputData)
		}

		posistion, err := strconv.Atoi(inputDataSplit[0])

		if err != nil {
			return err
		}

		deploymentName := inputDataSplit[1]

		if sheet.Rows[posistion][deploymentPos].Value != deploymentName {
			return errors.New("Data is not correct at line " + strconv.Itoa(posistion) + " deployment name " + deploymentName)
		}

		//sheet.Rows[rowPos][eventPos].Value = replicaData

		if sheet.Rows[posistion][eventPos].Value != "" {
			return errors.New("This event replicas has already filled, please contact @systemoi to change this value")
		}

		replicaData := inputDataSplit[2]
		//if replica event == replica normal => no need to add
		if replicaData == sheet.Rows[posistion][normalRepPos].Value {
			replicaData = "n/a"
		}

		sheet.Update(posistion, eventPos, replicaData)
	}

	sheet.Synchronize()

	return nil
}

func GetRemindEventEditBlock(input string) (slack.MsgOption, error) {
	return getRemindEventEditBlock(input)
}
func GetRemindEventValueInput(eventInput string, eventBase string) (map[string]*EventRemindStruct, error) {

	events := make(map[string]*EventRemindStruct)

	//var event []EventRemindStruct
	sheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		log.Println(err)
	}

	//needAddToMap := false
	authorPos := -1
	//eventPos := -1
	hpaPos := -1
	statePos := -1
	clusterPos := -1
	projectPos := -1
	namespacePos := -1
	namePos := -1
	eventInputPos := -1
	eventBasePos := -1
	normalRepPos := -1
	//enablePos := -1
	//isAppend := false

	if eventInput == "" || eventBase == "" {
		return events, errors.New("Input cannot be empty")
	}

	for i, row := range sheet.Rows {
		//ignore head row
		if i == 0 {
			for j, cell := range row {

				if strings.TrimSpace(cell.Value) == "Author" {
					authorPos = j
				}

				if strings.TrimSpace(cell.Value) == eventInput {
					eventInputPos = j
				}

				if strings.TrimSpace(cell.Value) == eventBase {
					eventBasePos = j
				}

				if strings.TrimSpace(cell.Value) == "Cluster" {
					clusterPos = j
				}

				if strings.TrimSpace(cell.Value) == "Project" {
					projectPos = j
				}

				if strings.TrimSpace(cell.Value) == "Namespace" {
					namespacePos = j
				}

				if strings.TrimSpace(cell.Value) == "Deployment" {
					namePos = j
				}
				if strings.TrimSpace(cell.Value) == "State" {
					statePos = j
				}

				if strings.TrimSpace(cell.Value) == "HpaID" {
					hpaPos = j
				}

				if strings.TrimSpace(cell.Value) == "Scale Normal" {
					normalRepPos = j
				}
			}

			continue
		}

		if eventBasePos == -1 {
			return events, errors.New("cannot find event base " + eventBase)
		}

		if eventInputPos == -1 {
			return events, errors.New("cannot find event input " + eventInput)
		}

		if authorPos == -1 {
			return events, errors.New("cannot find header Author")
		}

		if clusterPos == -1 {
			return events, errors.New("cannot find header Cluster")
		}

		if projectPos == -1 {
			return events, errors.New("cannot find header Project")
		}

		if namespacePos == -1 {
			return events, errors.New("cannot find header Namespace")
		}

		if namePos == -1 {
			return events, errors.New("cannot find header Deployment")
		}

		if statePos == -1 {
			return events, errors.New("cannot find header State")

		}

		if hpaPos == -1 {
			return events, errors.New("cannot find header HpaID")
		}

		if normalRepPos == -1 {
			return events, errors.New("cannot find header Scale Normal")
		}

		// if enablePos == -1 {
		// 	return event, errors.New("cannot find header Enable")
		// }

		authorName := strings.TrimSpace(row[authorPos].Value)
		clusterName := strings.TrimSpace(row[clusterPos].Value)
		projectName := strings.TrimSpace(row[projectPos].Value)
		namespace := strings.TrimSpace(row[namespacePos].Value)
		deploymentName := strings.TrimSpace(row[namePos].Value)
		state := strings.TrimSpace(row[statePos].Value)
		eventInputName := strings.TrimSpace(row[eventInputPos].Value)
		eventBaseName := strings.TrimSpace(row[eventBasePos].Value)
		hpaID := strings.TrimSpace(row[hpaPos].Value)

		//break if line empty
		if authorName == "" && clusterName == "" && projectName == "" || deploymentName == "" {
			break
		}

		if authorName == "" {
			return events, errors.New("Author at line " + strconv.Itoa(i) + " is empty")
		}

		if clusterName == "" {
			return events, errors.New("Cluster at line " + strconv.Itoa(i) + " is empty")

		}

		if projectName == "" {
			return events, errors.New("Project at line " + strconv.Itoa(i) + " is empty")

		}

		if namespace == "" {
			return events, errors.New("Namespace at line " + strconv.Itoa(i) + " is empty")

		}

		if deploymentName == "" {
			return events, errors.New("Deployment at line " + strconv.Itoa(i) + " is empty")

		}

		if eventBaseName == "" {
			return events, errors.New("Event base at line " + strconv.Itoa(i) + " is empty")
		}

		if state == "" {
			return events, errors.New("State base at line " + strconv.Itoa(i) + " is empty")
		}

		tmpEvent := new(EventRemindStruct)

		tmpEvent.Author = authorName
		tmpEvent.LineError = strconv.Itoa(i)
		tmpData := new(Data)
		tmpData.ClusterName = clusterName
		tmpData.ProjectName = projectName
		tmpData.NamespaceId = namespace
		tmpData.Name = deploymentName
		tmpData.State = state
		tmpData.Position = i
		if row[eventInputPos].Value == "" {
			//needAddToMap = true

			if hpaID == "" {
				var replicas int
				if strings.ToLower(eventBaseName) == "n/a" {
					replicas, err = strconv.Atoi(row[normalRepPos].Value)
				} else {
					replicas, err = strconv.Atoi(eventBaseName)
				}

				if err != nil {
					return events, errors.New("Event input at line " + strconv.Itoa(i) + " is wrong format for hpa")
				}

				tmpData.Replicas = replicas
			} else {
				tmpData.Replicas = -1

				var splitBaseEvent []string
				if strings.ToLower(eventBaseName) == "n/a" {
					splitBaseEvent = strings.Split(row[normalRepPos].Value, "-")
				} else {
					splitBaseEvent = strings.Split(eventBaseName, "-")
				}

				if len(splitBaseEvent) != 2 {
					return events, errors.New("Event base at line " + strconv.Itoa(i) + " is wrong format for deployment")

				}

				tmpData.EventMinReplicas, err = strconv.Atoi(splitBaseEvent[0])
				if err != nil {
					return events, errors.New("Event base at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitBaseEvent[0])
				}

				tmpData.EventMaxReplicas, err = strconv.Atoi(splitBaseEvent[1])
				if err != nil {
					return events, errors.New("Event base at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitBaseEvent[1])
				}

				if tmpData.MinReplicas > tmpData.EventMaxReplicas {
					return events, errors.New("Event base at line " + strconv.Itoa(i) + "has wrong value, min rep cannot small than max rep")

				}
			}

			if events[authorName] != nil {
				events[authorName].Data = append(events[authorName].Data, *tmpData)

			} else {
				tmpEvent.Data = append(tmpEvent.Data, *tmpData)
				events[authorName] = tmpEvent
			}

			continue
		}

		//ignore if event is n/a
		if strings.ToLower(eventInputName) == "n/a" {
			continue
		}

		if hpaID == "" {

			// if strings.ToLower(eventBaseName) != "n/a" {

			// }
			// baseRep, err := strconv.Atoi(eventBaseName)

			// if err != nil {
			// 	return events, errors.New("Event input at line " + strconv.Itoa(i) + " is wrong format for hpa")
			// }
			eventRep, err := strconv.Atoi(eventInputName)
			if err != nil {
				return events, errors.New("Event input at line " + strconv.Itoa(i) + " is wrong format for deployment")
			}

			if eventRep >= 0 {
				continue
			}

			// tmpData.Replicas = eventRep
		} else {

			// //set value to define deployment or hpa
			// tmpData.Replicas = -1

			// //split data to get value
			// splitBaseEvent := strings.Split(eventBaseName, "-")
			// if len(splitBaseEvent) != 2 {
			// 	return events, errors.New("Event base at line " + strconv.Itoa(i) + " is wrong format for deployment")
			// }

			// tmpData.EventMinReplicas, err = strconv.Atoi(splitBaseEvent[0])
			// if err != nil {
			// 	return events, errors.New("Event base at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitBaseEvent[0])
			// }

			// tmpData.EventMaxReplicas, err = strconv.Atoi(splitBaseEvent[1])
			// if err != nil {
			// 	return events, errors.New("Event base at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitBaseEvent[1])
			// }

			splitEventRep := strings.Split(eventBaseName, "-")

			if len(splitEventRep) != 2 {
				return events, errors.New("Event at line " + strconv.Itoa(i) + " is wrong format for hpa")
			}

			minRep, err := strconv.Atoi(splitEventRep[0])
			if err != nil {
				return events, errors.New("Event at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitEventRep[0])
			}

			maxRep, err := strconv.Atoi(splitEventRep[1])
			if err != nil {
				return events, errors.New("Event at line " + strconv.Itoa(i) + " must be a number, invalid data is " + splitEventRep[1])
			}

			if minRep > maxRep {
				return events, errors.New("Event at line " + strconv.Itoa(i) + "has wrong value, min rep cannot small than max rep")

			}

			if minRep == 0 {
				return events, errors.New("Event at line " + strconv.Itoa(i) + "has wrong value, min Replicas cannot be zero")

			}

			if minRep > 0 && maxRep > 0 {
				continue
			}
		}

		// log.Println("Author ", authorName)
		// log.Println(events[authorName])
		if events[authorName] != nil {
			events[authorName].Data = append(events[authorName].Data, *tmpData)

		} else {
			tmpEvent.Data = append(tmpEvent.Data, *tmpData)
			events[authorName] = tmpEvent
		}

	}

	return events, nil
}

func ReturnMsgName(rancherUser RancherUser) string {
	return rancherUser.name
}

func HandleRemindEvent() (slack.MsgOption, error) {
	msg, err := getRemindEventBlock()

	if err != nil {
		return msg, err
	}

	return msg, nil
}

func GetApproveScaleBtn2(checkBoxValue map[string]map[string]slack.BlockAction, userApprove string) (slack.MsgOption, error) {

	var msg slack.MsgOption
	var isApprove bool
	var textBlockObject *slack.TextBlockObject
	var approvedInitOption *slack.OptionBlockObject
	var checkbox *slack.CheckboxGroupsBlockElement
	value := checkBoxValue["checkbox_scale_confirm_2"]["checkbox_scale_confirm_2"]

	if len(value.SelectedOptions) == 0 {
		isApprove = false
	} else {
		isApprove = true

		if value.SelectedOptions[0].Value != userApprove {
			return msg, errors.New("Only user approved could change approve request button!!!")
		}
	}

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("scale_event_input", "Enter event need to scale, type `Scale Normal` if want to scale back:", "Example:\nEvent 8/8/20222")

	if isApprove {
		//checkBoxValue["checkbox_scale_confirm_2"]["checkbox_scale_confirm_2"].SelectedOptions[0].Value = userApprove
		textBlockObject = slack.NewTextBlockObject("plain_text", userApprove+" approved this request", false, false)
		approvedInitOption = slack.NewOptionBlockObject(userApprove, textBlockObject, nil)

		log.Printf("%+v", approvedInitOption)
	} else {
		textBlockObject = slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	}

	op := slack.NewOptionBlockObject(userApprove, textBlockObject, nil)

	checkbox = slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm_2", op)
	if isApprove {
		checkbox.InitialOptions = append(checkbox.InitialOptions, approvedInitOption)
	}

	checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm_2", checkbox)

	btn := common.GetAprroveBtn("scale_event_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		checkBoxBlock,
		btn,
	)

	return msg, nil
}

func GetApproveScaleBtn(checkBoxValue map[string]map[string]slack.BlockAction, userApprove string) (slack.MsgOption, error) {

	var msg slack.MsgOption
	var isApprove bool
	var textBlockObject *slack.TextBlockObject
	var approvedInitOption *slack.OptionBlockObject
	var checkbox *slack.CheckboxGroupsBlockElement
	value := checkBoxValue["checkbox_scale_confirm"]["checkbox_scale_confirm"]

	if len(value.SelectedOptions) == 0 {
		isApprove = false
	} else {
		isApprove = true
	}

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("scale_event_input", "Enter event need to scale, type `Scale Normal` if want to scale back:", "Example:\nEvent 8/8/20222")

	if isApprove {
		//checkBoxValue["checkbox_scale_confirm_2"]["checkbox_scale_confirm_2"].SelectedOptions[0].Value = userApprove
		textBlockObject = slack.NewTextBlockObject("plain_text", userApprove+" approved this request", false, false)
		approvedInitOption = slack.NewOptionBlockObject(userApprove, textBlockObject, nil)

		log.Printf("%+v", approvedInitOption)
	} else {
		textBlockObject = slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	}

	op := slack.NewOptionBlockObject(userApprove, textBlockObject, nil)

	checkbox = slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm_2", op)
	checkbox.InitialOptions = append(checkbox.InitialOptions, approvedInitOption)
	checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm_2", checkbox)

	btn := common.GetAprroveBtn("scale_event_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		checkBoxBlock,
		btn,
	)

	return msg, nil
}

func HandleGoogleSheetUpdateData() error {
	sheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		log.Println(err)
	}
	var clusterPos int
	var projectPos int
	var namespacePos int
	var namePos int
	var statePos int
	var curRepPos int
	var desiredRepPos int
	var minRepPos int
	var maxRepPos int
	var hpaPos int

	for i, row := range sheet.Rows {
		//ignore head row

		if i == 0 {
			for j, cell := range row {

				if strings.TrimSpace(cell.Value) == "Cluster" {
					clusterPos = j
				}

				if strings.TrimSpace(cell.Value) == "Project" {
					projectPos = j
				}

				if strings.TrimSpace(cell.Value) == "Namespace" {
					namespacePos = j
				}

				if strings.TrimSpace(cell.Value) == "Deployment" {
					namePos = j
				}
				if strings.TrimSpace(cell.Value) == "State" {
					statePos = j
				}

				if strings.TrimSpace(cell.Value) == "Current Replicas" {
					curRepPos = j
				}

				if strings.TrimSpace(cell.Value) == "Desired Replicas" {
					desiredRepPos = j
				}

				if strings.TrimSpace(cell.Value) == "Min Replicas" {
					minRepPos = j
				}

				if strings.TrimSpace(cell.Value) == "Max Replicas" {
					maxRepPos = j
				}

				if strings.TrimSpace(cell.Value) == "HpaID" {

					hpaPos = j
				}
			}

			positions := []string{"cluster " + strconv.Itoa(clusterPos), "project " + strconv.Itoa(projectPos), "hpaPos " + strconv.Itoa(hpaPos),
				"name " + strconv.Itoa(namePos), "namespace " + strconv.Itoa(namespacePos), "desiredRepPos " + strconv.Itoa(desiredRepPos), "minRepPos " + strconv.Itoa(minRepPos), "maxRepPos " + strconv.Itoa(maxRepPos)}

			for _, position := range positions {
				dataSplit := strings.Split(position, " ")
				if len(dataSplit) != 2 {
					return errors.New("error when split positions")
				}
				if dataSplit[1] == "0" {
					if dataSplit[0] == "cluster" {
						continue
					}
					return errors.New("cannot get positions header  " + position + ", please check header name is already valid")
				}
			}

			continue
		}

		var deployment Deployment

		deployment.ClusterName = strings.TrimSpace(row[clusterPos].Value)
		deployment.ProjectName = strings.TrimSpace(row[projectPos].Value)
		deployment.NamespaceId = strings.TrimSpace(row[namespacePos].Value)
		deployment.Name = strings.TrimSpace(row[namePos].Value)
		hpaID := strings.TrimSpace(row[hpaPos].Value)
		deployment.Position = i

		//break if empty
		if deployment.ClusterName == "" || deployment.ProjectName == "" || deployment.Name == "" {
			break
		}

		err := validateDeployment(deployment)

		if err != nil {
			return err
		}

		clusterID, err := getClusterIdWithClusterName(deployment.ClusterName)

		if err != nil {
			return err
		}

		project, err := getProjectWithClusterID(deployment.ProjectName, clusterID)

		if err != nil {
			return err
		}

		if len(project.Data) != 1 {
			return errors.New("Project not found " + deployment.ProjectName + " in cluster " + deployment.ClusterName)
		}

		tmpDeployment, err := getDeploymentWithProjectId(project.Data[0].ID, deployment.Name, deployment.NamespaceId)

		if err != nil {
			return err
		}

		if len(tmpDeployment.Deployment) != 1 {
			return errors.New("Deployment not found " + deployment.Name)
		}

		sheet.Update(i, statePos, tmpDeployment.Deployment[0].State)
		sheet.Update(i, curRepPos, strconv.Itoa(tmpDeployment.Deployment[0].DeploymentStatus.ReadyReplicas))
		sheet.Update(i, desiredRepPos, strconv.Itoa(tmpDeployment.Deployment[0].DeploymentStatus.Replicas))

		//updateHpa
		if hpaID != "" {
			wordloadId := "deployment:" + deployment.NamespaceId + ":" + deployment.Name
			hpa, err := getHpaWithProjectId(project.Data[0].ID, wordloadId)

			//retry 3 times if cannot get hpa

			if err != nil {
				return err
			}

			if len(hpa.Data) != 1 {
				return errors.New("Error when geting Hpa " + wordloadId + " line " + strconv.Itoa(i))
			}

			sheet.Update(i, minRepPos, strconv.Itoa(hpa.Data[0].MinReplicas))
			sheet.Update(i, maxRepPos, strconv.Itoa(hpa.Data[0].MaxReplicas))

		}
	}

	//write to sheet
	sheet.Synchronize()
	return nil
}

func validateDeployment(deployment Deployment) error {
	if common.IsEmpty(deployment.ClusterName) || common.IsEmpty(deployment.ProjectName) || common.IsEmpty(deployment.NamespaceId) || common.IsEmpty(deployment.Name) {
		return errors.New(" " + strconv.Itoa(deployment.Position))
	}

	err := common.ValidateInput(deployment.ClusterName, "name")

	if err != nil {
		return errors.New(deployment.ClusterName + " has special charcater at line" + strconv.Itoa(deployment.Position))
	}

	err = common.ValidateInput(deployment.ProjectName, "name")
	if err != nil {
		return errors.New(deployment.ProjectName + " has special charcater at line" + strconv.Itoa(deployment.Position))
	}

	err = common.ValidateInput(deployment.NamespaceId, "name")
	if err != nil {
		return errors.New(deployment.NamespaceId + " has special charcater at line" + strconv.Itoa(deployment.Position))
	}

	err = common.ValidateInput(deployment.Name, "name")
	if err != nil {
		return errors.New(deployment.Name + " has special charcater at line" + strconv.Itoa(deployment.Position))
	}

	return nil

}

func validateHpa(hpaData Data) error {
	if common.IsEmpty(hpaData.ClusterName) || common.IsEmpty(hpaData.ProjectName) || common.IsEmpty(hpaData.NamespaceId) || common.IsEmpty(hpaData.ID) {
		return errors.New("Input cannot be empty at line" + strconv.Itoa(hpaData.Position))
	}

	err := common.ValidateInput(hpaData.ClusterName, "name")

	if err != nil {
		return errors.New(hpaData.ClusterName + " has special charcater at line " + strconv.Itoa(hpaData.Position))
	}

	err = common.ValidateInput(hpaData.ProjectName, "name")
	if err != nil {
		return errors.New(hpaData.ProjectName + " has special charcater at line " + strconv.Itoa(hpaData.Position))
	}

	err = common.ValidateInput(hpaData.NamespaceId, "name")
	if err != nil {
		return errors.New(hpaData.NamespaceId + " has special charcater at line " + strconv.Itoa(hpaData.Position))
	}

	err = common.ValidateInput(hpaData.ID, "name")
	if err != nil {
		return errors.New(hpaData.ID + " has special charcater at line " + strconv.Itoa(hpaData.Position))
	}

	// if hpaData.MaxReplicas < 1 {
	// 	return errors.New(hpaData.Name + " has max replicas less than 1 at line" + strconv.Itoa(hpaData.Position))
	// }

	return nil

}

func HandleScaleEventData(eventData string) ([]Data, []Deployment, error) {

	sheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		log.Println(err)
	}

	//get data
	var hpaList []Data
	var deployments []Deployment

	if eventData == "" {
		return nil, nil, errors.New("input cannot be empty!!!")
	}

	// if userSubmit == approveData.SelectedOptions[0].Value {
	// 	return errors.New("User approve and user submit request cannot be the same")
	// }

	checkEvent := false
	scaleType := "normal"

	var rowEventPos int
	var hpaPos int
	var scaleNormalPos int
	var clusterPos int
	var projectPos int
	var namespacePos int
	var deploymentPos int
	var desiredReplicaPos int
	var minReplicasPos int
	var maxReplicasPos int

	for i, row := range sheet.Rows {
		//ignore head row
		if i == 0 {

			for j, cell := range row {

				//log.Println(cell.Value)
				if strings.TrimSpace(cell.Value) == eventData {
					if eventData != "Scale Normal" {
						scaleType = "event"
					}
					checkEvent = true
					rowEventPos = j
				}

				if strings.TrimSpace(cell.Value) == "Cluster" {
					clusterPos = j
				}

				if strings.TrimSpace(cell.Value) == "Project" {
					projectPos = j
				}

				if strings.TrimSpace(cell.Value) == "Namespace" {
					namespacePos = j
				}

				if strings.TrimSpace(cell.Value) == "Deployment" {
					deploymentPos = j
				}

				if strings.TrimSpace(cell.Value) == "Scale Normal" {
					scaleNormalPos = j
				}

				if strings.TrimSpace(cell.Value) == "HpaID" {
					hpaPos = j
				}

				if strings.TrimSpace(cell.Value) == "Desired Replicas" {
					desiredReplicaPos = j
				}

				if strings.TrimSpace(cell.Value) == "Min Replicas" {
					minReplicasPos = j
				}

				if strings.TrimSpace(cell.Value) == "Max Replicas" {
					maxReplicasPos = j
				}

			}

			positions := []string{"event " + strconv.Itoa(rowEventPos), "cluster " + strconv.Itoa(clusterPos), "project " + strconv.Itoa(projectPos),
				"name " + strconv.Itoa(deploymentPos), "namespace " + strconv.Itoa(namespacePos), "scaleNor " + strconv.Itoa(scaleNormalPos), "HpaID " + strconv.Itoa(hpaPos),
				"desiredReplicas " + strconv.Itoa(desiredReplicaPos), "minReplicas " + strconv.Itoa(minReplicasPos), "maxReplicas " + strconv.Itoa(maxReplicasPos)}

			for _, position := range positions {
				dataSplit := strings.Split(position, " ")
				if len(dataSplit) != 2 {
					return nil, nil, errors.New("Error when split positions")
				}
				if dataSplit[1] == "0" {
					if dataSplit[0] == "cluster" {
						continue
					}
					return nil, nil, errors.New("cannot get positions header " + position + ", please check header name exist")
				}
			}
			if !checkEvent {
				return nil, nil, errors.New("there is no event match input " + eventData)
			}

			continue
		}

		//ignore if event value is n/a

		if strings.ToLower(row[rowEventPos].Value) == "n/a" {
			continue
		}

		if row[hpaPos].Value != "" {
			var hpaData Data

			hpaData.ClusterName = strings.TrimSpace(row[clusterPos].Value)
			hpaData.ProjectName = strings.TrimSpace(row[projectPos].Value)
			hpaData.NamespaceId = strings.TrimSpace(row[namespacePos].Value)
			//hpaData.Name = strings.TrimSpace(row[namePos].Value)
			hpaData.ID = row[hpaPos].Value
			hpaData.Name = strings.TrimSpace(row[deploymentPos].Value)
			//hpaData.Enabled = strings.TrimSpace(row[isEnablePos].Value)

			//get enable
			// if hpaData.Enabled == "false" {
			// 	if hpaData.Enabled != "true" {
			// 		return errors.New("Enable value must be true or false")
			// 	}
			// 	continue
			// }

			normalRep := strings.TrimSpace(row[scaleNormalPos].Value)

			normalRepSplit := strings.Split(normalRep, "-")
			if len(normalRepSplit) != 2 {
				return nil, nil, errors.New("Somethings wrong with normal replicas row " + strconv.Itoa(i+1))
			}
			hpaData.NormalMinReplicas, err = strconv.Atoi(normalRepSplit[0])
			if err != nil {
				return nil, nil, err
			}

			hpaData.NormalMaxReplicas, err = strconv.Atoi(normalRepSplit[1])
			if err != nil {
				return nil, nil, err
			}

			eventRep := strings.TrimSpace(row[rowEventPos].Value)

			if eventRep == "" {
				return nil, nil, errors.New("event cannot be empty, check at line " + strconv.Itoa(i))
			}
			eventRepSplit := strings.Split(eventRep, "-")
			if len(eventRepSplit) != 2 {
				return nil, nil, errors.New("Somethings wrong with event replicas row " + strconv.Itoa(i+1))
			}
			hpaData.EventMinReplicas, err = strconv.Atoi(eventRepSplit[0])
			if err != nil {
				return nil, nil, err
			}

			hpaData.EventMaxReplicas, err = strconv.Atoi(eventRepSplit[1])
			if err != nil {
				return nil, nil, err
			}

			if common.IsEmpty(hpaData.ClusterName) || common.IsEmpty(hpaData.ProjectName) || common.IsEmpty(hpaData.NamespaceId) || common.IsEmpty(hpaData.ID) {
				return nil, nil, errors.New("Input cannot be empty, check at line " + strconv.Itoa(i))
			}

			// ignore if already scale normal value
			hpaData.CurrentMinReplicas = strings.TrimSpace(row[minReplicasPos].Value)

			if hpaData.CurrentMinReplicas == "" {
				return nil, nil, errors.New("Somethings wrong with current min replicas row " + strconv.Itoa(i+1))
			}

			hpaData.CurrentMaxReplicas = strings.TrimSpace(row[maxReplicasPos].Value)

			if hpaData.CurrentMaxReplicas == "" {
				return nil, nil, errors.New("Somethings wrong with current max replicas row " + strconv.Itoa(i+1))
			}

			currentScale := hpaData.CurrentMinReplicas + "-" + hpaData.CurrentMaxReplicas

			if currentScale == normalRep && eventData == "Scale Normal" {
				continue
			}
			//save current position for updating
			hpaData.Position = i
			err = validateHpa(hpaData)

			if err != nil {
				return nil, nil, err
			}

			if eventData == "Scale Normal" {
				hpaData.ReplicaData = normalRep
			} else {
				hpaData.ReplicaData = eventRep
			}
			// if hpaData.Enabled == "true" {
			hpaList = append(hpaList, hpaData)
			// }

		} else if row[hpaPos].Value == "" {
			var deployment Deployment

			deployment.ClusterName = strings.TrimSpace(row[clusterPos].Value)
			deployment.ProjectName = strings.TrimSpace(row[projectPos].Value)
			deployment.NamespaceId = strings.TrimSpace(row[namespacePos].Value)
			deployment.Name = strings.TrimSpace(row[deploymentPos].Value)
			//deployment.Scale = strings.Atoi()
			//deployment.EnableForBot = strings.TrimSpace(row[isEnablePos].Value)
			//get enable
			// if deployment.EnableForBot == "false" {
			// 	if deployment.EnableForBot != "true" {
			// 		return errors.New("Enable value must be true or false")
			// 	}
			// 	continue
			// }

			deployment.NormalReplicas, err = strconv.Atoi(row[scaleNormalPos].Value)

			if err != nil {
				return nil, nil, err
			}
			deployment.EventReplicas, err = strconv.Atoi(row[rowEventPos].Value)
			if err != nil {
				return nil, nil, err
			}

			if common.IsEmpty(deployment.ClusterName) || common.IsEmpty(deployment.ProjectName) || common.IsEmpty(deployment.NamespaceId) || common.IsEmpty(deployment.Name) {
				return nil, nil, errors.New("Input cannot be empty, check at line " + strconv.Itoa(i))
			}

			//save current position for updating
			deployment.Position = i

			deployment.DesiredReplicas, err = strconv.Atoi(strings.TrimSpace(row[desiredReplicaPos].Value))

			if err != nil {
				return nil, nil, errors.New("Somethings wrong with current DesiredReplicas row " + strconv.Itoa(i+1))
			}

			//ingore if already normal data
			if deployment.DesiredReplicas == deployment.NormalReplicas && eventData == "Scale Normal" {
				continue
			}

			//validate deployment
			err = validateDeployment(deployment)
			if err != nil {
				return nil, nil, err
			}
			//if deployment.EnableForBot == "true" {
			if eventData == "Scale Normal" {
				deployment.Scale = deployment.NormalReplicas
			} else {
				deployment.Scale = deployment.EventReplicas
			}
			deployments = append(deployments, deployment)
			//}

		}

	}

	err = sendDeploymentAndHpaToRancher(deployments, hpaList, scaleType, sheet, rowEventPos)

	if err != nil {
		return nil, nil, err
	}

	return hpaList, deployments, nil
}

func sendDeploymentAndHpaToRancher(deployments []Deployment, hpaList []Data, scaleType string, sheet *spreadsheet.Sheet, rowEventPos int) error {

	//send deployments

	retry := 3
	if len(deployments) > 0 {

		for _, deployment := range deployments {

			clusterID, err := getClusterIdWithClusterName(deployment.ClusterName)
			if err != nil {

				for i := 0; i < retry; i++ {
					//sleep 3 second to retry to rancher
					time.Sleep(10 * time.Second)
					log.Println("cannot get cluster " + deployment.ClusterName + " retry after 10 seconds")
					clusterID, err = getClusterIdWithClusterName(deployment.ClusterName)
					if err == nil {
						break
					}
				}

				if err != nil {
					return err
				}

			}
			projects, err := getProjectWithClusterID(deployment.ProjectName, clusterID)

			if err != nil {
				for i := 0; i < retry; i++ {
					//sleep 3 second to retry to rancher
					time.Sleep(10 * time.Second)
					log.Println("cannot get project " + deployment.ProjectName + " retry after 10 seconds")
					projects, err = getProjectWithClusterID(deployment.ProjectName, clusterID)
					if err == nil {
						break
					}
				}
				if err != nil {
					return err
				}
			}

			if len(projects.Data) == 0 || projects.Data == nil {
				return errors.New("project not found: " + deployment.ProjectName)
			}

			deployment.ProjectID = projects.Data[0].ID
			if scaleType == "event" {
				deployment.Scale = deployment.EventReplicas
			} else if scaleType == "normal" {
				deployment.Scale = deployment.NormalReplicas
			}

			deployment.ID = "deployment:" + deployment.NamespaceId + ":" + deployment.Name
			isDeployHasHpa, err := queryRancherHpaWithDeployment(deployment)

			if err != nil {
				return err
			}

			//log.Println("query " + deployment.ID + " " + "hpa " + strconv.FormatBool(isDeployHasHpa))

			if isDeployHasHpa {
				return errors.New("Deployment name " + deployment.Name + " has hpa, please check again!!!")
			}
			statusCode := updateDeploymentDataCommand(deployment)

			if statusCode != 200 {
				return errors.New("error when send deployment update request to rancher " + deployment.Name + " with status " + strconv.Itoa(statusCode))
			}

			//update sheet event position

		}

	}

	//send hpa

	if len(hpaList) > 0 {
		for _, hpa := range hpaList {
			clusterID, err := getClusterIdWithClusterName(hpa.ClusterName)
			if err != nil {
				return err
			}
			projects, err := getProjectWithClusterID(hpa.ProjectName, clusterID)

			if err != nil {
				return err
			}

			if len(projects.Data) == 0 || projects.Data == nil {
				return errors.New("project not found: " + hpa.ProjectName)
			}

			hpa.ProjectID = projects.Data[0].ID
			hpa.ID = hpa.NamespaceId + ":" + hpa.ID
			if scaleType == "event" {
				hpa.TempMinReplicas = hpa.EventMinReplicas
				hpa.TempMaxReplicas = hpa.EventMaxReplicas
			} else if scaleType == "normal" {
				hpa.TempMinReplicas = hpa.NormalMinReplicas
				hpa.TempMaxReplicas = hpa.NormalMaxReplicas
			}
			statusCode := updateHpaDataCommand(hpa)

			if statusCode != 200 {
				return errors.New("error when send deployment update request to rancher " + hpa.ID + " with status " + strconv.Itoa(statusCode))
			}
		}

	}

	return nil
}

func HandleScaleMsg() (slack.MsgOption, error) {
	var msg slack.MsgOption

	msg, err := getScaleBlock()

	if err != nil {
		return msg, err
	}

	return msg, nil
}

func HandleClearLocalFile(fileType string) error {
	godotenv.Load(".env")
	var file_name string
	var path string
	if fileType == "deployment" {
		file_name = os.Getenv("DEPLOYMENT_FIND_FILE_NAME")
		path = os.Getenv("DEPLOYMENT_PATH")
	} else if fileType == "hpa" {
		file_name = os.Getenv("HPA_FILE_NAME")
		path = os.Getenv("HPA_PATH")
	}

	if err := os.Truncate(path+"/"+file_name, 0); err != nil {
		log.Printf("Failed to truncate: %v", err)
		return err
	}
	return nil
}

func enrichProjects(clusters RancherClusters, projects RancherProjects) RancherProjects {

	for i := 0; i < len(projects.Data); i++ {

		for j := 0; j < len(clusters.Data); j++ {

			log.Println("Current cluster", clusters.Data[j].Name)
			if clusters.Data[j].Name == "k8s-s14e-prod" {

				log.Println("s14e error project")
				continue
			}

			if clusters.Data[j].ID == projects.Data[i].ClusterID {

				projects.Data[i].ClusterName = clusters.Data[j].Name
			}
		}
	}
	return projects
}

// func updateInfo()

// func getHpaListFromRancher(project string) (RancherProjects, error) {
// 	var projects []RancherProjects

// }

func ResetUserPassword(rancherUser RancherUser) (string, error) {

	minSpecialChar := 0
	minNum := 1
	minUpperCase := 3
	passwordLength := 12
	password := common.GeneratePassword(passwordLength, minSpecialChar, minNum, minUpperCase)

	data := make(map[string]interface{})
	data["newPassword"] = password

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", "/users/"+rancherUser.id+"?action=setpassword", string(json_req))

	fmt.Print(err)
	if err != nil {
		return "", err

	}

	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		return password, nil
	} else {
		return "", errors.New("somethings when wrong when reset password with error code " + strconv.Itoa(resp.StatusCode))
	}
}

func GetRancherUserData(interaction slack.InteractionCallback) (RancherUser, string, error) {

	var rancherUser RancherUser
	blockState := interaction.BlockActionState.Values

	//fmt.Println(blockState)
	// fmt.Println("blockstate: %+v\n", blockState)

	//user := RancherUser{}

	//fmt.Println(blockState)
	userName := blockState["user_name"]["user_name"].Value

	//fmt.Println("User input ", userName)

	err := common.ValidateInput(userName, "name")

	if err != nil {
		return rancherUser, "", err
	}

	rancherUser.name = userName

	option_block := blockState["options"]

	if len(option_block) > 0 {
		rancherUser.cluster = option_block["clusterBlock"].SelectedOption.Value
		rancherUser.clusterRole = option_block["clusterRoleBlock"].SelectedOption.Value
		rancherUser.project = option_block["projectBlock"].SelectedOption.Value
		rancherUser.projectRole = option_block["projectRoleBlock"].SelectedOption.Value
	}

	return rancherUser, userName, nil
}

func GetUserIdByUserName(rancherObj RancherUser) (RancherUser, error) {

	querryCommmand := "/users?username=" + rancherObj.name
	resp, err := initRancherHttpReq("GET", querryCommmand, "`{}`")

	// TODO: check err
	fmt.Print(err)
	if err != nil {
		log.Fatal(err)
	}

	respBody, err := ioutil.ReadAll(resp.Body)

	userId := gjson.GetBytes(respBody, "data.0.id")

	//fmt.Println("User id is", int(userId.Int()))
	rancherObj.id = userId.Str

	if rancherObj.id == "" {
		return rancherObj, errors.New("this user is not found!!!")
	}
	fmt.Println("user id is ", userId.Str)

	defer resp.Body.Close()

	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		return rancherObj, nil
	} else {
		return rancherObj, errors.New("somethings when wrong when query rancher ID")
	}
}

//func createUserBodyTemplate()
func CreateNewUser(rancherUser RancherUser) (RancherUser, string, error) {

	data := make(map[string]interface{})

	godotenv.Load(".env")
	data["mustChangePassword"] = true

	//generate password
	minSpecialChar := 0
	minNum := 1
	minUpperCase := 3
	passwordLength := 12
	password := common.GeneratePassword(passwordLength, minSpecialChar, minNum, minUpperCase)

	//fmt.Println(password)

	data["password"] = password
	data["username"] = rancherUser.name

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", "/users", string(json_req))

	// TODO: check err
	fmt.Print(err)
	if err != nil {
		return rancherUser, "", err
	}

	respBody, err := ioutil.ReadAll(resp.Body)

	userId := gjson.GetBytes(respBody, "id")

	rancherUser.id = userId.Str

	defer resp.Body.Close()

	if resp.StatusCode == 201 {
		return rancherUser, password, nil
	} else if resp.StatusCode == 422 {
		return rancherUser, "", errors.New("user is duplicated")
	} else {
		return rancherUser, "", errors.New("somethings when wrong")
	}
}

func CreateGlobalRoleBinding(rancherUser RancherUser) (string, error) {

	data := make(map[string]interface{})
	data["globalRoleId"] = "user"
	data["name"] = ""
	data["userId"] = rancherUser.id

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", "/globalrolebindings", string(json_req))

	// TODO: check err
	fmt.Print(err)
	if err != nil {
		return strconv.Itoa(resp.StatusCode), err
	}

	return strconv.Itoa(resp.StatusCode), nil
}

func CreateClusterRoleBinding(rancherUser RancherUser) (string, error) {
	data := make(map[string]interface{})
	data["clusterId"] = rancherUser.cluster
	data["name"] = ""
	data["namespaceId"] = ""
	data["roleTemplateId"] = rancherUser.clusterRole
	data["userId"] = rancherUser.id

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", "/clusterroletemplatebindings", string(json_req))

	if err != nil {
		return strconv.Itoa(resp.StatusCode), err
	}

	return strconv.Itoa(resp.StatusCode), nil
}

func CreateProjectRoleBinding(rancherUser RancherUser) (string, error) {
	data := make(map[string]interface{})
	data["projectId"] = rancherUser.project
	data["name"] = ""
	data["namespaceId"] = ""
	data["roleTemplateId"] = rancherUser.projectRole
	data["userId"] = rancherUser.id

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", "/projectroletemplatebindings", string(json_req))

	// TODO: check err
	fmt.Print(err)
	if err != nil {
		return strconv.Itoa(resp.StatusCode), err
	}

	return strconv.Itoa(resp.StatusCode), nil
}

func GetRancherData(input string) ([]RancherObject, error) {

	//get command as input type
	querryCommmand := ""

	switch input {
	case "clusters":
		querryCommmand = "/clusters"
	// case "clusterRoles":
	// 	querryCommmand += "/clusters/local/clusterroletemplatebindings"
	case "users":
		querryCommmand = "/users"
	case "projects":
		querryCommmand = "/projects?sort=description"
	case "clusterProjectRoles":
		querryCommmand = "/roletemplates"
	default:
	}

	rancherObjs, err := queryRancherData(querryCommmand)
	//"Begin request"
	if err != nil {
		//log.Fatal(err)
		return rancherObjs, err
	}

	return rancherObjs, err
}

func queryRancherData(querryCommmand string) ([]RancherObject, error) {

	var rancherObjs []RancherObject
	resp, err := initRancherHttpReq("GET", querryCommmand, "`{}`")

	if err != nil {
		fmt.Println("Error request")
		return rancherObjs, err
	}
	// TODO: check err
	fmt.Print(err)

	// Read Response Body

	respBody, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return rancherObjs, err
	}

	defer resp.Body.Close()

	//get name of all cluster
	//getData := gjson.GetManyBytes(respBody, "data.#.name", "data.#.id", "data.#.context")
	jsonDataName := gjson.GetBytes(respBody, "data.#.name")
	jsonDataId := gjson.GetBytes(respBody, "data.#.id")
	jsonDataCotext := gjson.GetBytes(respBody, "data.#.context")

	// create Array
	//RancherObjs := make([]rancherObject, len(getData))

	//fmt.Println("dataIndex: ", getData)

	var querriedName []string
	var querriedId []string
	var querriedCtx []string
	jsonDataName.ForEach(
		func(key gjson.Result, value gjson.Result) bool {
			querriedName = append(querriedName, value.String())
			return true // keep iterating
		})

	jsonDataId.ForEach(
		func(key gjson.Result, value gjson.Result) bool {
			querriedId = append(querriedId, value.String())
			return true // keep iterating
		})

	jsonDataCotext.ForEach(
		func(key gjson.Result, value gjson.Result) bool {
			querriedCtx = append(querriedCtx, value.String())
			return true // keep iterating
		})

	//create RancherObjs

	for i, data := range querriedName {
		var rancherObj RancherObject
		if len(querriedCtx) > 0 {
			rancherObj = RancherObject{data, querriedId[i], querriedCtx[i]}
		} else {
			rancherObj = RancherObject{data, querriedId[i], ""}
		}
		rancherObjs = append(rancherObjs, rancherObj)

	}

	//fmt.Println(rancherObjs)

	return rancherObjs, err
}
