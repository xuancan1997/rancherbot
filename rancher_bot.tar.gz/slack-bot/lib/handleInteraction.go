package lib

import (
	"errors"
	"fmt"
	"log"
	"os"
	"regexp"
	"slack-bot/atlantis"
	"slack-bot/common"
	"slack-bot/github"
	"slack-bot/jsonconvert"
	"slack-bot/kong"
	"slack-bot/rancher"
	"slack-bot/sheet"
	"slack-bot/vault"
	"strconv"
	"strings"
	"time"

	"github.com/jedib0t/go-pretty/table"
	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
)

var lastTimeStamp string

func HandleInteractionEvent(interaction slack.InteractionCallback, client *slack.Client) error {

	// This is where we would handle the interaction
	// Switch depending on the Type

	user, err := client.GetUserInfo(interaction.User.ID)

	if err != nil {
		return err
	}

	if !user.IsBot {
		log.Println("User: " + user.Name + " interractive ")
	}

	switch interaction.Type {
	case slack.InteractionTypeBlockActions:
		fmt.Println("----------------------Submit to InteractionTypeBlockActions msg--------------- ")
		// This is a block action, so we need to handle it

		//fmt.Println("Interactive: ", interaction.ActionID)
		action := interaction.ActionCallback.BlockActions[0]

		//fmt.Println(action.ActionID, action.BlockID)

		switch action.ActionID {

		case "choose_action":
			fmt.Println("----------------------Submit to choose_action---------------- ")

		case "submit_ac_create_user":

			rancherUser, userName, err := rancher.GetRancherUserData(interaction)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			rancherUserWithIdUpdated, password, err := rancher.CreateNewUser(rancherUser)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			msg_create_global_role_binds, err := rancher.CreateGlobalRoleBinding(rancherUserWithIdUpdated)

			statusCodeRes := msg_create_global_role_binds

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			if statusCodeRes == "201" {
				log.Println("Success global role binds")

				msg_create_cluster_role_bindings, err := rancher.CreateClusterRoleBinding(rancherUserWithIdUpdated)

				if err != nil {
					sendResponse(client, interaction, err, "error", "post")
					return nil
				}

				statusCodeRes = msg_create_cluster_role_bindings
				log.Println("Status code", msg_create_cluster_role_bindings)

			}

			if statusCodeRes == "201" {
				log.Println("Success cluster role binds")
				msg_create_project_role_bindings, err := rancher.CreateProjectRoleBinding(rancherUserWithIdUpdated)

				log.Println("Status code", msg_create_project_role_bindings)

				statusCodeRes = msg_create_project_role_bindings
				if err != nil {
					sendResponse(client, interaction, err, "error", "post")
					return nil
				}
			}
			if statusCodeRes == "201" {

				sendResponse(client, interaction, err, "Successfully create user information, now try to send password to user", "post")

				//try to send password to user
				user, err := client.GetUserByEmail(userName + "@tiki.vn")

				if err != nil {
					fmt.Println(err)
					return nil
				}

				attachment := slack.Attachment{}
				attachment.Text = fmt.Sprintf("Your rancher password is: " + password)
				_, _, err = client.PostMessage(user.ID, slack.MsgOptionAttachments(attachment))

				if err != nil {
					sendResponse(client, interaction, err, "error", "post")
				}
				return nil

			} else {
				log.Println("Error updating user roles")

				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

		case "submit_grant_user":
			rancherUser, userName, err := rancher.GetRancherUserData(interaction)

			fmt.Println("rancher User check:", userName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			updatedRancherUserWithID, err := rancher.GetUserIdByUserName(rancherUser)

			fmt.Println("rancher User check 2:", updatedRancherUserWithID)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			statusCodeRes := ""
			msg_create_global_role_binds, err := rancher.CreateGlobalRoleBinding(updatedRancherUserWithID)

			statusCodeRes = msg_create_global_role_binds

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			if statusCodeRes == "201" {
				log.Println("Success global role binds")

				msg_create_cluster_role_bindings, err := rancher.CreateClusterRoleBinding(updatedRancherUserWithID)

				if err != nil {
					log.Println("Something error")
					sendResponse(client, interaction, err, "error", "post")
					return nil
				}

				statusCodeRes = msg_create_cluster_role_bindings
				log.Println("Status code", msg_create_cluster_role_bindings)

			}

			if statusCodeRes == "201" {
				log.Println("Success cluster role binds")
				msg_create_project_role_bindings, err := rancher.CreateProjectRoleBinding(updatedRancherUserWithID)

				log.Println("Status code", msg_create_project_role_bindings)

				statusCodeRes = msg_create_project_role_bindings
				if err != nil {
					log.Println("Something error")
					sendResponse(client, interaction, err, "error", "post")
					return nil
				}
			}
			if statusCodeRes == "201" {

				sendResponse(client, interaction, err, "Successfully update user information for user "+userName, "post")
				return nil

			} else {
				log.Println("Error updating user " + userName)

				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

		case "submit_reset_rancher_pwd_btn":
			fmt.Println("----------------------Submit to rancher---------------- ")
			rancherUser, userName, err := rancher.GetRancherUserData(interaction)

			fmt.Println("rancher User check:", rancherUser)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			updatedRancherUserWithID, err := rancher.GetUserIdByUserName(rancherUser)

			fmt.Println("rancher User check 2:", updatedRancherUserWithID)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			pwd, err := rancher.ResetUserPassword(updatedRancherUserWithID)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			err = sendInformationToUser(client, interaction, userName, pwd)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			} else {
				log.Println("Create success")
				//ts := event.TimeStamp

				sendResponse(client, interaction, err, "Success send information to "+userName, "post")
				return nil
			}

		case "submit_kong":
			//ts := interaction.Message.Timestamp
			//attachment := slack.Attachment{}
			fmt.Println("----------------------Submit to kong---------------- ")
			kongData, err := kong.GetKongData(interaction.BlockActionState.Values)

			fmt.Println(kongData)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			err = kong.AddKongSvc(kongData)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			} else {
				log.Println("Create success")
				//ts := event.TimeStamp

				sendResponse(client, interaction, err, "Success create services and routes", "post")
				return nil
			}

		case "submit_adduser_git_btn":
			fmt.Println("----------------------Submit to git adduser btn---------------- ")
			inputData, err := github.GetUserGitInputData(interaction.BlockActionState.Values)

			//fmt.Println(inputData)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")

				return nil
			}

			err = github.AddMemberToProject(inputData)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")

				return nil
			}

			sendResponse(client, interaction, err, "Success add user to gitHub!!!", "post")

			//sendResponse(client, interaction, err, "error")
		case "submit_json_convert_btn":
			fmt.Println("----------------------Submit to json btn---------------- ")
			inputData, err := jsonconvert.GetTextInputData(interaction.BlockActionState.Values["input"]["input"].Value, "normal")

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")

				return nil
			}
			sendResponseToUser(client, interaction, "", err, "```"+inputData+"```", "post")

		case "hpa_options":
			fmt.Println("----------------------Submit to hpa edit---------------- ")
			msg, err := rancher.GetHpaInputData(interaction)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			fmt.Println("Update hpa data options ")

			client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)
			return nil

		// case "edit_hpa_btn":
		// 	fmt.Println("----------------------Submit to hpa edit---------------- ")

		// 	err := rancher.GetHpaEditData(interaction)

		// 	if err != nil {
		// 		sendResponse(client, interaction, err, "error", "post")
		// 		return nil
		// 	}

		// 	fmt.Println("Update data")
		// 	sendResponse(client, interaction, err, "Success update Hpa data!!!", "post")

		case "submit_hpa_multi_edit_btn":
			fmt.Println("----------------------Submit to submit_hpa_multi_edit_btn---------------- ")
			err := rancher.GetHpaMultiEditInputData(interaction.BlockActionState.Values)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "```Successfully update hpa data to local file```", "post")

		case "submit_deploy_edit_btn":
			fmt.Println("----------------------Submit to submit_deploy_edit_btn---------------- ")
			err := rancher.GetDeploymentEditInputData(interaction.BlockActionState.Values)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "```Successfully update deployment data to local file```", "post")

		case "submit_deploy_add_btn":
			fmt.Println("----------------------Submit to submit_deploy_add_btn---------------- ")
			err := rancher.GetDeploymentAddInputData(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "```Successfully add deployment data to local file```", "post")

		// case "submit_project_list_btn":
		// 	fmt.Println("----------------------Submit to submit_project_list_btn---------------- ")
		// 	data, err := rancher.GetDeploymentListInputData(interaction.BlockActionState.Values)

		// 	if err != nil {
		// 		fmt.Println("error")
		// 		sendResponse(client, interaction, err, "error", "post")
		// 		return nil
		// 	}

		// 	sendResponseAsText(client, interaction, err, data)

		case "submit_deploy_find_btn":
			fmt.Println("----------------------Submit to submit_deploy_find_btn---------------- ")

			value := interaction.BlockActionState.Values["deployment_find_input"]["deployment_find_input"].Value
			data, _, _, err := rancher.GetDeploymentFindInputData(value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponseAsText(client, interaction, err, data)

		case "scale_manual_approve":
			fmt.Println("----------------------Submit to scale_manual_approve---------------- ")

			ts := interaction.Message.Timestamp
			//update message with choosing project ID
			msg, msgToSendRancher, err := rancher.GetScaleManuallyData(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			attachment := slack.Attachment{}
			//ts := event.TimeStamp

			//inputBl := common.GetTxtInputBlock("testBlock", "test", "test")

			if err != nil {
				fmt.Printf(err.Error())
			}
			attachment.Color = "#ff0000"
			attachment.Pretext = ":mag: Please *Confirm* to approve this deployment scale:"

			//textBlockObject := slack.NewTextBlockObject("plain_text", "b", false, false)
			//blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, "c")

			// Create the Accessory that will be included in the Block and add the checkbox to it

			attachment = slack.Attachment{
				CallbackID: "deployment_scale_manually_btn",
				Fallback:   "deployment_scale_manually_btn",
				Color:      "#2484BE",
				Fields: []slack.AttachmentField{
					slack.AttachmentField{
						Title: "Apply this deployment value to server",
						Short: true,
					},
				},
				// Blocks: slack.Blocks{
				// 	BlockSet: []slack.Block{
				// 		// Create a new section block element and add some text and the accessory to it
				// 		common.GetInputBlock("data"),
				// 	},
				// },
				Actions: []slack.AttachmentAction{
					slack.AttachmentAction{
						Name:  "deployment_scale_manually_btn",
						Text:  "Apply",
						Style: "primary",
						Type:  "button",
						Value: msgToSendRancher,
						Confirm: &slack.ConfirmationField{
							Title:  "Confirm",
							Text:   "Are you sure to apply this? \n",
							OkText: "Apply",
						},
					},
				},

				MarkdownIn: []string{"text"},
			}

			_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionText(msg, true), slack.MsgOptionAttachments(attachment))

			//_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgHpaConfim[0])

			if err != nil {
				fmt.Printf(err.Error())
			}
			return nil

		case "hpa_edit_cluster_choose":
			fmt.Println("----------------------Submit to hpa_edit_cluster_choose---------------- ")
			msg, err := rancher.GetProjectBlockWithClusterChosen(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)
			if err != nil {
				log.Println(err)
			}

		case "hpa_edit_project_choose":
			fmt.Println("----------------------Submit to hpa_edit_project_choose---------------- ")
			msg, err := rancher.GetHpaDataBlockWithProjectChosen(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)
			if err != nil {
				log.Println(err)
			}

		case "hpa_edit_deployment_choose":
			fmt.Println("----------------------Submit to deploy_manually_select---------------- ")
			msg, err := rancher.GetDeploymentDetailBlockWithDepoymentChosen(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)

			if err != nil {
				log.Println(err)
			}

		case "hpa_edit_choose_btn":
			fmt.Println("----------------------Submit to hpa_edit_choose_btn---------------- ")
			err := rancher.GetHpaEditData(interaction.BlockActionState.Values)

			//clear data value after approve
			for k := range interaction.BlockActionState.Values {
				delete(interaction.BlockActionState.Values, k)
			}

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "```Successfully update hpa data to local file```", "post")

		case "pwd_approve_btn":
			fmt.Println("----------------------Submit to pwd_approve_btn---------------- ")

			password, err := common.GetPasswordInputData(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			ts := interaction.Message.Timestamp
			err = sendResponseToUser(client, interaction, "", err, "Your random password is: "+password, "post")

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n```Send random password to user successfully```",
				false,
				false)
			headerSection := slack.NewSectionBlock(headerText, nil, nil)
			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, ts, msg)

		case "redeploy_approve_btn":
			fmt.Println("----------------------Submit to redeploy_approve_btn---------------- ")

			ts := interaction.Message.Timestamp
			//update message with choosing project ID
			msg, msgToSendRancher, err := rancher.GetRedeployDeploymentData(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			attachment := slack.Attachment{}
			//ts := event.TimeStamp

			//inputBl := common.GetTxtInputBlock("testBlock", "test", "test")

			if err != nil {
				fmt.Printf(err.Error())
			}
			attachment.Color = "#ff0000"
			attachment.Pretext = ":mag: Please *Confirm* to redeploy deployment"

			//textBlockObject := slack.NewTextBlockObject("plain_text", "b", false, false)
			//blockElm := slack.NewPlainTextInputBlockElement(textBlockObject, "c")

			// Create the Accessory that will be included in the Block and add the checkbox to it

			attachment = slack.Attachment{
				CallbackID: "redeploy_deployment_btn",
				Fallback:   "redeploy_deployment_btn",
				Color:      "#2484BE",
				Fields: []slack.AttachmentField{
					slack.AttachmentField{
						Title: "Redeploy this deployment?",
						Short: true,
					},
				},
				// Blocks: slack.Blocks{
				// 	BlockSet: []slack.Block{
				// 		// Create a new section block element and add some text and the accessory to it
				// 		common.GetInputBlock("data"),
				// 	},
				// },
				Actions: []slack.AttachmentAction{
					slack.AttachmentAction{
						Name:  "redeploy_deployment_btn",
						Text:  "Apply",
						Style: "primary",
						Type:  "button",
						Value: msgToSendRancher,
						Confirm: &slack.ConfirmationField{
							Title:  "Confirm",
							Text:   "Are you sure to apply this? \n",
							OkText: "Apply",
						},
					},
				},

				MarkdownIn: []string{"text"},
			}

			_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionText(msg, true), slack.MsgOptionAttachments(attachment))

			//_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgHpaConfim[0])

			if err != nil {
				fmt.Printf(err.Error())
			}
			return nil

		case "submit_addreopo_git_btn":
			fmt.Println("----------------------Submit to submit_addreopo_git_btn---------------- ")
			err := github.GetAddRepoData(interaction.BlockActionState.Values)

			//clear data value after approve
			for k := range interaction.BlockActionState.Values {
				delete(interaction.BlockActionState.Values, k)
			}

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "```Successfully create new repo to GitHub```", "post")

		case "scale_event_btn":
			fmt.Println("----------------------Submit to scale_event_btn---------------- ")
			ts := interaction.Message.Timestamp

			eventData := interaction.BlockActionState.Values["scale_event_input"]["scale_event_input"].Value
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			sheet, err := sheet.GetGoogleSheetData()

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			checkInputExist := false
			//check eventData input is exist or not
			for i, row := range sheet.Rows {
				if i == 0 {
					for _, cell := range row {
						//log.Println(cell.Value)
						if strings.TrimSpace(cell.Value) == eventData {
							checkInputExist = true
							break
						}
					}
				}
				break
			}

			if !checkInputExist {
				_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionText("Could not found event "+eventData, true))
				return nil
			}

			attachment, err := common.CreateAttachment("confirm_scale_event_btn", ":mag: Bot response: \nPlease double check ggsheet data carefully before apply", "User "+interaction.User.Name+" has submit for "+eventData+
				"\nPlease confirm this value then apply", "scale_event_apply_btn", interaction.User.Name+":"+eventData)

			_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

			if err != nil {
				log.Println(err)
			}

			return nil

		case "checkbox_scale_confirm":
			fmt.Println("----------------------Submit to checkbox_scale_confim---------------- ")

			checkBoxValue := interaction.BlockActionState.Values

			userName := interaction.User.Name
			msg, err := rancher.GetApproveScaleBtn(checkBoxValue, userName)

			if err != nil {
				sendResponse(client, interaction, err, err.Error(), "post")
				return nil
			}

			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)
			if err != nil {
				log.Println("could not update message to slack !!!")
			}

		case "remind_event_btn":
			fmt.Println("----------------------Submit to remind_event_btn---------------- ")

			eventInput := interaction.BlockActionState.Values["remind_event_input"]["remind_event_input"].Value
			eventBase := interaction.BlockActionState.Values["remind_event_rep_input"]["remind_event_rep_input"].Value

			eventReminds, err := rancher.GetRemindEventValueInput(eventInput, eventBase)

			//log.Println(eventReminds)
			if err != nil {
				sendResponse(client, interaction, err, err.Error(), "post")
				return nil
			}
			var authors []string
			for _, event := range eventReminds {
				//ts := interaction.Message.Timestamp

				authors = append(authors, event.Author)
				attachment := slack.Attachment{}
				//ts := event.TimeStamp

				t := table.NewWriter()
				t.SetOutputMirror(os.Stdout)

				t.AppendHeader(table.Row{"Deployment", "Scale"})
				valueSubmit := ""
				valueSubmit += strings.TrimSpace(strings.ReplaceAll(eventInput, " ", "-"))
				valueSubmit += " "
				for _, data := range event.Data {

					scale := ""
					// data is deployment
					if data.Replicas != -1 {
						scale = strconv.Itoa(data.Replicas)
						valueSubmit += strconv.Itoa(data.Position) + ":" + data.Name + ":" + strconv.Itoa(data.Replicas)
					} else {
						//data is hpa
						valueSubmit += strconv.Itoa(data.Position) + ":" + data.Name + ":" + strconv.Itoa(data.EventMinReplicas) + "-" + strconv.Itoa(data.EventMaxReplicas)
						scale = strconv.Itoa(data.EventMinReplicas) + "-" + strconv.Itoa(data.EventMaxReplicas)
					}

					valueSubmit += " "
					t.AppendRow([]interface{}{data.Name, scale})
				}

				attachment.Text = "```" + t.Render() + "```"
				attachment.Color = "#2484BE"

				eventOptimize := os.Getenv("SCALE_OP_HEADER_NAME")
				if eventInput == eventOptimize {
					attachment.Pretext = "Bot remind event message:\nHello `" +
						event.Author + "`, this message is to remind you need to check scale pods for optimizing cost" +
						"`, currently, it set as Normal Scale, please edit this value as you want, this scale down profile will run at 23h and scale back to normal at 7 a.m "
				} else {
					attachment.Pretext = "Bot remind event message:\nHello `" +
						event.Author + "`, this message is to remind you need to check scale for " +
						eventInput + ", please confim if it's oke, or edit if you want to modify following this table below"
				}

				// user, err := client.GetUserByEmail(event.Author + "@tiki.vn")
				user, err := client.GetUserByEmail(event.Author + "@tiki.vn")
				if err != nil {

					log.Println("Author sent: ", event.Author)
					sendResponse(client, interaction, err, event.Author+" not found", "post")
					return nil
				}

				attachment.CallbackID = "remind_event_user_btn"
				attachment.Fallback = "remind_event_user_btn"

				attachment.Actions = []slack.AttachmentAction{
					slack.AttachmentAction{
						Name:  "remind_event_apply_btn",
						Text:  "OK!",
						Style: "primary",
						Type:  "button",
						Value: valueSubmit,
						Confirm: &slack.ConfirmationField{
							Title:  "Confirm",
							Text:   "Are you sure? \n",
							OkText: "Apply",
						},
					},
					slack.AttachmentAction{
						Name:  "remind_event_edit_btn",
						Text:  "Edit",
						Type:  "button",
						Value: valueSubmit,
					},
				}

				_, _, err = client.PostMessage(interaction.Channel.User, slack.MsgOptionAttachments(attachment))

				//_, _, err = client.PostMessage(event.Channel, slack.MsgOptionTS(ts), msgHpaConfim[0])

				if err != nil {
					fmt.Printf(err.Error())
				}

				_, _, err = client.PostMessage(user.ID, slack.MsgOptionAttachments(attachment))

				if err != nil {
					sendResponse(client, interaction, err, err.Error(), "post")
					return nil
				}
			}

			//authors = common.RemoveDuplicateValues(authors)
			if len(eventReminds) > 0 {
				sendResponse(client, interaction, err, "Success send remind event to author:\n `"+strings.Join(authors, ", ")+"`", "post")
			} else {
				sendResponse(client, interaction, err, "Sheet is filled for event "+eventInput, "post")

			}

			if err != nil {
				log.Println("could not update message to slack !!!")
			}

		case "user_submit_edit_remind_event_btn":
			fmt.Println("----------------------Submit to user_submit_edit_remind_event_btn---------------- ")
			//channelID := os.Getenv("CHANNEL_ID")
			//log.Printf("log interaction: %+v", interaction)
			msg, err := rancher.HandleUserSubmitEditRemindEventBtn(interaction.BlockActionState.Values)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			_, _, err = client.DeleteMessage(interaction.User.ID, interaction.Message.Timestamp)
			//send apply edit block to user
			_, _, err = client.PostMessage(interaction.User.ID, slack.MsgOptionAttachments(msg))

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

		case "rerun_approve_btn":
			fmt.Println("----------------------Submit to rerun_approve_btn---------------- ")
			deploymentValue := interaction.BlockActionState.Values["rerun_input"]["rerun_input"].Value
			msg, err := rancher.HandleReRunDeploymentBtn(deploymentValue)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			_, err = client.PostEphemeral(interaction.Channel.ID, interaction.User.ID, slack.MsgOptionTS(interaction.Message.Timestamp), slack.MsgOptionAttachments(msg))

		case "submit_add_to_orgs_git_btn":
			fmt.Println("----------------------Submit to submit_add_to_orgs_git_btn---------------- ")

			userName := interaction.BlockActionState.Values["add_to_orgs_git_username"]["add_to_orgs_git_username"].Value
			err := github.HandleGitAddToOrgsBtn(userName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			sendResponse(client, interaction, err, "Successfully invite user "+userName+" to orgs", "post")

		case "search_console_btn":
			fmt.Println("----------------------Submit to search_console_btn---------------- ")
			userInput := interaction.BlockActionState.Values["search_console_input"]["search_console_input"].Value

			err := rancher.HandleSearchConsoleInput(client, interaction.Channel.ID, interaction.Message.Timestamp, userInput)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

		case "data_search_sent_to_channel_btn":
			fmt.Println("----------------------Submit to data_search_sent_to_channel_btn---------------- ")
			cmdInput := interaction.BlockActionState.Values["data_search_sent_to_channel"]["data_search_sent_to_channel"].Value
			err := rancher.HandleVerifedConsoleInput(client, interaction.Channel.ID, interaction.Message.Timestamp, cmdInput)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			sendResponse(client, interaction, err, "Successfully sent data to group infra-console", "post")

		case "vault_update_btn":
			fmt.Println("----------------------Submit to vault_update_btn---------------- ")
			deploymentInput := interaction.BlockActionState.Values["vault_find_deployment"]["vault_find_deployment"].Value
			secretName := interaction.BlockActionState.Values["vault_secret_name"]["vault_secret_name"].Value
			vaultDataInput := interaction.BlockActionState.Values["vault_update_value"]["vault_update_value"].Value

			if len(vaultDataInput) > 35000 {
				err = errors.New("vault data is too long")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			addMsg, vaultUrl, err := vault.HandleDeploymentVaultUpdateValue(deploymentInput, vaultDataInput, secretName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}

			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n`Update vault successfully, url:\n"+vaultUrl+"\nNow showing data that updated`\nVault url updated\n"+addMsg,
				false,
				false)

			headerSection := slack.NewSectionBlock(headerText, nil, nil)

			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}

			output, addMsg, err := vault.HandleDeploymentVaultCheckValue(deploymentInput, vaultDataInput, secretName)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}
			//clear data value after approve

			attachment := slack.Attachment{}
			//ts := event.TimeStamp

			if addMsg != "" {
				attachment.Pretext = ":mag: Bot response:\nWarnings: \n" + addMsg
			} else {
				attachment.Pretext = ":mag: Bot response:"
			}

			attachment.Text = output
			attachment.Color = "#00cc00"

			_, timestampPost, err := client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(interaction.Message.Timestamp), slack.MsgOptionAttachments(attachment))

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			time.Sleep(5 * time.Second)
			_, _, err = client.DeleteMessage(interaction.Channel.ID, timestampPost)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			return nil

		case "vault_check_btn":
			fmt.Println("----------------------Submit to vault_check_btn---------------- ")
			deploymentInput := interaction.BlockActionState.Values["vault_find_deployment"]["vault_find_deployment"].Value
			secretName := interaction.BlockActionState.Values["vault_secret_name"]["vault_secret_name"].Value
			vaultDataInput := interaction.BlockActionState.Values["vault_check_value"]["vault_check_value"].Value
			output, addMsg, err := vault.HandleDeploymentVaultCheckValue(deploymentInput, vaultDataInput, secretName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}
			//clear data value after approve

			attachment := slack.Attachment{}
			//ts := event.TimeStamp

			if addMsg != "" {
				attachment.Pretext = ":mag: Bot response:\nWarnings: \n" + addMsg
			} else {
				attachment.Pretext = ":mag: Bot response:"
			}

			attachment.Text = output
			attachment.Color = "#00cc00"

			_, timestampPost, err := client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(interaction.Message.Timestamp), slack.MsgOptionAttachments(attachment))

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			time.Sleep(5 * time.Second)
			_, _, err = client.DeleteMessage(interaction.Channel.ID, timestampPost)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			return nil

		case "create_vault_btn":
			fmt.Println("----------------------Submit to create_vault_btn---------------- ")
			deploymentInput := interaction.BlockActionState.Values["vault_new_deployment"]["vault_new_deployment"].Value
			secretName := interaction.BlockActionState.Values["vault_secret_name"]["vault_secret_name"].Value
			vaultDataInput := interaction.BlockActionState.Values["vault_new_value"]["vault_new_value"].Value

			if deploymentInput == "" || vaultDataInput == "" {
				sendResponse(client, interaction, err, "Input is empty", "post")
				return nil
			}

			if len(vaultDataInput) > 35000 {
				err = errors.New("vault data is too long")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			output, addMsg, vaultURL, err := vault.HandleDeploymentVaultCreate(deploymentInput, vaultDataInput, secretName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}
			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nVault url create at:\n"+vaultURL+"\n"+addMsg+"\n`"+output+"`",
				false,
				false)

			headerSection := slack.NewSectionBlock(headerText, nil, nil)

			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}

			output, addMsg, err = vault.HandleDeploymentVaultCheckValue(deploymentInput, vaultDataInput, secretName)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil

			}
			//clear data value after approve

			attachment := slack.Attachment{}
			//ts := event.TimeStamp

			if addMsg != "" {
				attachment.Pretext = ":mag: Bot response:\nWarnings: \n" + addMsg
			} else {
				attachment.Pretext = ":mag: Bot response:"
			}

			attachment.Text = output
			attachment.Color = "#00cc00"

			_, timestampPost, err := client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(interaction.Message.Timestamp), slack.MsgOptionAttachments(attachment))

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}

			time.Sleep(5 * time.Second)
			_, _, err = client.DeleteMessage(interaction.Channel.ID, timestampPost)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}
			return nil
		case "init_optimize_cost_btn":
			fmt.Println("----------------------Submit to init_optimize_cost_btn msg--------------- ")

			enableOptimizeCost := strings.TrimSpace(interaction.BlockActionState.Values["optimize_cost_options"]["optimize_cost_options"].SelectedOption.Value)
			eventInit := strings.TrimSpace(interaction.BlockActionState.Values["event_scale_init"]["event_scale_init"].Value)
			/*
				// timeOptimizeRun := strings.TrimSpace(interaction.BlockActionState.Values["time_optimize_run"]["time_optimize_run"].Value)
				// if enableOptimizeCost == "" || timeNormalRun == "" || timeOptimizeRun == "" {
				// 	sendResponse(client, interaction, err, "Input is empty", "post")
				// 	return nil
				// }

				// if timeNormalRun == timeOptimizeRun {
				// 	err := errors.New("start time cannot be same as end time")
				// 	sendResponse(client, interaction, err, "error", "post")
				// 	return nil
				// }

				// timeNormalInt, err := strconv.Atoi(timeNormalRun)

				// if err != nil {
				// 	return err
				// }

				// if timeNormalInt < 0 || timeNormalInt > 23 {
				// 	return errors.New("invalid hour")
				// }

				// timeOptimizeInt, err := strconv.Atoi(timeOptimizeRun)

				// if err != nil {
				// 	return err
				// }

				// if timeOptimizeInt < 0 || timeOptimizeInt > 23 {
				// 	return errors.New("invalid hour")
				// }
				// textTime := "\n`Time start optimize cost: " + timeOptimizeRun + "`\n`Time start scale normal: " + timeNormalRun + "`"

				// timeNormalInt = (timeNormalInt - 7) % 24
				// timeOptimizeInt = (timeOptimizeInt - 7) % 24

				//timeRunOptimizeCost := strconv.Itoa(timeNormalInt) + "-" + strconv.Itoa(timeOptimizeInt)
				//attachment, err := common.CreateAttachment("confirm_optimize_value", ":mag: Bot response", "Confirm data: \n`enable for optimize cost: "+enableOptimizeCost+"`"+textTime, "optimize_value", enableOptimizeCost+" "+timeRunOptimizeCost)
			*/
			err = rancher.SendConfirmOptimizeData(enableOptimizeCost, eventInit)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(interaction.Message.Timestamp), slack.MsgOptionText("`Update enable optimizing: "+enableOptimizeCost+"`", false))
			//sendResponse(client, interaction, err, "Update scale profile successfully", "post")
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

		case "user_self_update_vault":
			fmt.Println("----------------------Submit to user_self_update_vault msg--------------- ")
			//log.Printf("%+v", interaction)

			data := interaction.ActionCallback.BlockActions[0].Value
			secretName := interaction.BlockActionState.Values["action_choose_secret"]["action_choose_secret"].SelectedOption.Value
			vaultDataInput := interaction.BlockActionState.Values["vault_self_update_value"]["vault_self_update_value"].Value

			if len(vaultDataInput) > 35000 {
				err = errors.New("vault data is too long")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			//create jira ticket
			dataSplit := strings.Split(data, " ")
			deployment := dataSplit[0]
			userID := dataSplit[1]
			userCreateJira, err := client.GetUserInfo(userID)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}
			userName := userCreateJira.Name
			jiraTicketUrl, err := atlantis.CreateTicket("update vault", deployment, userName, secretName, vaultDataInput)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			//send msg to systemoi
			err = vault.SendApproveSelfUpdateVault(client, data, secretName, vaultDataInput, jiraTicketUrl)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n`Your request has been sent to systemoi, please wait...`\nYour jira ticket is:\n"+jiraTicketUrl,
				false,
				false)

			headerSection := slack.NewSectionBlock(headerText, nil, nil)

			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)

			return nil

		case "user_self_create_vault":
			fmt.Println("----------------------Submit to user_self_create_vault msg--------------- ")
			data := interaction.ActionCallback.BlockActions[0].Value
			secretName := interaction.BlockActionState.Values["vault_self_create_secret_name"]["vault_self_create_secret_name"].Value
			vaultDataInput := interaction.BlockActionState.Values["vault_self_create_value"]["vault_self_create_value"].Value

			if secretName == "" {
				err = errors.New("secret name is empty")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			if len(vaultDataInput) > 35000 {
				err = errors.New("vault data is too long")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			//create jira ticket
			dataSplit := strings.Split(data, " ")
			deployment := dataSplit[0]
			userID := dataSplit[1]
			userCreateJira, err := client.GetUserInfo(userID)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}
			userName := userCreateJira.Name
			jiraTicketUrl, err := atlantis.CreateTicket("create vault", deployment, userName, secretName, vaultDataInput)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			//send msg to systemoi
			err = vault.SendApproveSelfCreateVault(client, data, secretName, vaultDataInput, jiraTicketUrl)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n`Your request has been sent to systemoi, please wait...`\nYour jira ticket is:\n"+jiraTicketUrl,
				false,
				false)

			headerSection := slack.NewSectionBlock(headerText, nil, nil)

			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, _, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)

			if err != nil {
				log.Println(err)
			}
			return nil

		case "pattern_vault_check_btn":
			//log.Println(output, keys, userID)
			headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: Please wait...",
				false,
				false)

			headerSection := slack.NewSectionBlock(headerText, nil, nil)

			msg := slack.MsgOptionBlocks(
				headerSection,
			)
			_, newTs, _, err := client.UpdateMessage(interaction.Channel.ID, interaction.Message.Timestamp, msg)

			if err != nil {
				log.Println(err)
				return nil
			}
			//log.Println("Go to pattern_vault_check_btn")
			data := interaction.ActionCallback.BlockActions[0].Value

			dataSplit := strings.Split(data, " ")
			eventType := dataSplit[2]
			userID := dataSplit[1]
			deployment := dataSplit[0]
			secretName := interaction.BlockActionState.Values["action_choose_secret"]["action_choose_secret"].SelectedOption.Value
			patternSearch := interaction.BlockActionState.Values["pattern_input_vault_check"]["pattern_input_vault_check"].Value

			output, keys, err := vault.HandleDeploymentSearchVault(deployment, patternSearch, secretName)

			if err != nil {
				sendResponse(client, interaction, err, err.Error(), "post")
				return nil
			}

			//chat to user
			if eventType == "im" {
				attachment := slack.Attachment{}
				//ts := event.TimeStamp

				attachment.Text = fmt.Sprintf("```" + keys + "```")
				attachment.Color = "#00cc00"

				attachment.Pretext = "Bot response:"

				_, ts, err := client.PostMessage(userID, slack.MsgOptionTS(newTs), slack.MsgOptionAttachments(attachment))

				if err != nil {
					log.Println(err)
					return nil
				}
				time.Sleep(10 * time.Second)
				if ts == "" {
					log.Println("cannot find ts to send user")
				}

				client.DeleteMessage(userID, ts)
				return nil

			} else {
				//chat to channel
				ts := sendResponse(client, interaction, err, output, "post")
				time.Sleep(10 * time.Second)
				client.DeleteMessage(interaction.Channel.ID, ts)
				return nil
			}
		case "send_manage_wl_btn":
			fmt.Println("Go to send_manage_wl_btn")
			data := interaction.ActionCallback.BlockActions[0].Value
			userNameGit := strings.TrimSpace(interaction.BlockActionState.Values["user_name_git"]["user_name_git"].Value)
			manager := strings.TrimSpace(interaction.BlockActionState.Values["user_manager"]["user_manager"].Value)
			description := strings.ReplaceAll(strings.TrimSpace(interaction.BlockActionState.Values["user_description"]["user_description"].Value), " ", "-")

			err := handleManageWLClicked(client, interaction, data, userNameGit, manager, description)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
			}
			return nil

		case "send_approve_redeploy_to_system":
			fmt.Println("Go to send_approve_redeploy_to_system")
			deployment := interaction.ActionCallback.BlockActions[0].Value
			urlRedeploy := strings.TrimSpace(interaction.BlockActionState.Values["revision_action_id"]["revision_action_id"].SelectedOption.Value)

			keyText := interaction.BlockActionState.Values["revision_action_id"]["revision_action_id"].SelectedOption.Text.Text
			description := deployment + " to " + keyText
			deploymentName := strings.Split(deployment, " ")[0]
			deploymentNameRegex := strings.ReplaceAll(deploymentName, "`", "")
			err := rancher.SendRequeststRollbackToSystem(description, urlRedeploy, deploymentNameRegex, client, &interaction.User)

			ts := interaction.Message.Timestamp
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "Sent request to systemoi, please wait for approving...\nDescription: "+deployment, "post")
			client.DeleteMessage(interaction.Channel.ID, ts) //log.Println(deployment, urlRedeploy)
			return nil
		}

	case slack.InteractionTypeInteractionMessage:
		fmt.Println("----------------------Submit to interaction msg--------------- ")
		data := interaction.ActionCallback.AttachmentActions[0]

		for pattern, actionFunc := range reactInterractionReceiveMsg {
			re := regexp.MustCompile(pattern)
			if re.MatchString(data.Name) {
				err := actionFunc(client, data.Value, &interaction.User, &interaction)

				if err != nil {
					client.PostMessage(interaction.Channel.ID, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
					return nil
				}
				return nil
			}
		}

		if data.Name == "hpa_approve_btn" {
			fmt.Println("----------------------Submit to hpa approve btn--------------- ")

			err := rancher.SendHPADataToRancher(data.Value)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, err.Error(), "update")

				return nil
			}

			sendResponse(client, interaction, err, "Successfully update hpa, Check status after a while with `hpa list` command", "update")

			if err != nil {
				log.Printf("Cannot update hpa message")
			}
		} else if data.Name == "deployment_approve_scale_btn" {
			fmt.Println("----------------------Submit to deployment_approve_scale_btn--------------- ")

			err := rancher.SendDeploymentDataToRancher(data.Value)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, err.Error(), "update")

				return nil
			}

			sendResponse(client, interaction, err, "Successfully update hpa, Check status after a while with `deploy list` command", "update")

			if err != nil {
				log.Printf("Cannot update hpa message")
			}
		} else if data.Name == "deployment_scale_manually_btn" {
			fmt.Println("----------------------Submit to deployment_scale_manually_btn--------------- ")

			err := rancher.SendScaleManuallyToRancher(data.Value)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, err.Error(), "update")

				return nil
			}

			sendResponse(client, interaction, err, "Successfully update deployment, Check status after a while with `deploy find` command to get more infor", "update")

			if err != nil {
				log.Printf("Cannot update hpa message")
			}
		} else if data.Name == "redeploy_deployment_btn" {
			fmt.Println("----------------------Submit to redeploy_deployment_btn--------------- ")

			err := rancher.SendRedeploDeploymentToRancher(data.Value)

			if err != nil {
				fmt.Println("error")
				sendResponse(client, interaction, err, err.Error(), "update")

				return nil
			}

			sendResponse(client, interaction, err, "Successfully redeploy deployment!!!", "update")

			if err != nil {
				log.Printf("Cannot update hpa message")
			}
		} else if data.Name == "scale_event_apply_btn" {
			log.Println("----------------------Submit to scale_event_apply_btn--------------- ")

			dataSplit := strings.SplitN(data.Value, ":", 2)

			if len(dataSplit) != 2 {
				err := errors.New("could not get data correctly, please check data " + data.Value)
				sendResponse(client, interaction, err, "error", "update")
			}
			userSubmitChange := dataSplit[0]
			value := dataSplit[1]
			if userSubmitChange == interaction.User.Name {

				err := errors.New("User approve must be different as user submit event!!!")
				sendResponse(client, interaction, err, "error", "update")
				return nil
				// if userSubmitChange != "xuan.can" {
				// 	return nil
				// }
			}

			hpa, deploy, err := rancher.HandleScaleEventData(value)

			log.Println("hpa and deploy change ", hpa, deploy)
			if err != nil {

				sendResponse(client, interaction, err, "error", "update")

				return nil
			}

			sendResponse(client, interaction, err, "Success send scale event request, please wait for a while or use `update rancherdata` to update gg sheet value (auto run once time after scale)", "update")

			//sleep 3s before update sheet
			time.Sleep(30 * time.Second)
			err = rancher.HandleGoogleSheetUpdateData()

			if err != nil {

				sendResponse(client, interaction, err, "error", "update")

				return nil
			}

			sendResponse(client, interaction, err, "Update gg sheet successfully", "update")

			//update scale_info properties
			rancher.UpdateScaleProfileLocal(value)

			return nil

		} else if data.Name == "remind_event_apply_btn" {

			err := rancher.GetRemindEventOkBlock(data.Value)
			//send response update message of user
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			t := table.NewWriter()
			t.SetOutputMirror(os.Stdout)
			t.AppendHeader(table.Row{"Line", "Deployment", "Scale"})

			splitData := strings.Split(data.Value, " ")

			for i, line := range splitData {
				if i == 0 {
					eventSplit := strings.Split(line, "-")
					t.AppendRow([]interface{}{"zero", strings.Join(eventSplit, " ")})
					continue
				}

				splitLine := strings.Split(line, ":")

				t.AppendRow([]interface{}{splitLine[0], splitLine[1], splitLine[2]})

			}
			sendResponse(client, interaction, err, "Successfully update information, thank you!!!\nEvent logs:\n```"+t.Render()+"```", "update")

			//send message to slack channel
			channelID := os.Getenv("CHANNEL_ID")
			_, _, err = client.PostMessage(channelID, slack.MsgOptionText("User `"+interaction.User.Name+"` has submit *OK* for new event scalers\nLogs deployment changed:\n```"+t.Render()+"```", true))

			if err != nil {
				log.Println(err)
			}
			return nil

		} else if data.Name == "remind_event_edit_btn" {

			sendResponse(client, interaction, err, "Show block edit", "delete")

			msg, err := rancher.GetRemindEventEditBlock(data.Value)

			if err != nil {
				log.Println(err)
			}

			_, _, err = client.PostMessage(interaction.User.ID, msg)

			if err != nil {
				log.Println(err)
			}

			return nil

		} else if data.Name == "confirm_user_edit_deployment_btn" {
			err := rancher.UpdateGoogleSheetData(data.Value)
			//send response update message of user
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			t := table.NewWriter()
			t.SetOutputMirror(os.Stdout)
			t.AppendHeader(table.Row{"Line", "Deployment", "Scale"})

			splitData := strings.Split(data.Value, " ")

			for i, line := range splitData {
				if i == 0 {
					eventSplit := strings.Split(line, "-")
					t.AppendRow([]interface{}{"Event", strings.Join(eventSplit, " ")})

					continue
				}

				splitLine := strings.Split(line, ":")

				t.AppendRow([]interface{}{splitLine[0], splitLine[1], splitLine[2]})

			}

			sendResponse(client, interaction, err, "Successfully update information, thank you!!!\nEvent logs:\n```"+t.Render()+"```", "update")

			//send message to slack channel
			channelID := os.Getenv("CHANNEL_ID")
			_, _, err = client.PostMessage(channelID, slack.MsgOptionText("User `"+interaction.User.Name+"` has submitted change for new event scalers by editting\nLogs deployment changed:\n```"+t.Render()+"```", true))

			if err != nil {
				fmt.Println(err)
			}
			return nil
		} else if data.Name == "user_rerun_apply_btn" {

			//log.Println(data)
			err := rancher.GetUserApproveReRunData(data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			deploymentName := strings.SplitN(data.Value, "@", 2)[1]

			/*
				counter := 0

				for {
					dataOutput, _, _, err := rancher.GetDeploymentFindInputData(deploymentName)
					time.Sleep(2 * time.Second)
					counter++
					if err != nil {
						sendResponse(client, interaction, err, "error", "post")
						return nil
					}

					if strings.Contains(dataOutput, "updating") {
						_, err = client.PostEphemeral(interaction.Channel.ID, interaction.User.ID, slack.MsgOptionText(dataOutput, true))
						if err != nil {
							log.Println(err)
						}
						break
					}
					if counter > 3 {
						break
					}
				}
			*/

			sendResponse(client, interaction, err, "Redeploy `"+deploymentName+"` successfully", "update")

			// err = updateTimeUserRedeploy(user, deployment, deployLeft)

			// if err != nil {
			// 	return err
			// }

			return nil

		} else if data.Name == "optimize_value" {
			log.Println("Confirm optimize value")

			dataSubmit := strings.Split(data.Value, " ")

			if len(dataSubmit) != 2 {
				err := errors.New("data format error")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			enableBot := dataSubmit[0]
			//timeRunOptimize := dataSubmit[1]

			err := rancher.SendConfirmOptimizeData(enableBot, "")

			if err != nil {
				err := errors.New("data format error")
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			sendResponse(client, interaction, err, "success update optimize profile", "update")

			return nil

		} else if data.Name == "cancel_action" {
			if data.Value == "cancel" {

				sendResponse(client, interaction, err, "User "+interaction.User.Name+" has cancelled event", "update")

				if err != nil {
					log.Println("Error msg delete", err)
				}
			}
		}

		//user request add deployment is accept
		if data.Name == "user_add_deployment" {
			err := rancher.AddDeployToUser(data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "update")
			}

			userUpdated := strings.Split(data.Value, " ")
			user, err := client.GetUserInfo(userUpdated[0])
			if err != nil {
				sendResponse(client, interaction, err, "error", "update")
			}
			sendResponse(client, interaction, err, "Added redeployment *"+userUpdated[1]+"* to user "+user.Name, "update")

			MAX_TIME_DEPLOY_PER_DAY := os.Getenv("MAX_TIME_DEPLOY_PER_DAY")
			sendResponseToSpecificUser(client, userUpdated[0], err, "Your request has been approved\nNow, You could redeploy svc `"+userUpdated[1]+"` `"+MAX_TIME_DEPLOY_PER_DAY+"` times per day")
			return nil
		}

		//system approve for user update vault

		if data.Name == "approve_self_update_vault" {
			//log.Println(data.Value)
			addMsg, userID, jiraTicketURL, _, urlVault, err := vault.SendDataConfirmedToUpdateVault(client, data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				sendResponseToSpecificUser(client, userID, err, "error")
				return nil
			}

			err = atlantis.CloseJiraTicket(jiraTicketURL)
			if err != nil {
				return err
			}

			sendResponse(client, interaction, err, "Success update vault data, now send data updated to user request and close jira ticket\nVault update url:\n"+urlVault, "update")

			if addMsg != "" {
				dataSplit := strings.Split(data.Value, " ")
				userName := dataSplit[0]
				user, err := client.GetUserInfo(userName)
				ts, err := sendResponseToChannel(client, err, "<!subteam^SVALNFK27> Warnings, user "+user.Name+" update vault data:  \n"+addMsg, "")
				log.Println("Ts is", ts)
				time.Sleep(300 * time.Second)
				_, _, err = client.DeleteMessage(interaction.Message.Channel, ts)

				if err != nil {
					log.Println(err)
				}
			}

			//send msg to user requested update vault
			attachment, err := common.CreateAttachmentOnlyShow("self_show_update_vault", ":mag: Bot response:",
				"`Systemoi has updated your request, close your jira ticket , now you could choose to show data that updated`", "self_show_update_vault", data.Value)

			if err != nil {
				log.Println(err)
			}
			_, _, err = client.PostMessage(userID, slack.MsgOptionAttachments(attachment))

			if err != nil {
				log.Println(err)
			}
			return nil
		}

		//show data when user needed
		if data.Name == "self_show_update_vault" {
			ts := interaction.MessageTs

			err := vault.ShowSelfUserUpdatedVaultValue(client, interaction.Channel.ID, ts, data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			return nil
		}

		//get new vault data
		if data.Name == "approve_selft_create_vault" {
			//log.Println(data.Value)
			addMsg, userID, jiraTicketURL, _, vaultURL, err := vault.SendDataConfirmedToCreateVault(client, data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				sendResponseToSpecificUser(client, userID, err, "error")
				return nil
			}
			err = atlantis.CloseJiraTicket(jiraTicketURL)
			sendResponse(client, interaction, err, "Success create vault data, now send data created to user request\nVault create url:\n"+vaultURL, "update")

			if addMsg != "" {
				dataSplit := strings.Split(data.Value, " ")
				userName := dataSplit[0]
				user, err := client.GetUserInfo(userName)
				if err != nil {
					log.Println(err)
					return nil
				}
				ts, err := sendResponseToChannel(client, err, "<!subteam^SVALNFK27> Warnings, user "+user.Name+" has create vault:  \n```"+addMsg+"```", "")

				if err != nil {
					log.Println(err)
					return nil
				}
				time.Sleep(300 * time.Second)
				client.DeleteMessage(interaction.Message.Channel, ts)
			}

			//send msg to user requested create vault
			attachment, err := common.CreateAttachmentOnlyShow("self_show_create_vault", ":mag: Bot response:",
				"`Systemoi has updated your request , jira ticket is closed, now you could choose to show data that created`", "self_show_create_vault", data.Value)

			if err != nil {
				log.Println(err)
			}
			_, _, err = client.PostMessage(userID, slack.MsgOptionAttachments(attachment))

			if err != nil {
				log.Println(err)
			}
			return nil
		}

		if data.Name == "self_show_create_vault" {
			ts := interaction.MessageTs

			err := vault.ShowSelfUserCreatedVaultValue(client, interaction.Channel.ID, ts, data.Value)

			log.Println(err)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			return nil
		}

		if data.Name == "manager_approve_for_user" {
			log.Println("submit approve for user", data.Value)

			// err := handleManagerSendRequestToSystem(client, interaction.User.Name, data.Value)
			// if err != nil {
			// 	sendResponse(client, interaction, err, "error", "post")
			// 	return nil
			// }
			err := handleSystemReviewManageWL(client, interaction, data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			splitData := strings.Split(data.Value, " ")

			userRequest := splitData[2]
			JiraTicket := splitData[6]
			err = atlantis.CloseJiraTicket(JiraTicket)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "Accepted manage workload request, closed jira ticket: "+JiraTicket, "update")

			sendResponseToSpecificUser(client, userRequest, err, "Your ticket has been approved, now you can manage workload for 4 hour")
			return nil
		}

		if data.Name == "manager_send_confirm_manage_wl" {
			log.Println("submit manager_send_confirm_manage_wl for user", data.Value)

			err := handleSystemReviewManageWL(client, interaction, data.Value)
			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			splitData := strings.Split(data.Value, " ")
			userRequest := splitData[2]
			JiraTicket := splitData[6]
			err = atlantis.CloseJiraTicket(JiraTicket)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			sendResponse(client, interaction, err, "Sent request to infra channel, close jira ticket: "+JiraTicket, "update")
			sendResponseToSpecificUser(client, userRequest, err, "Systemoi has approved your ticket, jira ticket now closed")

			//update to local file
			err = updateManageWLToLocalFile(data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			return nil
		}

		if data.Name == "system_approve_rollback" {
			log.Println("submit system_approve_rollback for user", data.Value)

			dataSplit := strings.Split(data.Value, " ")

			if len(dataSplit) != 3 {
				sendResponse(client, interaction, err, "Data rollback not correct ", "post")
				return nil
			}
			userRequest := dataSplit[0]
			url := dataSplit[1]
			deploymentName := dataSplit[2]
			err := rancher.SendRollbackToRancher(url, deploymentName)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "Sent request to rancher successfully", "update")
			sendResponseToSpecificUser(client, userRequest, err, "Systemoi has approved your ticket, your deployment has been rollback")
			return nil
		}

		if data.Name == "approve_set_deployment_pod" {
			log.Println("submit approve_set_deployment_pod for user", data.Value)

			log.Println(data.Value)

			err := rancher.SendSetPodNumberToRancher(data.Value)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}

			//show value update
			deployment := strings.Split(strings.Split(data.Value, "|")[1], ":")[2]
			data, _, _, err := rancher.GetDeploymentFindInputData(deployment)

			if err != nil {
				sendResponse(client, interaction, err, "error", "post")
				return nil
			}
			sendResponse(client, interaction, err, "Success update deployment data\n"+data, "update")

			return nil
		}

	default:
		fmt.Println("----------------------Submit action--------------- ")

	}

	return nil
}

func sendResponseMsgOption(client *slack.Client, interaction slack.InteractionCallback, ts string, msg slack.MsgOption, postType string) error {

	log.Println("Ts", ts)
	var err error
	if postType == "post" {
		_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), msg)

		if err != nil {
			log.Println(err)
			return err
		}
	} else {
		_, _, _, err = client.UpdateMessage(interaction.Channel.ID, ts, msg)
	}

	if err != nil {
		log.Println(err)
	}
	return nil
}

func sendInformationToUser(client *slack.Client, interaction slack.InteractionCallback, userName string, pwd string) error {

	user, err := client.GetUserByEmail(userName + "@tiki.vn")

	fmt.Println("=>>>>>>User info: ", user)

	if err != nil {
		fmt.Println(err)
		return err
	}

	attachment := slack.Attachment{}
	attachment.Text = fmt.Sprintf("Your rancher password is: " + pwd)
	_, _, err = client.PostMessage(user.ID, slack.MsgOptionAttachments(attachment))

	return err
}

func sendResponseAsText(client *slack.Client, interaction slack.InteractionCallback, err error, response string) error {
	ts := interaction.Message.Timestamp

	_, _, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionText(response, true))

	if err != nil {
		return err
	}

	return nil
}

func sendResponse(client *slack.Client, interaction slack.InteractionCallback, err error, response string, postType string) string {
	ts := interaction.Message.Timestamp
	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	if response == "error" {
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
	} else {
		attachment.Text = response
		attachment.Color = "#00cc00"
	}
	attachment.Pretext = ":mag: Bot response:"

	if postType == "post" {
		_, ts, err = client.PostMessage(interaction.Channel.ID, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	} else if postType == "update" {
		fmt.Println(ts)
		_, ts, _, err = client.UpdateMessage(interaction.Channel.ID, interaction.MessageTs, slack.MsgOptionAttachments(attachment))

	} else if postType == "delete" {
		_, _, err = client.DeleteMessage(interaction.Channel.ID, interaction.MessageTs)

	}

	if err != nil {
		log.Println(err)
	}
	return ts
}

func sendResponseToChannel(client *slack.Client, err error, response, channelName string) (string, error) {

	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	if response == "error" {
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
	} else {
		attachment.Text = response
		attachment.Color = "#00cc00"
	}
	attachment.Pretext = ":mag: Bot response:"
	godotenv.Load(".env")
	CHANNEL_ID := ""

	if channelName == "" {
		CHANNEL_ID = os.Getenv("CHANNEL_ID")
	} else if channelName == "redeploy-notification" {
		CHANNEL_ID = os.Getenv("CHANNEL_REDEPLOY_NOTIFCATION")
	}

	_, ts, err := client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		return ts, err
	}
	return ts, nil
}

func sendResponseToUser(client *slack.Client, interaction slack.InteractionCallback, userID string, err error, response, postType string) error {
	//ts := interaction.Message.Timestamp
	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	if response == "error" {
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
	} else {
		attachment.Text = fmt.Sprintf(response)
		attachment.Color = "#00cc00"
	}
	attachment.Pretext = "Bot response:"
	if postType == "post" {
		client.PostMessage(userID, slack.MsgOptionAttachments(attachment))
	} else if postType == "update" {
		_, _, _, err := client.UpdateMessage(userID, interaction.MessageTs, slack.MsgOptionAttachments(attachment))

		if err != nil {
			log.Println(err)
		}
	} else if postType == "delete" {
		client.DeleteMessage(userID, interaction.MessageTs)
	}

	_, _, err = client.PostMessage(interaction.User.ID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		return err
	}

	return err
}

func sendResponseToSpecificUser(client *slack.Client, userID string, err error, response string) string {
	//ts := interaction.Message.Timestamp
	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	if response == "error" {
		attachment.Text = fmt.Sprintf("Error: " + err.Error())
		attachment.Color = "#ff0000"
	} else {
		attachment.Text = fmt.Sprintf(response)
		attachment.Color = "#00cc00"
	}
	attachment.Pretext = "Bot response:"

	_, ts, err := client.PostMessage(userID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		log.Println(err)
		return ""
	}

	return ts
}
