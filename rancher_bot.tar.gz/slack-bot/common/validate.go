package common

import (
	"errors"
	"os"
	"strings"

	"github.com/joho/godotenv"
)

func ValidateInput(input string, inputType string) error {
	godotenv.Load(".env")

	nameValidate := os.Getenv("NAME_REGEX")

	kongRouteValidate := os.Getenv("KONG_ROUTE_REGEX")

	kongMethodValidate := os.Getenv("KONG_METHOD_REGEX")

	gitReposValidate := os.Getenv("GIT_REPOS_REGEX")

	gitNameValidate := os.Getenv("GIT_NAME_REGEX")

	//gitName can be empty

	if inputType != "gitRepos" {
		if input == "" {
			return errors.New("input cannot be empty")
		}
	}

	switch inputType {
	case "name":
		if strings.ContainsAny(input, nameValidate) {
			return errors.New("input has special character")
		}
	case "kongRoute":
		if strings.ContainsAny(input, kongRouteValidate) {
			return errors.New("routes has special character")
		}
	case "kongMethod":
		if strings.ContainsAny(input, kongMethodValidate) {
			return errors.New("method has special character")
		}
	case "gitRepos":
		if strings.ContainsAny(input, gitReposValidate) {
			return errors.New("Repos has special character")
		}
	case "gitName":
		if strings.ContainsAny(input, gitNameValidate) {
			return errors.New("Repos has special character")
		}

	}

	return nil

}
