package common

import (
	"bytes"
	"errors"
	"log"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
)

var (
	lowerCharSet   = "abcdedfghijklmnopqrstuvwxyz"
	upperCharSet   = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	specialCharSet = "!@#$%^&*()-+"
	numberSet      = "0123456789"
	allCharSet     = lowerCharSet + upperCharSet + specialCharSet + numberSet
)

func CreateNewAttachment(preText, text, color, buttonName, callbackID, buttonID, buttonValue, denyValue string, hasButton bool) (slack.Attachment, error) {

	attachment := slack.Attachment{}
	attachment.Text = text
	attachment.Color = color
	attachment.Pretext = preText
	attachment.CallbackID = callbackID
	attachment.Fallback = callbackID

	if hasButton {

		approveBtn := slack.AttachmentAction{
			Name:  buttonID,
			Text:  buttonName,
			Style: "primary",
			Type:  "button",
			Value: buttonValue,
		}

		deniedBtn := slack.AttachmentAction{
			Name:  denyValue,
			Text:  "Deny",
			Style: "danger",
			Type:  "button",
			Value: buttonValue,
		}
		attachment.Actions = append(attachment.Actions, approveBtn)
		attachment.Actions = append(attachment.Actions, deniedBtn)

	}

	return attachment, nil
}

func HandleUserSelfGenFileBlock(input, user string) (slack.MsgOption, error) {
	var msg slack.MsgOption

	// splitInput := strings.Split(input, " ")

	// if len(splitInput) != 2 {
	// 	return msg, errors.New("format not correct, please check")
	// }

	// //validate data

	// data := splitInput[2]

	// //get data if format is /home/abc/data.csv
	// if strings.Contains(data, "/") {
	// 	dataSplit := strings.Split(data, "/")
	// 	data = dataSplit[len(dataSplit)-1]
	// }

	// //check data
	// if strings.Contains(data, ".") {
	// 	return msg, errors.New("file format not correct, need end with .csv, .xlsx, .xls, .txt...")
	// }

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: Please fill information",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	msg = slack.MsgOptionBlocks(
		headerSection,
	)

	return msg, nil
}

func ConvertToUnicode(input string) string {
	var output string

	output = strings.ReplaceAll(input, "&amp;", "&")
	output = strings.ReplaceAll(output, "&lt;", "<")
	output = strings.ReplaceAll(output, "&gt;", ">")

	//log.Println(output)

	return output
}

func GetKeyFromKeyValue(input string) (string, error) {
	var output string

	strimInput := strings.Trim(input, "'")
	strimInput = strings.Trim(strimInput, "\"")
	strimInput = strings.Trim(strimInput, ",")
	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return "", errors.New("Notthing to do!!!")

	}

	for _, line := range lines {
		line = strings.Trim(line, ",")

		//log.Println("Current lines ", line)
		if line == "" {
			continue
		}

		if strings.Contains(line, "\\n") {
			return "", errors.New("not support multi lines vault yet")
		}

		isComment := strings.HasPrefix(line, "#")

		if isComment {
			continue
		}

		line = strings.TrimSpace(line)

		splitInput := strings.SplitN(line, "=", 2)

		if len(splitInput) == 1 {
			splitInput = strings.SplitN(line, ":", 2)
		}

		if len(splitInput) == 2 {
			key := splitInput[0]
			output += key + "\n"
		} else {
			return "", errors.New("not support this type yet")
		}
	}

	return output, nil

}
func RandString(length int) string {
	var (
		block strings.Builder
		chars = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789")
	)
	rand.Seed(time.Now().UnixNano())
	for i := 0; i < length; i++ {
		block.WriteRune(chars[rand.Intn(len(chars))])
	}
	return block.String()
}

//get userID from pic users
func GetPicUsers(client *slack.Client) ([]string, error) {

	var userIds []string
	godotenv.Load(".env")

	users := os.Getenv("PIC_USER")

	//remove all space
	users = strings.ReplaceAll(users, " ", "")

	picUsers := strings.Split(users, ",")

	if len(picUsers) == 0 {
		return nil, errors.New("pic is empty")
	}

	for i := 0; i < len(picUsers); i++ {
		user, err := client.GetUserByEmail(picUsers[i])

		if err != nil {
			log.Println("Could not get user " + picUsers[i])
			return nil, errors.New("could not get user " + picUsers[i])
		}

		userIds = append(userIds, "<@"+user.ID+">")
	}

	return userIds, nil
}

func CreateAttachmentOnlyShow(callbackID string, preText string, text string, nameActionBtn string, valueAction string) (slack.Attachment, error) {
	attachment := slack.Attachment{}

	attachment = slack.Attachment{
		CallbackID: callbackID,
		Fallback:   callbackID,
		Color:      "#2484BE",
		Pretext:    preText,
		Text:       text,
		Actions: []slack.AttachmentAction{
			slack.AttachmentAction{
				Name:  nameActionBtn,
				Text:  "Show",
				Style: "primary",
				Type:  "button",
				Value: valueAction,
			},
			slack.AttachmentAction{
				Name:  "cancel_action",
				Text:  "Cancel",
				Style: "danger",
				Type:  "button",
				Value: "cancel",
				Confirm: &slack.ConfirmationField{
					Title:  "Confirm",
					Text:   "Are you sure to cancel? \n",
					OkText: "Yessssss",
				},
			},
		},

		MarkdownIn: []string{"text"},
	}

	return attachment, nil
}

func CreateAttachment(callbackID string, preText string, text string, nameActionBtn string, valueAction string) (slack.Attachment, error) {
	attachment := slack.Attachment{}

	attachment = slack.Attachment{
		CallbackID: callbackID,
		Fallback:   callbackID,
		Color:      "#2484BE",
		Pretext:    preText,
		Text:       text,
		Actions: []slack.AttachmentAction{
			slack.AttachmentAction{
				Name:  nameActionBtn,
				Text:  "Approve",
				Style: "primary",
				Type:  "button",
				Value: valueAction,
				Confirm: &slack.ConfirmationField{
					Title:  "Confirm",
					Text:   "Are you sure to approve this? \n",
					OkText: "Approve",
				},
			},
			slack.AttachmentAction{
				Name:  "cancel_action",
				Text:  "Cancel",
				Style: "danger",
				Type:  "button",
				Value: "cancel",
				Confirm: &slack.ConfirmationField{
					Title:  "Confirm",
					Text:   "Are you sure to cancel? \n",
					OkText: "Yes",
				},
			},
		},

		MarkdownIn: []string{"text"},
	}

	// // Create the Accessory that will be included in the Block and add the checkbox to it
	// accessory := slack.NewAccessory(checkbox)
	// // Add Blocks to the attachment
	// attachment.Blocks = slack.Blocks{
	// 	BlockSet: []slack.Block{
	// 		// Create a new section block element and add some text and the accessory to it
	// 		slack.NewSectionBlock(
	// 			&slack.TextBlockObject{
	// 				Type: slack.MarkdownType,
	// 				Text: "Did you think this article was helpful?",
	// 			},
	// 			nil,
	// 			accessory,
	// 		),
	// 	},
	// }

	// attachment.Text = "Rate the tutorial"
	// attachment.Color = "#4af030"

	return attachment, nil
}

func RemoveDuplicateValues(stringSlice []string) []string {
	keys := make(map[string]bool)
	list := []string{}

	// If the key(values of the slice) is not equal
	// to the already present value in new slice (list)
	// then we append it. else we jump on another element.
	for _, entry := range stringSlice {
		if _, value := keys[entry]; !value {
			keys[entry] = true
			list = append(list, entry)
		}
	}
	return list
}

func IsEmpty(input string) bool {
	if input == "" {
		return true
	} else {
		return false
	}
}

func GetPasswordInputData(blockAc map[string]map[string]slack.BlockAction) (string, error) {
	var output string
	length := blockAc["random_password"]["pwd_length"].SelectedOption.Value

	specialChar := blockAc["random_password"]["special_character"].SelectedOption.Value

	numbers := blockAc["random_password"]["number_count"].SelectedOption.Value

	upperCase := blockAc["random_password"]["upperCase"].SelectedOption.Value

	lengthToNum, err := strconv.Atoi(length)

	if err != nil {
		return output, err
	}

	specialCharToNum, err := strconv.Atoi(specialChar)

	if err != nil {
		return output, err
	}

	numbersToNum, err := strconv.Atoi(numbers)

	if err != nil {
		return output, err
	}

	upperCaseToNum, err := strconv.Atoi(upperCase)

	if err != nil {
		return output, err
	}

	if lengthToNum < (specialCharToNum + numbersToNum + upperCaseToNum) {
		return "", errors.New("input is wronggggg!!!!")
	}

	output = GeneratePassword(lengthToNum, specialCharToNum, numbersToNum, upperCaseToNum)
	return output, nil
}

//split string to N part
func SplitSubN(s string) []string {
	sub := ""
	subs := []string{}

	runes := bytes.Runes([]byte(s))
	l := len(runes)

	max := l - 21
	for i, r := range runes {

		if i > 15 && i < max {
			continue

		} else if i == 15 {
			subs = append(subs, sub)
			sub = ""

		} else {
			sub = sub + string(r)
		}

		if i == l-1 {
			subs = append(subs, sub)
		}

	}

	return subs
}

// https://play.golang.org/p/Qg_uv_inCek
// contains checks if a string is present in a slice
func Contains(s []string, str string) bool {
	for _, v := range s {
		if v == str {
			return true
		}
	}

	return false
}
func GeneratePassword(passwordLength, minSpecialChar, minNum, minUpperCase int) string {
	var password strings.Builder

	//Set special character
	for i := 0; i < minSpecialChar; i++ {
		random := rand.Intn(len(specialCharSet))
		password.WriteString(string(specialCharSet[random]))
	}

	//Set numeric
	for i := 0; i < minNum; i++ {
		random := rand.Intn(len(numberSet))
		password.WriteString(string(numberSet[random]))
	}

	//Set uppercase
	for i := 0; i < minUpperCase; i++ {
		random := rand.Intn(len(upperCharSet))
		password.WriteString(string(upperCharSet[random]))
	}

	remainingLength := passwordLength - minSpecialChar - minNum - minUpperCase
	for i := 0; i < remainingLength; i++ {
		random := rand.Intn(len(lowerCharSet))
		password.WriteString(string(lowerCharSet[random]))
	}
	inRune := []rune(password.String())
	rand.Shuffle(len(inRune), func(i, j int) {
		inRune[i], inRune[j] = inRune[j], inRune[i]
	})
	return string(inRune)
}
