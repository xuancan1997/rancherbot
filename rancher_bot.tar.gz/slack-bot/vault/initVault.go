package vault

import (
	"log"
	"os"
	"slack-bot/common"

	vault "github.com/hashicorp/vault/api"
)

const (
	// authVaultAddr  = "https://vault.infra.tiki.services"
	// authVaultPath  = "k8s-prod-infras-v2"
	// authVaultRole  = "rancher-bot"
	authTokenPath  = "rancher-api/dns-api-token"
	apiConfigPath  = "rancher-api/dns-api-config"
	pgConnEnvName  = "PG_CONN_STRING"
	giphyTokenName = "GIPHY_TOKEN"
)

// GateKeeper works as a secret handler which writes/reads
// secrets from Vault
type GateKeeper struct {
	V     *vault.Client
	path  string
	token string
}

func NewGateKeeper() (*GateKeeper, error) {

	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")
	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)
	if err != nil {
		log.Println(err)
	}
	return &GateKeeper{V: v, path: authTokenPath, token: common.RandString(48)}, err
}

// WriteSecret writes API token to vault
func (g GateKeeper) WriteSecret() string {

	data := map[string]interface{}{"token": g.token}
	_, err := g.V.Logical().Write(g.path, data)
	if err != nil {
		log.Fatal(err)
	}
	return g.token
}

// ReadApiConfig reads API config from Vault
func (g GateKeeper) ReadApiConfig() {

	config, err := g.V.Logical().Read(apiConfigPath)
	if err != nil {
		log.Fatal(err)
	}
	err = os.Setenv(pgConnEnvName, config.Data[pgConnEnvName].(string))
	if err != nil {
		log.Fatal(err)
	}
	err = os.Setenv(giphyTokenName, config.Data[giphyTokenName].(string))
	if err != nil {
		log.Fatal(err)
	}

}
