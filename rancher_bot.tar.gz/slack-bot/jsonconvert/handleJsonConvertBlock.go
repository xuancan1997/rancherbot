package jsonconvert

import (
	"slack-bot/common"

	"github.com/slack-go/slack"
)

func GetJsonConverterBlock() (slack.MsgOption, error) {

	var block slack.MsgOption
	headerGitText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerGitSection := slack.NewSectionBlock(headerGitText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("input", "Enter text need convert to json:", "Example:\na=b\nbccc:cssss\nd:e")
	addUserButton := common.GetAprroveBtn("submit_json_convert_btn")

	//fmt.Println(ognTeams)

	block = slack.MsgOptionBlocks(
		headerGitSection,
		inputBlock,
		addUserButton,
	)

	return block, nil
}
