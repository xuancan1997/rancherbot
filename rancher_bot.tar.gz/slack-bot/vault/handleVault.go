package vault

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"slack-bot/common"
	"slack-bot/rancher"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
)

// var httpClient = &http.Client{
// 	Transport: &http.Transport{
// 		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
// 	},
// }

func CreateNewVaultForKeyDB(client *slack.Client, input, channel, timeStamp string) error {
	splitInput := strings.Split(input, " ")

	if len(splitInput) != 4 {
		return errors.New("format create keydb vault not correct, please check")
	}

	vaultPath := splitInput[3]

	splitVaultPath := strings.Split(vaultPath, "/")

	if len(splitVaultPath) != 3 {
		return errors.New("vault path not correct, please check")
	}

	cluster := splitVaultPath[0]
	namespace := splitVaultPath[1]
	keydbName := splitVaultPath[2]

	var err error
	err = createNewKeyDBVault(cluster, namespace, keydbName)

	if err != nil {
		return err
	}

	item := slack.ItemRef{
		Channel:   channel,
		Timestamp: timeStamp,
	}
	err = client.AddReaction("nhang", item)
	if err != nil {
		log.Println(err)
	}
	client.PostMessage(channel, slack.MsgOptionTS(timeStamp), slack.MsgOptionText("`Create vault success, path created: "+cluster+"/"+namespace+"/secrets/"+keydbName+"`", false))
	return nil
}

func ShowSelfUserCreatedVaultValue(client *slack.Client, userID, ts, data string) error {

	dataSplit := strings.SplitN(data, " ", 4)

	deployment := dataSplit[1]
	secretName := dataSplit[2]
	vaultData := dataSplit[3]

	vaultDataConvert := strings.ReplaceAll(vaultData, "NEWLINE", "\n")

	output, _, err := HandleDeploymentVaultCheckValue(deployment, vaultDataConvert, secretName)

	if err != nil {
		return err
	}
	attachment := slack.Attachment{}

	attachment.Pretext = "Data vault after updated, this msg will delete after 10 seconds\n"
	attachment.Color = "#03fcdb"
	attachment.Text = output
	_, ts, _, err = client.UpdateMessage(userID, ts, slack.MsgOptionAttachments(attachment))

	if err != nil {

		log.Println(err)
		return err
	}

	//delete msg after 5 seconds
	time.Sleep(10 * time.Second)
	client.DeleteMessage(userID, ts)
	return nil
}

func SendDataConfirmedToCreateVault(client *slack.Client, data string) (string, string, string, string, string, error) {

	dataSplit := strings.SplitN(data, " ", 5)

	userId := dataSplit[0]
	deployment := dataSplit[1]
	secretName := dataSplit[2]
	jiraTicketURL := dataSplit[3]
	vaultData := dataSplit[4]

	vaultDataConvert := strings.ReplaceAll(vaultData, "NEWLINE", "\n")
	// log.Println(userId)
	// log.Println(deployment)
	// log.Println(secretName)
	// log.Println(vaultData)

	_, addMsg, vaultURL, err := HandleDeploymentVaultCreate(deployment, vaultDataConvert, secretName)

	if err != nil {
		return addMsg, userId, jiraTicketURL, vaultData, vaultURL, err
	}

	return addMsg, userId, jiraTicketURL, vaultData, vaultURL, nil
}

func SendApproveSelfCreateVault(client *slack.Client, dataInput, secretNameInput, vaultDataInput, jiraTicketURL string) error {

	dataSplit := strings.Split(dataInput, " ")
	deployment := dataSplit[0]
	user, err := client.GetUserInfo(dataSplit[1])
	if err != nil {
		return err
	}

	if secretNameInput == "" {
		secretNameInput = deployment
	}

	if strings.Contains(vaultDataInput, "\\n") {
		return errors.New("not support multi lines vault yet")
	}

	attachment, err := common.CreateAttachment("approve_user_self_create_vault", "<!subteam^SVALNFK27> User `"+user.Name+"` has submit request to create vault for deployment `"+deployment+"`", "Secret name: `"+secretNameInput+"`\n"+"Vault data:\n```"+vaultDataInput+"```",
		"approve_selft_create_vault", user.ID+" "+deployment+" "+secretNameInput+" "+jiraTicketURL+" "+strings.ReplaceAll(vaultDataInput, "\n", "NEWLINE"))

	if err != nil {
		return err
	}

	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))
	return nil
}

func ShowSelfUserUpdatedVaultValue(client *slack.Client, userID, ts, data string) error {

	//log.Printf(data)
	dataSplit := strings.SplitN(data, " ", 5)

	deployment := dataSplit[1]
	secretName := dataSplit[2]
	vaultData := dataSplit[4]

	vaultDataConvert := strings.ReplaceAll(vaultData, "NEWLINE", "\n")

	output, _, err := HandleDeploymentVaultCheckValue(deployment, vaultDataConvert, secretName)

	if err != nil {
		return err
	}

	attachment := slack.Attachment{}

	attachment.Pretext = "Data vault after updated, this msg will delete after 10 seconds.\n"
	attachment.Color = "#03fcdb"
	attachment.Text = output
	_, ts, _, err = client.UpdateMessage(userID, ts, slack.MsgOptionAttachments(attachment))

	if err != nil {

		log.Println(err)
		return err
	}

	//delete msg after 5 seconds
	time.Sleep(10 * time.Second)
	client.DeleteMessage(userID, ts)
	return nil
}

func SendDataConfirmedToUpdateVault(client *slack.Client, data string) (string, string, string, string, string, error) {

	dataSplit := strings.SplitN(data, " ", 5)

	userId := dataSplit[0]
	deployment := dataSplit[1]
	secretName := dataSplit[2]
	jiraTicket := dataSplit[3]
	vaultData := dataSplit[4]

	vaultDataConvert := strings.ReplaceAll(vaultData, "NEWLINE", "\n")
	// log.Println(userId)
	// log.Println(deployment)
	// log.Println(secretName)
	// log.Println(vaultData)

	addMsg, urlVault, err := HandleDeploymentVaultUpdateValue(deployment, vaultDataConvert, secretName)

	if err != nil {
		return addMsg, userId, jiraTicket, vaultData, urlVault, err
	}

	return addMsg, userId, jiraTicket, vaultData, urlVault, nil
}

func SendApproveSelfUpdateVault(client *slack.Client, dataInput, secretNameInput, vaultDataInput, jiraTicketURL string) error {

	dataSplit := strings.Split(dataInput, " ")
	deployment := dataSplit[0]
	user, err := client.GetUserInfo(dataSplit[1])
	if err != nil {
		return err
	}

	if secretNameInput == "" {
		secretNameInput = deployment
	}

	if strings.Contains(vaultDataInput, "\\n") {
		return errors.New("not support multi lines vault yet")
	}

	attachment, err := common.CreateAttachment("approve_user_self_update_vault", "<!subteam^SVALNFK27> User `"+user.Name+"` has submit request to update vault for deployment `"+deployment+"`", "Secret name: `"+secretNameInput+"`\n"+"Vault data:\n```"+vaultDataInput+"```\nJira ticket is "+jiraTicketURL,
		"approve_self_update_vault", user.ID+" "+deployment+" "+secretNameInput+" "+jiraTicketURL+" "+strings.ReplaceAll(vaultDataInput, "\n", "NEWLINE"))

	if err != nil {
		return err
	}

	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))
	return nil
}

func HandleDeploymentVaultCreate(deploymentInput, vaultDataInput, secretNameInput string) (string, string, string, error) {

	secretNameInput = strings.TrimSpace(secretNameInput)
	deployment, err := rancher.GetDeploymentWithDeploymentName(deploymentInput)

	if err != nil {
		if strings.Contains(err.Error(), "deployment not found") {
			err = rancher.HandleDeploymentUpdateLocalFile()

			if err != nil {
				return "", "", "", err
			}

			deployment, err = rancher.GetDeploymentWithDeploymentName(deploymentInput)
			if err != nil {
				return "", "", "", err
			}
		} else {
			return "", "", "", err
		}
	}

	_, envRancher, err := rancher.GetRancherContainers(deployment)

	if err != nil {
		return "", "", "", err
	}

	strimInput := strings.Trim(vaultDataInput, "'")
	strimInput = strings.Trim(strimInput, "\"")
	strimInput = strings.Trim(strimInput, ",")
	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return "", "", "", errors.New("Notthing to do!!!")

	}

	vaultSet := make(map[string]string)

	var duplicateRancherEnv []string
	for i, line := range lines {
		line = strings.Trim(line, ",")

		//log.Println("Current lines ", line)
		if line == "" {
			continue
		}

		if strings.Contains(line, "\\n") {
			return "", "", "", errors.New("not support multi lines vault yet")
		}

		isComment := strings.HasPrefix(line, "#")

		if isComment {
			continue
		}

		line = strings.TrimSpace(line)

		splitInput := strings.SplitN(line, "=", 2)

		if len(splitInput) == 1 {
			splitInput = strings.SplitN(line, ":", 2)
		}

		if len(splitInput) == 2 {
			key := splitInput[0]

			if len(key) > 0 {
				key = strings.TrimSpace(key)
				key = strings.Trim(key, "\"")
			}
			value := splitInput[1]

			if len(value) > 0 {
				value = strings.TrimSpace(value)
				value = strings.Trim(value, "\"")
			}

			if key == "" || value == "" {
				return "", "", "", errors.New("please check error with key: \n*`" + key + "`* has value: *`" + value + "`*" + " at line *" + strconv.Itoa(i+1) + "*")
			}

			//check rancher env is exist or not

			rancherValue := fmt.Sprintf("%v", envRancher[key])
			if rancherValue != "<nil>" {
				//log.Println("Current key ", key)
				//duplicateRancherEnv = append(duplicateRancherEnv, key+":"+rancherValue)
				duplicateRancherEnv = append(duplicateRancherEnv, key)
			}

			vaultSet[key] = value

		} else {
			return "", "", "", errors.New("Currently, not support this type yet!!! :yaoming:")
		}
	}

	//log.Println("Vault data length ", vaultSet)
	if len(vaultSet) == 0 {
		return "", "", "", errors.New("Vault data is empty")
	}
	var addMsg string
	//if found key value in rancher, print error
	if len(duplicateRancherEnv) > 0 {
		log.Println("env length", len(duplicateRancherEnv))
		addMsg = "```found these keys in rancher: " + strings.Join(duplicateRancherEnv, "\n ") + "```"
	}

	//check if deployment has mount secret
	var secretVault string

	if secretNameInput != "" {
		secretVault = secretNameInput
	} else {
		secretVault = "env-" + deployment.Name
	}

	reponse, mountPoint, err := createVault(vaultSet, deployment, secretVault)

	vaultAddr := os.Getenv("AUTH_VAULT_ADDR")

	//https://vault.infra.tiki.services/ui/vault/secrets/kv/show/k8s/k8s-app-platform-prod/default/workloads/mlem/environments
	//https://vault.infra.tiki.services/ui/vault/secrets/kv/list/k8s/k8s-app-platform-prod/default/workloads/mlem/environments
	vaultURL := vaultAddr + strings.Replace(mountPoint, "/v1/kv/data", "/ui/vault/secrets/kv/show", 1)
	if err != nil && addMsg == "" {
		log.Println(err)
		return "", "", "", err
	} else if err != nil && addMsg != "" {
		return "", addMsg, vaultURL, nil
	}

	return reponse, addMsg, vaultURL, nil
}

func HandleDeploymentSearchVault(deploymentInput, patternSearch, secretNameInput string) (string, string, error) {
	var output string
	var key string
	secretNameInput = strings.TrimSpace(secretNameInput)
	deployment, err := rancher.GetDeploymentWithDeploymentName(deploymentInput)

	if err != nil {
		if strings.Contains(err.Error(), "deployment not found") {
			err = rancher.HandleDeploymentUpdateLocalFile()

			if err != nil {
				return "", "", err
			}

			deployment, err = rancher.GetDeploymentWithDeploymentName(deploymentInput)
			if err != nil {
				return "", "", err
			}
		} else {
			return "", "", err
		}
	}

	output, key, err = searchVault(patternSearch, deployment, secretNameInput)

	if err != nil {
		return "", "", err
	}
	return output, key, nil
}

func HandleDeploymentVaultCheckValue(deploymentInput, vaultDataInput, secretNameInput string) (string, string, error) {

	secretNameInput = strings.TrimSpace(secretNameInput)
	deployment, err := rancher.GetDeploymentWithDeploymentName(deploymentInput)

	if err != nil {
		if strings.Contains(err.Error(), "deployment not found") {
			err = rancher.HandleDeploymentUpdateLocalFile()

			if err != nil {
				return "", "", err
			}

			deployment, err = rancher.GetDeploymentWithDeploymentName(deploymentInput)
			if err != nil {
				return "", "", err
			}
		} else {
			return "", "", err
		}
	}

	containerData, envRancher, err := rancher.GetRancherContainers(deployment)

	if err != nil {
		return "", "", err
	}

	//log.Println(containerData)

	//now need to create map with key-value to find if vault is contain in rancher or not

	// envSet := make(map[string]string)

	// log.Println("ENV ", envRancher)
	// for _, rancherEnv := range containerData.ENVFROM {
	// 	envSet[rancherEnv.SourceName] = rancherEnv.SourceName
	// }

	strimInput := strings.Trim(vaultDataInput, "'")
	strimInput = strings.Trim(strimInput, "\"")
	strimInput = strings.Trim(strimInput, ",")
	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return "", "", errors.New("Notthing to do!!!")

	}

	vaultSet := make(map[string]string)

	var duplicateRancherEnv []string
	for _, line := range lines {
		line = strings.Trim(line, ",")

		//log.Println("Current lines ", line)
		if line == "" {
			continue
		}

		if strings.Contains(line, "\\n") {
			return "", "", errors.New("Not support multi lines vault yet")
		}

		isComment := strings.HasPrefix(line, "#")

		if isComment {
			continue
		}

		line = strings.TrimSpace(line)

		splitted := false

		//if line is a=b
		if strings.Contains(line, "=") {
			splitted = true
			line = strings.SplitN(line, "=", 2)[0]

			if strings.Contains(line, ":") {
				line = strings.SplitN(line, ":", 2)[0]
			}
		}

		//if line is a:b
		if strings.Contains(line, ":") && !splitted {
			line = strings.SplitN(line, ":", 2)[0]
		}

		//if line is a:b=

		//remove double quote
		line = strings.Trim(line, "\"")

		rancherValue := fmt.Sprintf("%v", envRancher[line])
		log.Println("Key vault is ", line)
		//log.Println(rancherValue)
		if rancherValue != "<nil>" {
			log.Println("Current key ", line)
			//duplicateRancherEnv = append(duplicateRancherEnv, line+":"+rancherValue)
			duplicateRancherEnv = append(duplicateRancherEnv, line)
		}
		// if envRancher[line] != "" || envRancher[line] == "<nil>" {
		// 	log.Println("Env rancher found value is: ", envRancher[line])
		// 	log.Println("Current key ", line)
		// 	duplicateRancherEnv = append(duplicateRancherEnv, line)
		// }

		vaultSet[line] = "-1"

	}

	var addMsg string
	//if found key value in rancher, print error
	if len(duplicateRancherEnv) > 0 {
		log.Println("env length", len(duplicateRancherEnv))
		addMsg = "found these keys in rancher: *```\n" + strings.Join(duplicateRancherEnv, "\n") + "```*"
	}

	//check if deployment has mount secret
	var secretVault string

	if len(containerData.ENVFROM) == 0 {
		return "", "", errors.New("this deployment has not defined mount-secret yet!\nVault data might created but deployment need to add this secrets to tikici")
	}

	for _, secretRef := range containerData.ENVFROM {

		if secretRef.SECRETREF.Name == secretNameInput {
			secretVault = secretNameInput
		}
		if strings.Contains(secretRef.SECRETREF.Name, deployment.Name) && secretNameInput == "" {
			secretVault = secretRef.SECRETREF.Name
		}
	}

	// log.Println(containerData)
	// secretVault = "mlem"
	if secretVault == "" {
		return "", addMsg, errors.New("cannot find secret " + secretNameInput)
	}

	//log.Println(vaultSet, deployment, secretVault)
	reponse, err := checkVault(vaultSet, deployment, secretVault)

	if err != nil && addMsg == "" {
		log.Println(err)
		return "", "", err
	} else if err != nil && addMsg != "" {
		return "", addMsg, nil
	}

	return reponse, addMsg, nil
}

func createVault(vaultDataInput map[string]string, rancherData rancher.Data, secretVault string) (string, string, error) {
	//log.Println("mount secret and deployment ", secretVault, rancherData)

	mountPoint := "/v1/kv/data/k8s/"

	if strings.HasPrefix(secretVault, "env-") {
		mountPoint += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/workloads/" + strings.SplitN(secretVault, "-", 2)[1] + "/environments"
	} else {
		mountPoint += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/secrets/" + secretVault
	}

	log.Println("mount point", mountPoint)

	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")
	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)

	isFalse := false
	if err != nil {
		isFalse = true
		log.Println(err)
	}

	token := ""
	//for test from local
	if isFalse {
		godotenv.Load(".env")
		token = os.Getenv("VAULT_TOKEN")
	} else {
		token = v.Token()
	}

	//log.Println("Current token: ", token)

	if token == "" {
		return "", "", errors.New("cannot get vault token")
	}

	//testing
	//mountPointSec = "/v1/rancher-bot/data/foo"

	_, statusCodeQuery, err := querryToVault(token, mountPoint)

	if err != nil && statusCodeQuery == 200 {
		log.Println(err)
		return "", "", err
	}

	if statusCodeQuery == 200 {
		return "", "", errors.New("This vault has already defined")
	}

	newVault := make(map[string]interface{}, len(vaultDataInput))
	for k, v := range vaultDataInput {
		output := common.ConvertToUnicode(v)
		newVault[k] = output
	}

	statusCode, err := sendUpdateToVault(token, mountPoint, newVault)

	if err != nil {
		log.Println(err)
		return "", "", err
	}

	if statusCode != 200 {
		return "", "", errors.New("status code " + strconv.Itoa(statusCode) + " when create vault")
	}
	log.Println("Create vault success")

	return "Create vault success", mountPoint, nil
}

func searchVault(patternSearch string, rancherData rancher.Data, secretVault string) (string, string, error) {
	var output []string
	var keys []string
	mountPoint := "/v1/kv/data/k8s/"
	mountPointSec := mountPoint

	if strings.HasPrefix(secretVault, "env-") {
		mountPoint += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/workloads/" + strings.SplitN(secretVault, "-", 2)[1] + "/environments"
	}
	mountPointSec += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/secrets/" + secretVault

	log.Println("mount point", mountPoint)
	log.Println("mount point Sec", mountPointSec)
	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")
	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)

	isFalse := false
	if err != nil {
		isFalse = true
		log.Println(err)
	}

	token := ""
	//for test from local
	if isFalse {
		godotenv.Load(".env")
		token = os.Getenv("VAULT_TOKEN")
	} else {
		token = v.Token()
	}

	//log.Println("Current token: ", token)

	if token == "" {
		return "", "", errors.New("cannot get vault token")
	}

	//testing
	//mountPointSec = "/v1/rancher-bot/data/foo"

	currentVault, statusCodeQuery, err := querryToVault(token, mountPointSec)

	if statusCodeQuery == 404 {
		currentVault, statusCodeQuery, err = querryToVault(token, mountPoint)
		mountPointSec = mountPoint
	}

	if err != nil {
		log.Println(err)
		return "", "", err
	}

	for key := range currentVault {
		value := fmt.Sprintf("%v", currentVault[key])
		keyStr := fmt.Sprintf("%v", key)
		if strings.Contains(keyStr, patternSearch) {
			output = append(output, keyStr+"="+value)
			keys = append(keys, keyStr)
		}
	}

	if len(output) == 0 {
		return "", "", errors.New("not match any vault data with key " + patternSearch)
	}

	if len(output) > 20 {
		return "", "", errors.New("question is too generic")
	}

	return strings.Join(output, "\n"), strings.Join(keys, "\n"), nil
}

func checkVault(vaultDataInput map[string]string, rancherData rancher.Data, secretVault string) (string, error) {
	//log.Println("mount secret and deployment ", secretVault, rancherData)

	var output []string
	mountPoint := "/v1/kv/data/k8s/"
	mountPointSec := mountPoint

	if strings.HasPrefix(secretVault, "env-") {
		mountPoint += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/workloads/" + strings.SplitN(secretVault, "-", 2)[1] + "/environments"
	}
	mountPointSec += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/secrets/" + secretVault

	log.Println("mount point", mountPoint)
	log.Println("mount point Sec", mountPointSec)
	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")
	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)

	isFalse := false
	if err != nil {
		isFalse = true
		log.Println(err)
	}

	token := ""
	//for test from local
	if isFalse {
		godotenv.Load(".env")
		token = os.Getenv("VAULT_TOKEN")
	} else {
		token = v.Token()
	}

	//log.Println("Current token: ", token)

	if token == "" {
		return "", errors.New("cannot get vault token")
	}

	//testing
	//mountPointSec = "/v1/rancher-bot/data/foo"

	currentVault, statusCodeQuery, err := querryToVault(token, mountPointSec)

	if statusCodeQuery == 404 {
		currentVault, statusCodeQuery, err = querryToVault(token, mountPoint)
		mountPointSec = mountPoint
	}

	if err != nil {
		log.Println(err)
		return "", err
	}

	for key := range vaultDataInput {

		value := fmt.Sprintf("%v", currentVault[key])
		if value == "" || value == "<nil>" {
			continue
		}
		data := "```" + key + "=" + value + "```"
		output = append(output, data)
	}

	// for key := range currentVault {
	// 	value := fmt.Sprintf("%v", currentVault[key])
	// 	keyStr := fmt.Sprintf("%v", key)
	// 	if strings.Contains(keyStr, )
	// }

	if len(output) == 0 {
		return "", errors.New("not match any vault data")
	}
	return strings.Join(output, "\n"), nil
}

func HandleDeploymentVaultUpdateValue(deploymentInput, vaultDataInput, secretNameInput string) (string, string, error) {

	secretNameInput = strings.TrimSpace(secretNameInput)
	deployment, err := rancher.GetDeploymentWithDeploymentName(deploymentInput)

	if err != nil {
		if strings.Contains(err.Error(), "deployment not found") {
			err = rancher.HandleDeploymentUpdateLocalFile()

			if err != nil {
				return "", "", err
			}

			deployment, err = rancher.GetDeploymentWithDeploymentName(deploymentInput)
			if err != nil {
				return "", "", err
			}
		} else {
			return "", "", err
		}
	}

	containerData, envRancher, err := rancher.GetRancherContainers(deployment)

	if err != nil {
		return "", "", err
	}

	//log.Println(containerData)

	//now need to create map with key-value to find if vault is contain in rancher or not

	// envSet := make(map[string]string)
	// for _, rancherEnv := range containerData.ENVFROM {
	// 	envSet[rancherEnv.SourceName] = rancherEnv.SourceName
	// }

	strimInput := strings.Trim(vaultDataInput, "'")
	strimInput = strings.Trim(strimInput, "\"")
	strimInput = strings.Trim(strimInput, ",")
	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return "", "", errors.New("notthing to do!!!")

	}

	vaultSet := make(map[string]string)

	var duplicateRancherEnv []string
	for i, line := range lines {
		line = strings.Trim(line, ",")

		//log.Println("Current lines ", line)
		if line == "" {
			continue
		}

		if strings.Contains(line, "\\n") {
			return "", "", errors.New("not support multi lines vault yet")
		}

		isComment := strings.HasPrefix(line, "#")

		if isComment {
			continue
		}

		line = strings.TrimSpace(line)

		splitInput := strings.SplitN(line, "=", 2)

		if len(splitInput) == 1 || strings.Contains(splitInput[0], ":") {
			splitInput = strings.SplitN(line, ":", 2)
		}

		if len(splitInput) == 2 {
			key := splitInput[0]

			if len(key) > 0 {
				key = strings.TrimSpace(key)
				key = strings.Trim(key, "\"")
			}
			value := splitInput[1]

			if len(value) > 0 {
				value = strings.TrimSpace(value)
				value = strings.Trim(value, "\"")
			}

			if key == "" || value == "" {
				return "", "", errors.New("please check error with key: \n*`" + key + "`* has value: *`" + value + "`*" + " at line *" + strconv.Itoa(i+1) + "*")
			}

			//check rancher env is exist or not

			rancherValue := fmt.Sprintf("%v", envRancher[key])
			if rancherValue != "<nil>" {
				//log.Println("Current key ", key)
				//duplicateRancherEnv = append(duplicateRancherEnv, key+":"+rancherValue)
				duplicateRancherEnv = append(duplicateRancherEnv, key)
			}

			vaultSet[key] = value

		} else {
			return "", "", errors.New("Currently, not support this type yet!!! :yaoming:")
		}
	}

	//check if deployment has mount secret
	var secretVault string

	if len(containerData.ENVFROM) == 0 {
		return "", "", errors.New("this deployment has not defined mount-secret yet, you need to add secret to tikici first!!!")
	}

	for _, secretRef := range containerData.ENVFROM {

		if secretRef.SECRETREF.Name == secretNameInput {
			secretVault = secretNameInput
		}
		if strings.Contains(secretRef.SECRETREF.Name, deployment.Name) && secretNameInput == "" {
			secretVault = secretRef.SECRETREF.Name
		}
	}

	// log.Println(containerData)
	// secretVault = "mlem"
	if secretVault == "" {
		return "", "", errors.New("cannot find secret " + secretNameInput)
	}
	errorCode, mountSecret, err := updateToVault(vaultSet, deployment, secretVault)

	if err != nil {
		log.Println(err)
		return "", "", err
	}

	if errorCode != 200 {
		return "", "", errors.New("error code when updating vault, status code " + strconv.Itoa(errorCode))
	}

	vaultAddr := os.Getenv("AUTH_VAULT_ADDR")

	mountSecret = vaultAddr + strings.Replace(mountSecret, "/v1/kv/data", "/ui/vault/secrets/kv/show", 1)
	//if found key value in rancher, print warning
	if len(duplicateRancherEnv) > 0 {
		//log.Println("env length", len(duplicateRancherEnv))
		return "```Warning:\nfound these keys in rancher: \n" + strings.Join(duplicateRancherEnv, "\n") + "```", mountSecret, nil
	}

	return "", mountSecret, nil
}

func updateToVault(vaultDataInput map[string]string, rancherData rancher.Data, secretVault string) (int, string, error) {

	log.Println("mount secret and deployment ", secretVault, rancherData)

	mountPoint := "/v1/kv/data/k8s/"
	mountPointSec := mountPoint

	if strings.HasPrefix(secretVault, "env-") {
		mountPoint += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/workloads/" + strings.SplitN(secretVault, "-", 2)[1] + "/environments"
	}
	mountPointSec += rancherData.ClusterName + "/" + rancherData.NamespaceId + "/secrets/" + secretVault

	log.Println("mount point", mountPoint)
	log.Println("mount point Sec", mountPointSec)
	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")
	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)

	isFalse := false
	if err != nil {
		isFalse = true
		log.Println(err)
	}

	token := ""
	//for test from local
	if isFalse {
		godotenv.Load(".env")
		token = os.Getenv("VAULT_TOKEN")
	} else {
		token = v.Token()
	}

	//log.Println("Current token: ", token)

	if token == "" {
		return 0, "", errors.New("cannot get vault token")
	}

	//testing
	//mountPointSec = "/v1/rancher-bot/data/foo"

	currentVault, statusCodeQuery, err := querryToVault(token, mountPointSec)

	if statusCodeQuery == 404 && strings.HasPrefix(secretVault, "env-") {
		currentVault, statusCodeQuery, err = querryToVault(token, mountPoint)

		if err != nil {
			return 0, "", err
		}

		mountPointSec = mountPoint
	}

	if err != nil {
		log.Println(err)
		return 0, "", err
	}
	// log.Println("Vault res", vaultDataInput)

	// log.Println("Input vault ", currentVault)
	for key := range vaultDataInput {
		output := common.ConvertToUnicode(vaultDataInput[key])
		currentVault[key] = output
	}

	//log.Println("Update vault ", currentVault)

	statusCode, err := sendUpdateToVault(token, mountPointSec, currentVault)

	if err != nil {
		log.Println(err)
		return 0, "", err
	}

	if statusCode != 200 {
		return statusCode, "", nil
	}
	log.Println("Update vault success")

	return 200, mountPointSec, nil
}

func sendUpdateToVault(token, mountPoint string, vaultUpdate map[string]interface{}) (int, error) {

	data := make(map[string]interface{})
	data["data"] = vaultUpdate

	data["version"] = 0

	json_req, _ := json.Marshal(data)

	//log.Println(vaultUpdate)

	resp, err := initVaultHttpReq("POST", token, mountPoint, string(json_req))
	if err != nil {
		return 0, err
	}

	if resp.StatusCode != 200 {
		return 0, errors.New("error update vault with status code " + strconv.Itoa(resp.StatusCode))
	}

	return resp.StatusCode, err
}

func querryToVault(token, mountPoint string) (map[string]interface{}, int, error) {
	var vaultRes map[string]interface{}
	resp, err := initVaultHttpReq("GET", token, mountPoint, `{}`)

	if err != nil {
		return vaultRes, 0, err
	}
	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return vaultRes, 0, err
	}
	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)
	var result map[string]interface{}
	err = json.Unmarshal(body, &result)

	//log.Printf("Vault res %+v", vaultRes)
	if err != nil {
		return vaultRes, 0, err
	}

	//log.Println("Result ", result, resp.StatusCode)

	if resp.StatusCode != 200 {
		return vaultRes, resp.StatusCode, errors.New("vault data not found with error code " + strconv.Itoa(resp.StatusCode))
	}
	vaultData := result["data"].(map[string]interface{})

	vaultRes = vaultData["data"].(map[string]interface{})
	//log.Println("Result data", vaultRes)

	return vaultRes, 200, nil
}
