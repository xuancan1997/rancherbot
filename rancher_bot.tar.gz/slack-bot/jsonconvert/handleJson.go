package jsonconvert

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
)

func GetTextInputData(input, dataType string) (string, error) {

	//fmt.Println(input)

	strimInput := strings.ReplaceAll(input, "'", "")
	strimInput = strings.ReplaceAll(input, "\"", "")

	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return "", errors.New("Notthing to do!!!")

	}

	var output strings.Builder
	output.WriteString("{")
	output.WriteString("\n")

	for i, line := range lines {
		fmt.Println(i, line)

		if line == "" {
			continue
		}

		isComment := strings.HasPrefix(line, "#")

		if isComment {
			continue
		}

		splitInput := strings.SplitN(line, "=", 2)

		if len(splitInput) == 1 {
			splitInput = strings.SplitN(line, ":", 2)
		}

		if len(splitInput) == 2 {
			key := splitInput[0]

			if len(key) > 0 {
				key = removeHeaderAndTailBlankSpace(key)
			}
			value := splitInput[1]

			if dataType == "vault" {

				//log.Println("Value is: ", value)
				if strings.Contains(value, "\\n") {
					return "", errors.New("Currently, not support this type vault yet!!! :yaoming:")
				}
			}
			if len(value) > 0 {
				value = removeHeaderAndTailBlankSpace(value)
			}
			if key == "" || value == "" {
				return "", errors.New("please check error with key: *`" + key + "`* has value: *`" + value + "`*" + " at line *" + strconv.Itoa(i+1) + "*")
			}
			output.WriteString("\t\"" + key + "\"" + ":" + "\"" + value + "\"")
			output.WriteString(",\n")
		} else {
			return "", errors.New("Currently, not support this type yet!!! :yaoming:")
		}
	}
	output.WriteString("}")
	return output.String(), nil
}

func removeHeaderAndTailBlankSpace(input string) string {
	return strings.TrimSpace(input)
}
