package lib

import (
	"errors"
	"fmt"
	"log"
	"os"
	"regexp"
	"slack-bot/atlantis"
	"slack-bot/common"
	"slack-bot/rancher"
	"slack-bot/vault"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/slack-go/slack/slackevents"
	"github.com/spf13/viper"
)

var managerList = map[string]bool{
	"son.pham":       true,
	"hoang.leminh1":  true,
	"hoa.nguyenmanh": true,
	"phuc.vo2":       true,
	"tuan.ho":        true,
	"khanh.phan1":    true,
	"tien.nguyen6":   true,
	"thanh.dao":      true,
	"sieu.vong":      true,
	"hoang.ho":       true,
	"giang.dinh":     true,
	"kham.dang":      true,
	"hung.vu":        true,
	"anh.nguyen42":   true,
	"trung.duong1":   true,
	"max.hoang":      true,
	"thang.dang":     true,
	"khoa.truong":    true,
	"hung.nguyen7":   true,
	"quan.nguyen2":   true,
	"huy.nguyen12":   true,
	"khai.huynh":     true,
	"huy.tran10":     true,
	"hien.pham2":     true,
	"tu.nguyen12":    true,
	"phong.dinh1":    true,
	"minh.ha1":       true,
	"vuong.tran":     true,
	"khang.tran1":    true,
	"nguyen.doan":    true,
	"bao.nguyenyen":  true,
	"thinh.tranquoc": true,
	"minh.on":        true,
	//"quy.vu1":        true,
	//"long.nguyen11":  true,
	//"viet.dam1":      true,
	//"xuan.can": true,
}

func updateManageWLToLocalFile(data string) error {
	godotenv.Load(".env")
	file_name := os.Getenv("MANAGE_PROFILE")
	path := os.Getenv("CONF_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {
		log.Println("file invalid, create new file", path+file_name)
		return errors.New("cannot get file, create new one")
	}

	dataSplit := strings.Split(data, " ")

	key := dataSplit[2] + "-" + dataSplit[4]
	value := dataSplit[0] + "|" + dataSplit[1] + "|" + dataSplit[8] + "|" + dataSplit[5]

	v.Set(key, value)

	v.WriteConfigAs(path + file_name)
	return nil
}

// func checkManager(userInput string) bool {

// }

func handleManageWLClicked(client *slack.Client, interaction slack.InteractionCallback, data, userNameGit, manager, description string) error {
	var headerSection *slack.SectionBlock
	if userNameGit == "" || description == "" {
		return errors.New("input cannot be empty!!!")
	}
	//if submit is manager

	isManager := false
	if manager == "" || interaction.User.Name == manager {

		if !managerList[interaction.User.Name] {
			return fmt.Errorf("you are not in leader list yet, please call systemoi to add")
		}
		//set manage as user
		manager = interaction.User.Name
		isManager = true
	}

	managerInfo, err := client.GetUserByEmail(manager + "@tiki.vn")

	if err != nil {
		return err
	}
	jiraTicket, err := atlantis.CreateTicketManageWL(managerInfo.Name, data, interaction.User.Name, description)

	if err != nil {
		return err
	}

	//handle if user is normal
	if managerInfo.Name != "" && !isManager {
		headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n```Your request has been sent to your manager, please wait for approving```",
			false,
			false)
		headerSection = slack.NewSectionBlock(headerText, nil, nil)
		err = handleManagerApprove(client, managerInfo, interaction.User.Name, strings.TrimSpace(data), userNameGit, jiraTicket, description)

		if err != nil {
			return err
		}
	}

	ts := interaction.Message.Timestamp

	//get jira ticket

	//jiraTicket := "test"

	if err != nil {
		return err
	}

	if isManager {
		headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n```Sending info to infra channel, please wait 5 seconds and then you can manage your workload```",
			false,
			false)
		headerSection = slack.NewSectionBlock(headerText, nil, nil)
	}

	middle := slack.NewTextBlockObject("mrkdwn", " Your jira ticket is: "+jiraTicket,
		false,
		false)
	midSection := slack.NewSectionBlock(middle, nil, nil)
	msg := slack.MsgOptionBlocks(
		headerSection,
		midSection,
	)
	_, _, _, err = client.UpdateMessage(interaction.Channel.ID, ts, msg)

	if err != nil {
		return err
	}

	time.Sleep(1 * time.Second)
	if managerInfo.Name == interaction.User.Name {
		INFRA_CHANNEL_ID := os.Getenv("INFRA_CHANNEL_ID")

		textSendToInfra := ""

		log.Println(data)
		dataSplit := strings.Split(data, " ")

		projectName := dataSplit[1]
		projectName = strings.ReplaceAll(projectName, "-", " ")

		if strings.HasPrefix(description, "Manage-Configmaps") {
			textSendToInfra = ".rancher grant " + dataSplit[0] + " | " + projectName + " | " + userNameGit + " | Tiki Manage Workloads Configmaps | " + dataSplit[3]
		} else {
			textSendToInfra = ".rancher grant " + dataSplit[0] + " | " + projectName + " | " + userNameGit + " | Tiki Developer (Manage workloads) | " + dataSplit[3]
		}

		log.Println(textSendToInfra)

		client.PostMessage(INFRA_CHANNEL_ID, slack.MsgOptionText(textSendToInfra, false))
		err = atlantis.CloseJiraTicket(jiraTicket)

		if err != nil {
			return err
		}

		//update to local file
		dataUpdate := data + " " + userNameGit + " empty empty " + managerInfo.Name
		err = updateManageWLToLocalFile(dataUpdate)

		if err != nil {
			return err
		}

	}
	return nil
}

func handleSystemReviewManageWL(client *slack.Client, interaction slack.InteractionCallback, data string) error {

	INFRA_CHANNEL_ID := os.Getenv("INFRA_CHANNEL_ID")

	textSendToInfra := ""

	dataSplit := strings.Split(data, " ")

	projectName := dataSplit[1]
	projectName = strings.ReplaceAll(projectName, "-", " ")

	description := dataSplit[7]

	if strings.HasPrefix(description, "Manage-Configmaps") {
		textSendToInfra = ".rancher grant " + dataSplit[0] + " | " + projectName + " | " + dataSplit[5] + " | Tiki Manage Workloads Configmaps | " + dataSplit[3]
	} else {
		textSendToInfra = ".rancher grant " + dataSplit[0] + " | " + projectName + " | " + dataSplit[5] + " | Tiki Developer (Manage workloads) | " + dataSplit[3]
	}

	log.Println(textSendToInfra)

	client.PostMessage(INFRA_CHANNEL_ID, slack.MsgOptionText(textSendToInfra, false))
	return nil
}

func handleManagerSendRequestToSystem(client *slack.Client, managerName, data string) error {

	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	dataSplit := strings.Split(data, " ")

	userRequest, err := client.GetUserInfo(dataSplit[2])

	// := "<!subteam^SVALNFK27>"
	if err != nil {
		return err
	}
	//update jira ticket

	err = atlantis.UpdateJiraTicket(managerName, dataSplit[6])

	if err != nil {
		return err
	}

	preText := "<!subteam^SVALNFK27> `" + userRequest.Name + "` has submit request to manage workload, approved by `" + managerName + "`"
	text := "\n" + "```Cluster: " + dataSplit[0] + "\nProject: " + dataSplit[1] +
		"\nTime manage workload: " + dataSplit[3] + " Hour" +
		"\nUsername gitHub: " + dataSplit[5] +
		"\nDescription: " + strings.ReplaceAll(dataSplit[7], "-", " ") + "```" +
		"\nIf you approve, this message will be sent to infra channel\nJira ticket is: " + dataSplit[6]
	attachment, err := common.CreateAttachment("manager_send_confirm_manage_wl", preText, text, "manager_send_confirm_manage_wl", data+" "+managerName)

	if err != nil {
		return err
	}

	client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))

	return nil
}

func handleManagerApprove(client *slack.Client, managerUser *slack.User, userRequestName, data, userNameGit, jiraURL, description string) error {

	preText := "Hello " + managerUser.Name + "\nYour member " + userRequestName + " has request to manage workload\nDescription: " + strings.ReplaceAll(description, "-", " ")
	dataSplit := strings.Split(data, " ")
	text := "\n" + "```Cluster: " + dataSplit[0] + "\nProject: " + dataSplit[1] +
		"\nTime manage workload: " + dataSplit[3] + " Hour```" +
		"\nIf you approve, jira ticket will be updated to resolved: " + jiraURL
	attachment, err := common.CreateAttachment("manager_approve_for_user", preText, text, "manager_approve_for_user", data+" "+userNameGit+" "+jiraURL+" "+description)

	if err != nil {
		return err
	}

	client.PostMessage(managerUser.ID, slack.MsgOptionAttachments(attachment))
	return nil
}

func handleRedeployStateful(client *slack.Client, event *slackevents.MessageEvent, eventType string) error {

	return nil
}

func handleSearchVault(client *slack.Client, event *slackevents.MessageEvent, dataInput, eventType string) error {
	msg, err := vault.SearchVaultMsgBlock(dataInput, event.User, eventType)

	if err != nil {
		sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
		return nil
	}

	client.PostMessage(event.Channel, slack.MsgOptionTS(event.TimeStamp), msg)
	return nil
}

func handleReplyBotMsg(client *slack.Client, event *slackevents.MessageEvent) error {

	var err error
	if event.Text == "help" {
		text := "Command supported:\n" +
			"*add deploy <deployment>*\nRequest system to add a deployment, example `add deploy bulma`\n" +
			"*redeploy <deployment>*\nRedeploy a deployment, example `redeploy bulma`\n" +
			"*update vault <deployment>*\nRequest to update a deployment vault, example `update vault bulma`\n" +
			//"*create vault <deployment>*\nRequest to create a deployment vault, example `create vault bulma`\n" +
			"*search vault <deployment>*\nRequest to search key of a deployment, example `search vault bulma`\n" +
			"*manage <deployment> <hour> -d <description>*\nManage workload, example `manage bulma 8 -d Debug`\nyou can use `-d Manage-Configmaps` to manage configmaps\n" +
			"*rollback <deployment>*\nrequest to rollback workload, example `rollback bulma`\n" +
			//"*set git user<repos example: `adduser git porsche,bmw,vinfast`*\n" +
			"*set <permission> to repo <repoName>*\naccess to repo, example: `set write to repo huyndai`\n" +
			"*new git repo <repoName>*\n create new repo, example: `new git repo bmw`\n" +
			"*set manager <managerSlack>*\nset your manager to get approver, example: `set manager phong.huynh`\n" +
			"*set git username <gitUsername>*\nset your git username to take action, example: `set git username xuancanTiki`"
		//"*gen file*\nRequest to get file from server`\n"
		sendEventResponse(client, event.Channel, event.EventTimeStamp, err, text, "post")
		return nil
	}

	text := event.Text
	for pattern, handler := range templateTextMsg {
		re := regexp.MustCompile(pattern)
		if match := re.FindStringSubmatch(text); match != nil {
			err := handler(match, event, client)

			if err != nil {
				client.PostMessage(event.User, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
				log.Println(err)

				return err
			}
		}
	}

	//rollback
	if strings.HasPrefix(event.Text, "rollback") {
		//data := event.Text
		//err := rancher.HandleRollbackMsg(event.User, data, client)

		msg, err := rancher.HandleRollbackMsg(event.Text)

		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		_, _, err = client.PostMessage(event.User, slack.MsgOptionTS(event.TimeStamp), msg)

		if err != nil {
			log.Println(err)
		}

		return nil
	}

	//redeploy app
	if strings.HasPrefix(event.Text, "redeploy") {
		data := event.Text
		err := rancher.HandleRedeployMsg(event.User, data, client)
		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		user, err := client.GetUserInfo(event.User)
		if err != nil {
			log.Println(err)
			return err
		}
		_, err = sendResponseToChannel(client, err, "<!subteam^SVALNFK27> User "+user.Name+" has "+event.Text, "redeploy-notification")

		if err != nil {
			log.Println(err)
			return err
		}
		return nil
	}

	//add permission to deploy app
	if strings.HasPrefix(event.Text, "add deploy ") {
		deploymentName, err := rancher.VerifyAddRedeployData(event.User, event.Text)
		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		err = sendApproveAddDeploy(client, event.User, deploymentName)

		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "Sent event to systemoi, please wait for approving...", "post")
	}

	//add vault ticket
	if strings.HasPrefix(event.Text, "update vault ") {
		msg, err := vault.HandleUserSelfUpdateVaultBlock(event.Text, event.User)

		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		client.PostMessage(event.User, slack.MsgOptionTS(event.TimeStamp), msg)
		return nil
	}

	//add vault ticket
	// if strings.HasPrefix(event.Text, "create vault ") {
	// 	msg, err := vault.HandleUserSelfCreateVaultBlock(event.Text, event.User)

	// 	if err != nil {
	// 		sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
	// 		return nil
	// 	}

	// 	client.PostMessage(event.User, slack.MsgOptionTS(event.TimeStamp), msg)
	// 	return nil
	// }

	//manage wl rancher
	if strings.HasPrefix(event.Text, "manage ") {

		client.PostMessage(event.User, slack.MsgOptionTS(event.TimeStamp), slack.MsgOptionText("this command is deprecated now, please using `help` command to reach another way", true))
		return nil
	}

	//manage wl rancher
	if strings.HasPrefix(event.Text, "getfile") {
		msg, err := common.HandleUserSelfGenFileBlock(event.Text, event.User)

		if err != nil {
			sendEventResponse(client, event.Channel, event.EventTimeStamp, err, "error", "post")
			return nil
		}

		client.PostMessage(event.User, slack.MsgOptionTS(event.TimeStamp), msg)
		return nil
	}

	return nil
}

func sendApproveAddDeploy(client *slack.Client, userID, deployment string) error {

	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	user, err := client.GetUserInfo(userID)

	if err != nil {
		return err
	}
	attachment, err := common.CreateAttachment("user_add_deploy", "<!subteam^SVALNFK27> Add user permission to redeploy deployment", "User: "+user.Name+" Deployment: "+deployment, "user_add_deployment", user.ID+" "+deployment)

	if err != nil {
		return err
	}

	_, _, err = client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(attachment))

	if err != nil {
		return err
	}
	return nil
}
func sendEventResponse(client *slack.Client, channel string, ts string, err error, response string, postType string) string {

	attachment := slack.Attachment{}
	//ts := event.TimeStamp

	if response == "error" {
		attachment.Color = "#ff0000"
		attachment.Text = err.Error()

	} else {
		attachment.Text = response
		attachment.Color = "#00cc00"
	}
	attachment.Pretext = ":mag: Bot response:"

	if postType == "post" {
		_, ts, err = client.PostMessage(channel, slack.MsgOptionTS(ts), slack.MsgOptionAttachments(attachment))

	} else if postType == "update" {
		fmt.Println(ts)
		_, ts, _, err = client.UpdateMessage(channel, ts, slack.MsgOptionAttachments(attachment))

	} else if postType == "delete" {
		_, ts, err = client.DeleteMessage(channel, ts)

	}

	return ts
}
