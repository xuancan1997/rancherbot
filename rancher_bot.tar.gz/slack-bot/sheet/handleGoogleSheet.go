package sheet

import (
	"context"
	"io/ioutil"
	"os"

	"github.com/joho/godotenv"

	"gopkg.in/Iwark/spreadsheet.v2"

	"golang.org/x/oauth2/google"
)

func GetGoogleSheetData() (*spreadsheet.Sheet, error) {

	godotenv.Load(".env")
	//get all local key

	SHEET_ID := os.Getenv("SHEET_ID")
	SHEET_NAME := os.Getenv("SHEET_NAME")
	GGSHEET_SA := os.Getenv("GOOGLE_EVENT_FILE_LOCATION")

	//log.Println("Sa locate: ", GGSHEET_SA)
	data, err := ioutil.ReadFile(GGSHEET_SA)
	if err != nil {
		return nil, err
	}

	conf, err := google.JWTConfigFromJSON(data, spreadsheet.Scope)
	if err != nil {
		return nil, err
	}
	client := conf.Client(context.TODO())

	service := spreadsheet.NewServiceWithClient(client)
	//https://docs.google.com/spreadsheets/d/1T6AEo81FPr6q4GjovoiUPZqzSV7RboOh_FPLs9WX_iY/edit#gid=1464661504
	spreadsheet, err := service.FetchSpreadsheet(SHEET_ID)
	if err != nil {
		return nil, err
	}
	sheet, err := spreadsheet.SheetByTitle(SHEET_NAME)
	if err != nil {
		return nil, err
	}
	return sheet, err
}
