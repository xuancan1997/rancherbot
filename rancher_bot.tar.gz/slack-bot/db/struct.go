package db

import "cloud.google.com/go/civil"

type ProjectData struct {
	Name     string     `json:"project_name"`
	Time     civil.Date `json:"time_fragment"`
	Cost     float32    `json:"cost"`
	Credits  float32    `json:"credits"`
	RealPaid float32    `json:"realpaid"`
	PIC      string
}

const chartConfigSample = `{
	type: 'bar',
	data: {
	  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
	  datasets: [{
		label: 'Retweets',
		data: [12, 5, 40, 5]
	  }, {
		label: 'Likes',
		data: [80, 42, 215, 30]
	  }]
	},
	options: {
		plugins: {
		  datalabels: {
			anchor: 'end',
			align: 'top',
			color: '#fff',
			backgroundColor: 'rgba(34, 139, 34, 0.6)',
			borderWidth: 1,
			borderRadius: 5,
			formatter: (value) => {
			  return value + 'k';
			},
		  },
		},
	},
	
  }`

type ChartConfig struct {
	Type    string    `json:"type"`
	Data    ChartData `json:"data"`
	Options struct {
		Title struct {
			Display bool   `json:"display"`
			Text    string `json:"text"`
		} `json:"title"`
		Plugins struct {
			Datalabels struct {
				Anchor          string `json:"anchor"`
				Align           string `json:"align"`
				Color           string `json:"color"`
				BackgroundColor string `json:"backgroundColor"`
				BorderWidth     string `json:"borderWidth"`
				BorderRadius    string `json:"borderRadius"`
				Formatter       string `json:"formatter"`
			} `json:"datalabels"`
		} `json:"plugins"`
	} `json:"options"`
}

type ChartData struct {
	Labels   []string       `json:"labels"`
	Datasets []ChartDataset `json:"datasets"`
}

type ChartDataset struct {
	Label string   `json:"label"`
	Data  []string `json:"data"`
}
