package db

import (
	"errors"
	"log"
	"slack-bot/sheet"
	"strings"
	"time"
)

var validProject = map[string]string{
	"talaria":         "xuan.can",
	"marketplace":     "xuan.can",
	"catalog":         "xuan.can",
	"ai":              "xuan.can",
	"core-platform":   "quy.vu1",
	"astra":           "xuan.can",
	"checkout":        "long.nguyen11",
	"payment":         "long.nguyen11",
	"data-platform":   "khoa.tran1",
	"discovery":       "khoa.tran1",
	"insurtech":       "khoa.tran1",
	"infras":          "nguyen.doan",
	"operations":      "long.nguyen11",
	"shopping":        "khoa.tran1",
	"social-commerce": "long.nguyen11",
	"app-platform":    "quy.vu1",
	"s14e":            "quy.vu1",
	"integration":     "quy.vu1",
	"finance":         "nguyen.doan",
	"common":          "khoa.tran1",
	"devops":          "nguyen.doan",
	"astra-validator": "nguyen.doan",
	"dev-tiki-infra":  "nguyen.doan",
	//"special-proxy":   "nguyen.doan",
	"tiki-infra":         "nguyen.doan",
	"tiki-astra":         "nguyen.doan",
	"tiki-analytics-dwh": "nguyen.doan",
	"tiki-dwh":           "nguyen.doan",
	"special-tnsl-dwh":   "nguyen.doan",
}

func getEventDate(numberDateCheck int) ([]string, bool, error) {
	var listEvent []string

	currentDate := time.Now()
	minDate := time.Now().Add(-24 * time.Duration(numberDateCheck+1) * time.Hour)
	//get all header sheets
	ggsheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		return nil, false, err
	}
	for i, row := range ggsheet.Rows {
		if i == 0 {
			for _, cell := range row {
				cellValue := strings.TrimSpace(cell.Value)

				//log.Println(cellValue)
				if strings.HasPrefix(cellValue, "Event") {
					tempDate := ""
					if strings.Contains(cellValue, " ") {
						splitCellValue := strings.Split(cellValue, " ")

						log.Println(splitCellValue)

						tempDate = splitCellValue[len(splitCellValue)-1]
					} else {
						return nil, false, errors.New("cannot get date from event on gooogle sheet data")
					}

					splitTempDate := strings.Split(tempDate, "/")

					if len(splitTempDate) != 3 {
						return nil, false, errors.New("format date time not correct, please check value " + tempDate)
					}
					tempYear := splitTempDate[2]
					tempMonth := splitTempDate[1]
					tempDay := splitTempDate[0]

					if len(tempMonth) == 1 {
						tempMonth = "0" + tempMonth
					}

					if len(tempDay) == 1 {
						tempDay = "0" + tempDay
					}
					tempDateRightFormat := tempYear + "-" + tempMonth + "-" + tempDay
					getTempDate, err := time.Parse("2006-01-02", tempDateRightFormat)

					//timeInUS := getTempDate.Add(-15 * time.Hour)
					if err != nil {
						log.Println(err)
						return nil, false, err
					}

					log.Println("This date", getTempDate.Format("2006-01-02"), currentDate.Add(-25*time.Hour).Format("2006-01-02"))

					if minDate.Before(getTempDate) {
						if getTempDate.Format("2006-01-02") == currentDate.Add(-25*time.Hour).Format("2006-01-02") || getTempDate.Format("2006-01-02") == currentDate.Add(-49*time.Hour).Format("2006-01-02") {
							log.Println("Event's running")
							return listEvent, true, nil
						}

						listEvent = append(listEvent, getTempDate.Format("2006-01-02"))
					}
				}
			}
		} else {
			break
		}
	}

	return listEvent, false, nil
}

func checkProjectValue(input string) (map[string]string, error) {
	projectList := make(map[string]string)

	if strings.Contains(input, ",") {
		listProject := strings.Split(input, ",")

		for _, project := range listProject {
			if validProject[project] == "" {
				return projectList, errors.New("project" + project + " has not defined in list watcher, please add")
			}
			projectList[project] = validProject[project]
		}
	} else if input == "all" {
		projectList = validProject
	} else {
		if validProject[input] == "" {
			return projectList, errors.New("project not defined in list watcher, please add")
		}
		projectList[input] = validProject[input]
	}

	log.Println(projectList)
	return projectList, nil
}
