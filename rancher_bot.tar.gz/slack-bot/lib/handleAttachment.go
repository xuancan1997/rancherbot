package lib

import (
	"log"

	"github.com/slack-go/slack"
)

func GetKongAttachment() slack.Message {

	log.Printf("Go to kong block elements")
	//svcTextBlockObject := slack.NewTextBlockObject("plain_text", "Ex: zorba.dev.tiki.services/v1/golden", false, false)
	//svcBlockElm := slack.NewPlainTextInputBlockElement(svcTextBlockObject, "svc_input")
	//svcInputBlock := slack.NewInputBlock("svcInput", svcLabeltBlock, svcBlockElm)

	//blockResp := slack.NewActionBlock("kong_input", svcBlockElm)

	//accessory := slack.NewAccessory(svcBlockElm)

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Enter services", false, false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	block := slack.NewBlockMessage(headerSection)

	return block

}
