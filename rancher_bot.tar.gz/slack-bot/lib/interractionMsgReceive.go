package lib

import (
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"slack-bot/github"
	"strings"

	"github.com/slack-go/slack"
)

var reactInterractionReceiveMsg = map[string]func(client *slack.Client, dataInput string, user *slack.User, interraction *slack.InteractionCallback) error{
	"add-user-to-repo":          addUserToRepoInterraction,
	"create-new-git-repo":       createNewGitRepoInterraction,
	"send-manager-add-repo":     addUserToRepoManagerClick,
	"send-manager-create-repo":  createRepoManagerHandleInterraction,
	"manager-approve-manage-wl": sendManageRequestToInfraChannel,
}

func sendManageRequestToInfraChannel(client *slack.Client, dataInput string, userClick *slack.User, interraction *slack.InteractionCallback) error {
	dataInputSplit := strings.Split(dataInput, " ")
	index := 0
	cluster := dataInputSplit[index]
	index++
	project := dataInputSplit[index]
	index++
	userRequest := dataInputSplit[index]
	index++
	manageType := dataInputSplit[index]
	index++
	hour := dataInputSplit[index]

	gitUserName := github.GetUserGitName(userRequest)
	//send data to infras
	manageConfig := ""
	if manageType == "normal" {
		manageConfig = "Tiki Manage Workloads Configmaps"
	} else {
		manageConfig = "Tiki Developer (Manage workloads)"
	}

	textSendToInfra := fmt.Sprintf(".rancher grant %s | %s | %s | %s | %s", cluster, project, gitUserName, manageConfig, hour)
	log.Println(textSendToInfra)

	INFRA_CHANNEL_ID := os.Getenv("INFRA_CHANNEL_ID")
	client.PostMessage(INFRA_CHANNEL_ID, slack.MsgOptionText(textSendToInfra, false))

	//update manager msg
	client.UpdateMessage(interraction.Channel.ID, interraction.MessageTs, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: fmt.Sprintf("Send data to infras team now, your member can manage workload for %s hour", hour)}))

	//post Msg to user request
	client.PostMessage(userRequest, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: "Your request have been sent to infras team, you can manage your workload now"}))

	return nil
}

func createNewGitRepoInterraction(client *slack.Client, dataInput string, userClick *slack.User, interraction *slack.InteractionCallback) error {

	dataInputSplit := strings.Split(dataInput, " ")
	repoName := dataInputSplit[0]
	permission := dataInputSplit[1]
	userRequestID := dataInputSplit[2]

	userGit := github.GetUserGitName(userRequestID)

	log.Println("user ", userRequestID)
	user, err := client.GetUserInfo(userRequestID)

	if err != nil {
		return err
	}
	//create new git repo
	if err := github.CreateNewGitRepo(repoName, userGit, permission); err != nil {
		return err
	}

	//add team deployment to cicd trigger
	if err := github.AddDeploymentTeamToNewRepo(repoName); err != nil {
		return err
	}

	//post msg reponse userRequest
	textReponse := fmt.Sprintf("Created repo *%s* with permission *%s* for user *%s*", repoName, permission, user.Name)
	client.PostMessage(user.ID, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponse}))

	textToChannel := fmt.Sprintf("Success create repo `%s` with permission `%s` for user `%s`", repoName, permission, user.Name)
	//post msg to channel
	client.UpdateMessage(interraction.Channel.ID, interraction.MessageTs, slack.MsgOptionTS(interraction.MessageTs), slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textToChannel}))

	return nil
}

func createRepoManagerHandleInterraction(client *slack.Client, dataInput string, userClick *slack.User, interraction *slack.InteractionCallback) error {
	dataInputSplit := strings.Split(dataInput, " ")
	repoName := dataInputSplit[0]
	permission := dataInputSplit[1]
	userRequestID := dataInputSplit[2]

	//userGit := github.GetUserGitName(userRequestID)

	log.Println("Manager clicked create repo github")
	userRequest, err := client.GetUserInfo(userRequestID)

	if err != nil {
		return err
	}
	//post msg to systemoi
	preText := "New Create Repo GitHub Request:"
	text := fmt.Sprintf("<!subteam^SVALNFK27> User `%s` requests to create repo `%s` with permission `%s`\nRequest approved by %s", userRequest.Name, repoName, permission, interraction.User.Name)
	attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "create-new-git-repo", "create-new-git-repo", fmt.Sprintf("%s %s %s", repoName, permission, userRequestID), "deny_common", true)
	if err != nil {
		return err
	}

	//update manager msg
	textReponseManager := fmt.Sprintf("Success send request to systemoi to create repo %s", repoName)
	_, _, _, err = client.UpdateMessage(interraction.Channel.ID, interraction.MessageTs, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponseManager}))

	if err != nil {
		return err
	}

	CHANNEL := os.Getenv("CHANNEL_ID")

	client.PostMessage(CHANNEL, slack.MsgOptionAttachments(attachment))

	//post msg to user request
	textReponse := "Your manager has approved your ticket, please wait systemoi accept it"
	client.PostMessage(userRequestID, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponse}))

	return nil
}

func addUserToRepoInterraction(client *slack.Client, dataInput string, userClick *slack.User, interraction *slack.InteractionCallback) error {

	dataInputSplit := strings.Split(dataInput, " ")
	repoName := dataInputSplit[0]
	userGit := dataInputSplit[1]
	permission := dataInputSplit[2]
	userRequestID := dataInputSplit[3]

	if err := github.AddUserToRepo(userGit, repoName, permission); err != nil {
		return err
	}

	//post msg reponse userRequest
	textReponse := fmt.Sprintf("You have added to repo *%s* with permission *%s*", repoName, permission)
	client.PostMessage(userRequestID, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponse}))

	textToChannel := fmt.Sprintf("Success add user `%s` to repo `%s` with permission `%s`", userGit, repoName, permission)
	//post msg to channel
	client.UpdateMessage(interraction.Channel.ID, interraction.MessageTs, slack.MsgOptionTS(interraction.MessageTs), slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textToChannel}))

	return nil
}

func addUserToRepoManagerClick(client *slack.Client, dataInput string, userClick *slack.User, interraction *slack.InteractionCallback) error {
	dataInputSplit := strings.Split(dataInput, " ")
	repoName := dataInputSplit[0]
	userGit := dataInputSplit[1]
	permission := dataInputSplit[2]
	userRequestID := dataInputSplit[3]

	log.Println("Manager clicked submit github")
	userRequest, err := client.GetUserInfo(userRequestID)

	if err != nil {
		client.PostMessage(userClick.ID, slack.MsgOptionAttachments(slack.Attachment{Color: red, Text: err.Error()}))
		return err
	}
	//post msg to systemoi
	preText := "New GitHub Request:"
	text := fmt.Sprintf("<!subteam^SVALNFK27> User `%s` requests to access repo `%s` with permission `%s`\nRequest approved by %s", userRequest.Name, repoName, permission, interraction.User.Name)
	attachment, err := common.CreateNewAttachment(preText, text, green, "Approve", "add-user-to-repo", "add-user-to-repo", fmt.Sprintf("%s %s %s %s", repoName, userGit, permission, userRequestID), "deny_common", true)
	if err != nil {
		return err
	}

	//update manager msg
	textReponseManager := fmt.Sprintf("Success send request to systemoi to add %s to repo %s", userRequest.Name, repoName)
	_, _, _, err = client.UpdateMessage(interraction.Channel.ID, interraction.MessageTs, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponseManager}))

	if err != nil {
		log.Println(err)
		return err
	}

	CHANNEL := os.Getenv("CHANNEL_ID")

	client.PostMessage(CHANNEL, slack.MsgOptionAttachments(attachment))

	//post msg to user request
	textReponse := "Your manager has approved your ticket, please wait systemoi accept it"
	client.PostMessage(userRequestID, slack.MsgOptionAttachments(slack.Attachment{Color: green, Text: textReponse}))

	return nil
}
