package kong

import (
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

func initKongHttpReq(method string, querryCmd string, readerInput string) (*http.Response, error) {
	var httpResp *http.Response
	godotenv.Load(".env")

	//apiUrl := os.Getenv("KONG_ENDPOINT")
	//querryCommmand := apiUrl + querryCmd

	log.Println("Host kong is", querryCmd)
	accessKey := os.Getenv("KONG_ACCESS_KEY")

	secretKey := os.Getenv("KONG_SECRET_KEY")

	//fmt.Printf(readerInput)

	client := &http.Client{Timeout: 10 * time.Second}

	reader := strings.NewReader(readerInput)

	request, err := http.NewRequest(method, querryCmd, reader)

	if err != nil {
		return httpResp, errors.New("could not run request to kong")
	}

	request.Header.Add("Content-Type", "application/json; charset=UTF-8")
	request.Header.Add("Accept", "application/json")
	request.SetBasicAuth(accessKey, secretKey)

	httpResp, err = client.Do(request)

	if err != nil {
		fmt.Println(err.Error())
		return httpResp, errors.New("could not run request to kong, please check connection")
	}

	return httpResp, nil
}
