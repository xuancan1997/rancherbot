package rancher

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"sort"
	"strconv"
	"strings"

	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/spf13/viper"
)

//handle user rollback block
func HandleRollbackMsg(data string) (slack.MsgOption, error) {
	var msg slack.MsgOption

	splitInput := strings.Split(data, " ")

	if len(splitInput) != 2 {
		log.Println(len(splitInput))
		return msg, errors.New("input format not correct")
	}

	deployment := splitInput[1]

	err := common.ValidateInput(deployment, "name")

	if err != nil {
		return msg, err
	}

	rancherData, err := GetDeploymentWithDeploymentName(deployment)
	if err != nil {
		return msg, err
	}

	currentContainerData, _, err := GetRancherContainers(rancherData)
	if err != nil {
		return msg, err
	}
	// log.Println(rancherData.Type)

	// if rancherData.Type != "deployment" {
	// 	return msg, errors.New("only support rollback deployment :pepescared:")
	// }

	revisionsData, err := getRevisionData(rancherData)
	if err != nil {
		return msg, err
	}

	//log.Println(revisionsData)

	blockElm, currentTsImage, err := getRevisionBlockElm(revisionsData, currentContainerData, deployment)

	if err != nil {
		return msg, err
	}
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n*Current pods image:*`"+currentContainerData.Name+"`\n*Release date:*`"+currentTsImage+"`\nPlease choose image you want to rollback:",
		false,
		false)

	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	btn := common.GetAprroveBtnWithValue("send_approve_redeploy_to_system", "`"+deployment+"` from "+currentContainerData.Name)
	//btn := common.Get
	msg = slack.MsgOptionBlocks(
		headerSection,
		blockElm,
		btn,
	)

	return msg, nil
}

type RevisionSorter []ContainerData

func getRevisionBlockElm(revisions RevisionContainers, currentData ContainerData, deployment string) (*slack.ActionBlock, string, error) {
	var return_block *slack.ActionBlock

	options := []*slack.OptionBlockObject{}

	imageBuild := make(map[string]bool)
	currentTsImage := ""

	//firstImage := ""

	//sort slice
	sort.Slice(revisions.RevisionData, func(i, j int) bool {
		return revisions.RevisionData[i].Created > revisions.RevisionData[j].Created
	})

	for _, revision := range revisions.RevisionData {

		image := ""

		isSetImage := false

		//if has no change, continue

		for _, imageData := range revision.Containers {
			//log.Printf("%+v", imageData)

			if currentData.Name == imageData.Name {
				currentTsImage = revision.Created
				isSetImage = true
				break
			}

			log.Println(currentData.Name, imageData.Name)

			//igrone pluton or alpine image
			if !strings.Contains(imageData.Name, "pluton") {

				//log.Println(imageData)

				splitImageName := strings.Split(imageData.Name, "/")
				image = splitImageName[len(splitImageName)-1]
				// if i == 0 {
				// 	firstImage = imageData.Image
				// }
				//log.Println("True data", image)
				isSetImage = true

				break
			}

		}

		if image == "" && !isSetImage {
			return return_block, "", errors.New("cannot get image name of deployment " + currentData.Name)
		}

		//continue if  container found is not main container, example istio or has no change image
		if !isSetImage || image == "" {
			continue
		}

		//log.Println("Image set: ", isSetImage, image)

		//log.Println(revision.Containers)
		tempTxt := slack.NewTextBlockObject("plain_text", image, true, false)

		revisionUrl := revision.Actions.Redeploy

		revisionUrl = strings.Split(revisionUrl, "/workloads/")[0] + "/workloads/" + revision.Id + "?action=rollback"
		tempOption := slack.NewOptionBlockObject(revisionUrl, tempTxt, nil)

		//log.Println("Append Option data", revision.Created+"|"+image)

		if !imageBuild[image] {

			log.Println(image, imageBuild[image])
			options = append(options, tempOption)

			imageBuild[image] = true

		}

	}

	if currentTsImage == "" {
		return return_block, "", errors.New("cannot get current image name of this deployment")

	}
	//log.Println("Option init", revisions.RevisionData[0].Created+"|"+firstImage)
	// initOption := slack.NewTextBlockObject("plain_text", revisions.RevisionData[0].Created+"|"+firstImage, false, false)
	// initialOption := slack.NewOptionBlockObject(revisions.RevisionData[0].Id, initOption, nil)

	//selectObject := slack.NewTextBlockObject("plain_text", placeholder, false, false)

	if len(options) == 0 {
		return return_block, "", errors.New("cannot get any previous image data")
	}
	availableOption := common.NewOptionsSelectBlockElementWithInitOptions("static_select", "revision_action_id", options[0], options...)

	return_block = slack.NewActionBlock("revision_action_id", availableOption)

	return return_block, currentTsImage, nil
}

func HandleUserSelfManageWLBlock(input, userID string) (slack.MsgOption, error) {
	var msg slack.MsgOption

	splitInput := strings.Split(input, " ")

	if len(splitInput) != 3 {
		log.Println(len(input))
		return msg, errors.New("input format not correct")
	}

	deployment := splitInput[1]

	err := common.ValidateInput(deployment, "name")

	if err != nil {
		return msg, err
	}

	hour := splitInput[2]

	hourToInt, err := strconv.Atoi(hour)
	if err != nil {
		return msg, err
	}

	//check if user already added

	manageProfile, err := checkUserManageWLProfile(deployment, userID)

	if err != nil {
		return msg, err
	}

	if hourToInt > 8 || hourToInt < 1 {
		if hourToInt > 4 {
			hour = "4"
		}

		return msg, errors.New("only accept manage max 8 hour per request!!!")
	}
	log.Println("Profile: ", manageProfile)

	log.Println(hour)

	manageProfile.Hour = hour
	//check deployment is updated, if updated reregister
	isUpdate := false
	rancherData, err := GetDeploymentWithDeploymentName(deployment)
	if err != nil {
		return msg, err
	}

	if rancherData.ProjectName != manageProfile.ProjectName {
		isUpdate = true
		//manageProfile.UserNameGit = ""
	}

	//if user not added to profile, then ask user to select
	if manageProfile.UserNameGit == "" || isUpdate {

		manageProfile.Cluster = rancherData.ClusterName
		projectID := rancherData.ProjectID
		clusterID, err := getClusterIdWithClusterName(manageProfile.Cluster)

		if err != nil {
			return msg, err
		}

		projects, err := getProjectWithClusterID("", clusterID)

		if err != nil {
			return msg, err
		}

		for _, project := range projects.Data {
			if project.ID == projectID {
				manageProfile.ProjectName = project.Name

				manageProfile.ProjectName = strings.Replace(strings.TrimSpace(project.Name), " ", "-", -1)
				break
			}
		}

		if manageProfile.ProjectName == "" {
			return msg, errors.New("cannot get project " + rancherData.ProjectName)
		}

	}

	//block for the first time
	var headerText *slack.TextBlockObject
	var userNameGit *slack.InputBlock
	var userManager *slack.InputBlock
	if manageProfile.Manager == "" {
		headerText = slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\nThis is the very first time you use this, please fill data as below:"+
			"\n*Worload manage info:* \n```Cluster: "+manageProfile.Cluster+"\nProject: "+manageProfile.ProjectName+"```",
			false,
			false)
		userNameGit = common.GetTxtInputBlock("user_name_git", "Enter your username github", "Example: TramZn-tiki")
		userManager = common.GetTxtInputBlock("user_manager", "Enter your manager name, ignore if you're already a leader", "Example: nguyen.doan not nguyen.doan@tiki.vn")
	} else {
		headerText = slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\nPlease confirm data following this table below",
			false,
			false)
		userNameGit = common.GetTxtInputBlockWithInitInput("user_name_git", "Enter your username github", "Example: TramZn-tiki", manageProfile.UserNameGit)
		userManager = common.GetTxtInputBlockWithInitInput("user_manager", "Enter your manager name, ignore if you're already a leader", "Exmaple: nguyen.doan not nguyen.doan@tiki.vn", manageProfile.Manager)

	}

	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	description := common.GetTxtInputBlock("user_description", "Description", "If you want to manage configmap, type Manage-Configmaps")

	btn := common.GetAprroveBtnWithValue("send_manage_wl_btn", manageProfile.Cluster+" "+manageProfile.ProjectName+" "+userID+" "+
		manageProfile.Hour+" "+deployment)
	msg = slack.MsgOptionBlocks(
		headerSection,
		userNameGit,
		userManager,
		description,
		btn,
	)

	return msg, nil
}

func getScaleOptimizeBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\nEnable optimize cost",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	var trueFalse []string
	trueFalse = append(trueFalse, "true")
	trueFalse = append(trueFalse, "false")
	enableOptimizeElm, err := common.GetSelectedOptionBlock(trueFalse, "false", "Select value", "optimize_cost_options", "Enable optimize:")
	enableOptimizeBlock := slack.NewActionBlock("optimize_cost_options", enableOptimizeElm)
	if err != nil {
		return msg, err
	}

	inputNormalRun := common.GetTxtInputBlock("event_scale_init", "Enter event init", "example: Scale Normal")
	// inputDateOptimizeRun := common.GetTxtInputBlock("time_optimize_run", "Enter time run optimize scale", "example: 0 0 11 * * *")
	btn := common.GetAprroveBtn("init_optimize_cost_btn")

	msg = slack.MsgOptionBlocks(
		headerSection,
		enableOptimizeBlock,
		inputNormalRun,
		// inputDateNormalRun,
		// inputDateOptimizeRun,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func getRemindEventEditBlock(input string) (slack.MsgOption, error) {

	deploymentLength := 3
	var msg slack.MsgOption

	var deployments []Data

	splitInput := strings.Split(input, " ")

	if len(splitInput) == 0 {
		return msg, errors.New("Notthing to do")
	}

	event := ""
	for i, input := range splitInput {

		//get event header
		if i == 0 {
			event = strings.ReplaceAll(input, "-", " ")

			continue
		}

		deploymentValue := strings.Split(input, ":")

		if len(deploymentValue) != deploymentLength {
			return msg, errors.New("Somethings when wrong with deployment data")
		}

		var deployment Data

		deployment.Position, _ = strconv.Atoi(deploymentValue[0])
		deployment.Name = deploymentValue[1]
		repSplit := strings.Split(deploymentValue[2], "-")

		if len(repSplit) == 1 {
			deployment.Replicas, _ = strconv.Atoi(deploymentValue[2])
		} else if len(repSplit) == 2 {
			deployment.MinReplicas, _ = strconv.Atoi(repSplit[0])
			deployment.MaxReplicas, _ = strconv.Atoi(repSplit[1])

		}

		deployments = append(deployments, deployment)
	}

	var actionBlock []*slack.ActionBlock

	var eventArr []string

	eventArr = append(eventArr, event)
	//log.Println(event, eventArr)
	//eventElm, err := common.GetSelectedOptionBlock(eventArr, event, "Select event", "remind_event_header_choose", "")

	eventElm, err := common.GetSelectedOptionBlock(eventArr, event, "choose an event", "choose_event_remind", "")
	if err != nil {
		return msg, err
	}

	actionHeader := slack.NewActionBlock("remind_event_header", eventElm)

	for i, deployment := range deployments {
		var action *slack.ActionBlock
		var input []string
		input = append(input, strconv.Itoa(deployment.Position)+". "+deployment.Name)
		deploymentElm, err := common.GetSelectedOptionBlock(input, strconv.Itoa(deployment.Position)+". "+deployment.Name, "Select deployment", "remind_deployment_choose_"+strconv.Itoa(i), "")

		if err != nil {
			return msg, err
		}
		//position, err := common.GetSelectedOptionsNumberBlock(100, deployment.Position, "Position ", "remind_position_choose_"+strconv.Itoa(i))

		if deployment.Replicas != 0 {
			replicaElm, err := common.GetSelectedOptionsNumberBlock(100, deployment.Replicas, "Replicas", "remind_replicas_choose_"+strconv.Itoa(i))

			if err != nil {
				return msg, err
			}

			action = slack.NewActionBlock("remind_deployment_choose_"+strconv.Itoa(i), deploymentElm, replicaElm)
		} else {

			minRepElm, err := common.GetSelectedOptionsNumberBlock(100, deployment.MinReplicas, "Min", "remind_replicas_choose_min_"+strconv.Itoa(i))
			if err != nil {
				return msg, err
			}
			maxRepElm, err := common.GetSelectedOptionsNumberBlock(100, deployment.MaxReplicas, "Max", "remind_replicas_choose_max_"+strconv.Itoa(i))

			if err != nil {
				return msg, err
			}

			action = slack.NewActionBlock("remind_deployment_choose_"+strconv.Itoa(i), deploymentElm, minRepElm, maxRepElm)

		}

		if err != nil {
			return msg, err
		}

		actionBlock = append(actionBlock, action)

		// checkBoxBlock,

		//msg = append(msg, tmpMsg)

	}

	//log.Println(actionBlock[:])

	blocks := slack.NewBlockMessage()

	//append event to header
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n Please edit your workload following data below:",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)
	blocks.Blocks.BlockSet = append(blocks.Blocks.BlockSet, headerSection)
	blocks.Blocks.BlockSet = append(blocks.Blocks.BlockSet, actionHeader)
	for i := range actionBlock {
		blocks.Blocks.BlockSet = append(blocks.Blocks.BlockSet, actionBlock[i])
	}

	btnAction := common.GetAprroveBtn("user_submit_edit_remind_event_btn")

	blocks.Blocks.BlockSet = append(blocks.Blocks.BlockSet, btnAction)
	msg = slack.MsgOptionBlocks(blocks.Msg.Blocks.BlockSet...)
	return msg, nil

}

func getRemindEventBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("remind_event_input", "Enter event need to remind to Authors if data is not updated or filled", "Example:\nEvent 8/8/20222")
	inputBlock2 := common.GetMultiLinesInputBlock("remind_event_rep_input", "Enter event base", "Example:\nEvent 7/7/20222")

	// textBlockObject := slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	// op := slack.NewOptionBlockObject("approved", textBlockObject, nil)

	// checkbox := slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm", op)

	// checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm", checkbox)
	btn := common.GetAprroveBtn("remind_event_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		inputBlock2,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}
func getScaleBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("scale_event_input", "Enter event need to scale, type `Scale Normal` if want to scale back:", "Example:\nEvent 8/8/20222")

	// textBlockObject := slack.NewTextBlockObject("plain_text", "Waiting for approve", false, false)
	// op := slack.NewOptionBlockObject("approved", textBlockObject, nil)

	// checkbox := slack.NewCheckboxGroupsBlockElement("checkbox_scale_confirm", op)

	// checkBoxBlock := slack.NewActionBlock("checkbox_scale_confirm", checkbox)
	btn := common.GetAprroveBtn("scale_event_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		// checkBoxBlock,
		btn,
	)
	return msg, nil
}

func GetReRunDeploymentBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEnter deployment you need to rerun`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("rerun_input", "Enter data:", "Example:\nbulma")

	btn := common.GetAprroveBtn("rerun_approve_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		btn,
	)
	return msg, nil
}

func GetRedeployDeploymentBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nPattern to redeploy: `| cluster | project | namespace | deployment |`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("redeploy_input", "Enter data:", "Example:\n| dev | checkout | default | milo |")

	btn := common.GetAprroveBtn("redeploy_approve_btn")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		btn,
	)
	return msg, nil
}

func GetCallBotBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nChoose an action:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	listCommand := []string{"rancher adduser", "rancher adduser", "rancher resetpwd",
		"hpa list", "hpa list all", " hpa scale event", "hpa scale normal", "hpa edit", "hpa edits",
		"deploy list", "deploy list all", "deploy edit", "deploy add", "deploy find", "deploy scale normal", "deploy scale event",
		"scale manually",
		"kong addsvc", "kong addsvc 2",
		"to json",
	}

	sort.Strings(listCommand)
	blockElmChosen, err := common.GetOptionsBlock(listCommand, "static_select", "Choose an action", "choose_action")
	if err != nil {
		return msg, nil
	}
	blockChosen := slack.NewActionBlock("choose_action", blockElmChosen)
	msg = slack.MsgOptionBlocks(
		headerSection,
		blockChosen,
	)

	return msg, nil
}

func GetDeploymentDetailBlockWithDepoymentChosen(blockAc map[string]map[string]slack.BlockAction) (slack.MsgOption, error) {
	var msg slack.MsgOption
	clusterChoosen := blockAc["hpa_edit_choose"]["hpa_edit_cluster_choose"].SelectedOption.Value

	projectChoosen := blockAc["hpa_edit_choose"]["hpa_edit_project_choose"].SelectedOption.Value

	deploymentChoosen := blockAc["hpa_edit_choose"]["hpa_edit_deployment_choose"].SelectedOption.Value

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEdit hpa following information below:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	clusters, err := getClusters()

	if err != nil {
		return msg, err
	}

	var clusterMsg []string

	for _, cluster := range clusters.Data {
		clusterMsg = append(clusterMsg, cluster.Name)
	}

	clusterElm, err := common.GetSelectedOptionBlock(clusterMsg, clusterChoosen, "select a cluster", "hpa_edit_cluster_choose", "")
	if err != nil {
		return msg, err
	}

	clusterId, err := getClusterIdWithClusterName(clusterChoosen)
	if err != nil {
		return msg, err
	}
	projects, err := getProjectWithClusterID("", clusterId)
	if err != nil {
		return msg, err
	}

	var projectMsg []string
	var projectId string
	for _, project := range projects.Data {

		if project.Name == projectChoosen {
			projectId = project.ID
		}
		projectMsg = append(projectMsg, project.Name)
	}

	projectElm, err := common.GetSelectedOptionBlock(projectMsg, projectChoosen, "select a project", "hpa_edit_project_choose", "")

	if err != nil {
		return msg, err
	}

	hpaList, err := getHpaWithProjectId(projectId, "")

	if err != nil {
		return msg, err
	}

	var hpaMsg []string

	var hpaLs []RancherHpas
	for i, hpa := range hpaList.Data {

		fmt.Println(hpa.ID)
		hpaMsg = append(hpaMsg, hpa.ID)
		hpa.ClusterName = clusterChoosen

		if i == 99 {
			break
		}
	}

	var deploymentElm *slack.SelectBlockElement
	if len(hpaMsg) == 0 {
		hpaMsg = append(hpaMsg, "none of hpa")
		deploymentElm, err = common.GetOptionsBlock(hpaMsg, "static_select", "none of hpa", "hpa_edit_deployment_choose")
	} else {

		deploymentElm, err = common.GetOptionsBlock(hpaMsg, "static_select", "select hpa", "hpa_edit_deployment_choose")

		if err != nil {
			return msg, err
		}
	}

	//read hpa from file

	hpaLs = append(hpaLs, hpaList)

	err = updateHpaLocalFile(hpaLs)

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err = v.ReadInConfig() // Find and read the config file
	// Find and read the config file
	if err != nil { // Handle errors reading the config file
		return msg, err
	}

	key := clusterChoosen + "@" + projectChoosen + "@" + strings.ReplaceAll(deploymentChoosen, ":", "@")

	value := v.GetString(key)

	data, err := getHpaValue(value)

	if err != nil {
		return msg, err
	}

	var inputForEnableHpaBot []string
	inputForEnableHpaBot = append(inputForEnableHpaBot, "enable")
	inputForEnableHpaBot = append(inputForEnableHpaBot, "disable")

	fmt.Println("Data :", data.Enabled)
	enableForBot, err := common.GetSelectedOptionBlock(inputForEnableHpaBot, data.Enabled, "enable auto hpa", "enable_bot_hpa", "enable: ")

	if err != nil {
		return msg, err
	}

	curMinRep, err := common.GetSelectedOptionsNumberBlock(100, data.MinReplicas, "Cur MinRep", "cur_min_rep")
	if err != nil {
		return msg, err
	}
	curMaxRep, err := common.GetSelectedOptionsNumberBlock(100, data.MaxReplicas, "Cur MaxRep", "cur_max_rep")
	if err != nil {
		return msg, err
	}

	minNorRep, err := common.GetSelectedOptionsNumberBlock(100, data.NormalMinReplicas, "MinNor", "min_nor_rep")
	if err != nil {
		return msg, err
	}

	maxNorRep, err := common.GetSelectedOptionsNumberBlock(100, data.NormalMaxReplicas, "MaxNor", "max_nor_rep")
	if err != nil {
		return msg, err
	}

	minEventRep, err := common.GetSelectedOptionsNumberBlock(100, data.EventMinReplicas, "MinEvent", "min_event_rep")
	if err != nil {
		return msg, err
	}

	maxEventRep, err := common.GetSelectedOptionsNumberBlock(100, data.EventMaxReplicas, "MaxEvent", "max_event_rep")
	if err != nil {
		return msg, err
	}

	repBlock := slack.NewActionBlock("rep_options", enableForBot, curMinRep, curMaxRep)
	rep2Block := slack.NewActionBlock("rep2_options", minNorRep, maxNorRep, minEventRep, maxEventRep)

	approveBtn := common.GetAprroveBtn("hpa_edit_choose_btn")

	deploymentBlock := slack.NewActionBlock("hpa_edit_choose", clusterElm, projectElm, deploymentElm)

	msg = slack.MsgOptionBlocks(
		headerSection,
		deploymentBlock,
		repBlock,
		rep2Block,
		approveBtn,
	)

	return msg, nil
}

func GetHpaDataBlockWithProjectChosen(blockAc map[string]map[string]slack.BlockAction) (slack.MsgOption, error) {
	var msg slack.MsgOption

	clusterChoosen := blockAc["hpa_edit_choose"]["hpa_edit_cluster_choose"].SelectedOption.Value

	projectChoosen := blockAc["hpa_edit_choose"]["hpa_edit_project_choose"].SelectedOption.Value

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nChoose hpa need to edit:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	clusters, err := getClusters()

	if err != nil {
		return msg, err
	}

	var clusterMsg []string

	for _, cluster := range clusters.Data {
		clusterMsg = append(clusterMsg, cluster.Name)
	}

	clusterElm, err := common.GetSelectedOptionBlock(clusterMsg, clusterChoosen, "select a cluster", "hpa_edit_cluster_choose", "")
	if err != nil {
		return msg, err
	}

	clusterId, err := getClusterIdWithClusterName(clusterChoosen)
	if err != nil {
		return msg, err
	}
	projects, err := getProjectWithClusterID("", clusterId)
	if err != nil {
		return msg, err
	}

	var projectMsg []string
	var projectId string

	for _, project := range projects.Data {

		if project.Name == projectChoosen {
			projectId = project.ID
		}

		projectMsg = append(projectMsg, project.Name)

	}

	projectElm, err := common.GetSelectedOptionBlock(projectMsg, projectChoosen, "select a project", "hpa_edit_project_choose", "")

	if err != nil {
		return msg, err
	}

	hpaList, err := getHpaWithProjectId(projectId, "")

	if err != nil {
		return msg, err
	}

	var hpaMsg []string
	for i, hpa := range hpaList.Data {

		fmt.Println(hpa.ID)
		hpaMsg = append(hpaMsg, hpa.ID)

		if i == 99 {
			break
		}
	}

	var deploymentElm *slack.SelectBlockElement
	if len(hpaMsg) == 0 {
		hpaMsg = append(hpaMsg, "none of hpa")
		deploymentElm, err = common.GetOptionsBlock(hpaMsg, "static_select", "none of hpa", "hpa_edit_deplyoment_choose")
	} else {
		deploymentElm, err = common.GetOptionsBlock(hpaMsg, "static_select", "select hpa", "hpa_edit_deployment_choose")

		if err != nil {
			return msg, err
		}
	}

	deploymentBlock := slack.NewActionBlock("hpa_edit_choose", clusterElm, projectElm, deploymentElm)
	msg = slack.MsgOptionBlocks(
		headerSection,
		deploymentBlock,
	)

	return msg, nil

}

func GetProjectBlockWithClusterChosen(blockAc map[string]map[string]slack.BlockAction) (slack.MsgOption, error) {
	var msg slack.MsgOption

	clusterChoosen := blockAc["hpa_edit_choose"]["hpa_edit_cluster_choose"].SelectedOption.Value

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nChoose hpa need to edit:\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	clusters, err := getClusters()

	if err != nil {
		return msg, err
	}

	var clusterMsg []string

	for _, cluster := range clusters.Data {
		clusterMsg = append(clusterMsg, cluster.Name)
	}

	clusterElm, err := common.GetSelectedOptionBlock(clusterMsg, clusterChoosen, "select a cluster", "hpa_edit_cluster_choose", "")
	if err != nil {
		return msg, err
	}

	clusterId, err := getClusterIdWithClusterName(clusterChoosen)
	if err != nil {
		return msg, err
	}
	projects, err := getProjectWithClusterID("", clusterId)
	if err != nil {
		return msg, err
	}

	var projectMsg []string
	for _, project := range projects.Data {
		projectMsg = append(projectMsg, project.Name)
	}

	projectElm, err := common.GetOptionsBlock(projectMsg, "static_select", "Choose a project", "hpa_edit_project_choose")
	prjBlock := slack.NewActionBlock("hpa_edit_choose", clusterElm, projectElm)
	if err != nil {
		return msg, err
	}

	msg = slack.MsgOptionBlocks(
		headerSection,
		prjBlock,
	)

	return msg, nil
}

func getDeploymentConfirmedBlock(clusterState string) ([]slack.MsgOption, error) {
	var msgData []slack.MsgOption

	confirmBlock := common.GetTxtInputBlock("hpa_confirm", "Confirm Deployment Request", "please type *Confirm* to approve this request")

	approveBlock := common.GetAprroveBtn("deployment_approve_scale_btn")

	msgHpaData := slack.MsgOptionText(clusterState, true)

	msgData = append(msgData, msgHpaData)
	msgConfirmBlock := slack.MsgOptionBlocks(confirmBlock, approveBlock)
	msgData = append(msgData, msgConfirmBlock)

	return msgData, nil
}

func getDeploymentFindBlock() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \n", false, false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("deployment_find_input", "Enter deployment need to find:", "Example:\nbulma")
	button := common.GetAprroveBtn("submit_deploy_find_btn")

	//fmt.Println(ognTeams)

	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		button,
	)

	return msg, nil
}

func getDeploymentAddBlock() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEnter deployment need to add with format following:\n"+
		"`cluster@project@namespace@deployment=activeForBot|normal replicas|events replicas`\nOr\n"+
		"`| cluster | project | namespace | deployment | activeForBot | normalreplicas | events replicas |`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("deployment_input", "Write input there", "Example:\ndev@checkout@default@milo=enable|1|2\n|devquen|over|time|too much|=disable|99|99|")
	button := common.GetAprroveBtn("submit_deploy_add_btn")

	//fmt.Println(ognTeams)

	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		button,
	)

	return msg, nil
}

func getDeploymentEditBlock() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEnter deployment need to update with format following:\n"+
		"`cluster@project@namespace@deployment=activeForBot|normal replicas|events replicas`\nOr\n"+
		"`|cluster|project|namespace|deployment|activeForBot|normalreplicas|events replicas|`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("deployment_input", "Write input there", "Example:\ndev@checkout@default@milo=enable|1|2\n|devquen|over|time|too much|=disable|99|99|")
	button := common.GetAprroveBtn("submit_deploy_edit_btn")

	//fmt.Println(ognTeams)

	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		button,
	)

	return msg, nil
}

func GetScaleManuallyBlock() (slack.MsgOption, error) {
	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEnter deployment need to scale manually \n(if it is deployment, set scale pod = min replicas, else edit hpa = min max input):\n"+
		"`| cluster | project | namespace | deployment |  min replicas | max replicas |`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputScale := common.GetMultiLinesInputBlock("scale_manual_input", "Write deploy ment", "example:\n|dev| checkout | default | milo | 2 | 2|\n|dev| checkout | default | milo-saver | 3 | 3 |")

	btnApprove := common.GetAprroveBtn("scale_manual_approve")
	msg = slack.MsgOptionBlocks(
		headerSection,
		inputScale,
		btnApprove,
	)

	return msg, nil
}

func getHpaMultiEditBlock() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response: \nEnter hpa need to add with format following:\n"+
		"`cluster@project@namespace@deployment=activeForBot | normal min replicas |normal max replicas |events min replicas | events max replicas `\nOr\n"+
		"`| cluster | project | namespace | deployment | activeForBot | normalMinReplicas | normalMaxReplicas | eventMinReplicas | eventMaxreplicas |`\n",
		false,
		false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	inputBlock := common.GetMultiLinesInputBlock("input", "Write input there", "Example:\ndev@checkout@milo-ns@milo=enable|1|2|3|4|\n|devquen|quota|garot@kaka|disable|1|3|5|7|")
	addUserButton := common.GetAprroveBtn("submit_hpa_multi_edit_btn")

	//fmt.Println(ognTeams)

	msg = slack.MsgOptionBlocks(
		headerSection,
		inputBlock,
		addUserButton,
	)

	return msg, nil
}

func getHpaConfirmBlock(clusterState string) ([]slack.MsgOption, error) {
	var msgData []slack.MsgOption

	confirmBlock := common.GetTxtInputBlock("hpa_confirm", "Confirm HPA Request", "please type *Confirm* to approve this request")

	approveBlock := common.GetAprroveBtn("hpa_approve_scale_btn")

	msgHpaData := slack.MsgOptionText(clusterState, true)

	msgData = append(msgData, msgHpaData)
	msgConfirmBlock := slack.MsgOptionBlocks(confirmBlock, approveBlock)
	msgData = append(msgData, msgConfirmBlock)

	return msgData, nil
}

func CreateHpaResponseBlock(input string) (slack.MsgOption, error) {

	var msg slack.MsgOption

	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	godotenv.Load(".env")

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	// Find and read the config file
	if err != nil { // Handle errors reading the config file
		return msg, err
	}

	keys := v.AllKeys()

	valueInput := v.GetString(input)

	hpa, err := common.GetSelectedOptionBlock(keys, input, "select a hpa", "hpa_options", "")

	if err != nil {
		return msg, err
	}

	data, err := getHpaValue(valueInput)

	fmt.Println(data)

	if err != nil {
		return msg, err
	}

	var inputForEnableHpaBot []string
	inputForEnableHpaBot = append(inputForEnableHpaBot, "enable")
	inputForEnableHpaBot = append(inputForEnableHpaBot, "disable")

	fmt.Println("Data :", data.Enabled)
	enableForBot, err := common.GetSelectedOptionBlock(inputForEnableHpaBot, data.Enabled, "enable auto hpa", "enable_bot_hpa", "enable: ")

	if err != nil {
		return msg, err
	}

	curMinRep, err := common.GetSelectedOptionsNumberBlock(100, data.MinReplicas, "Cur MinRep", "cur_min_rep")
	if err != nil {
		return msg, err
	}
	curMaxRep, err := common.GetSelectedOptionsNumberBlock(100, data.MaxReplicas, "Cur MaxRep", "cur_max_rep")
	if err != nil {
		return msg, err
	}

	minNorRep, err := common.GetSelectedOptionsNumberBlock(100, data.NormalMinReplicas, "MinNor", "min_nor_rep")
	if err != nil {
		return msg, err
	}

	maxNorRep, err := common.GetSelectedOptionsNumberBlock(100, data.NormalMaxReplicas, "MaxNor", "max_nor_rep")
	if err != nil {
		return msg, err
	}

	minEventRep, err := common.GetSelectedOptionsNumberBlock(100, data.EventMinReplicas, "MinEvent", "min_event_rep")
	if err != nil {
		return msg, err
	}

	maxEventRep, err := common.GetSelectedOptionsNumberBlock(100, data.EventMaxReplicas, "MaxEvent", "max_event_rep")
	if err != nil {
		return msg, err
	}

	hpaBlock := slack.NewActionBlock("hpa_options", hpa)

	repBlock := slack.NewActionBlock("rep_options", enableForBot, curMinRep, curMaxRep)
	rep2Block := slack.NewActionBlock("rep2_options", minNorRep, maxNorRep, minEventRep, maxEventRep)
	editHpaBtn := common.GetAprroveBtn("edit_hpa_btn")

	msg = slack.MsgOptionBlocks(
		headerSection,
		hpaBlock,
		repBlock,
		rep2Block,
		editHpaBtn,
	)

	return msg, nil
}

func GetHpaEditBlock() (slack.MsgOption, error) {

	var msg slack.MsgOption
	headerText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerSection := slack.NewSectionBlock(headerText, nil, nil)

	clusters, err := getClusters()

	if err != nil {
		return msg, err
	}

	var clusterArr []string
	for _, cluster := range clusters.Data {
		clusterArr = append(clusterArr, cluster.Name)
	}
	hpa, err := common.GetOptionsBlock(clusterArr, "static_select", "Choose a cluster", "hpa_edit_cluster_choose")
	if err != nil {
		return msg, err
	}

	hpaBlock := slack.NewActionBlock("hpa_edit_choose", hpa)

	if err != nil {
		return msg, err
	}

	//editHpaBtn := common.GetAprroveBtn("edit_hpa_btn")

	msg = slack.MsgOptionBlocks(
		headerSection,
		hpaBlock,
		//repBlock,
		//rep2Block,
		//editHpaBtn,
	)

	return msg, nil
}

func GetResetUserPwdBlock() (slack.MsgOption, error) {
	var block slack.MsgOption
	headerGitText := slack.NewTextBlockObject("mrkdwn", ":mag: Bot response:", false, false)
	headerGitSection := slack.NewSectionBlock(headerGitText, nil, nil)

	inputBlock := common.GetTxtInputBlock("user_name", "Enter rancher user name:", "Ex: xuan.can")

	addUserButton := common.GetAprroveBtn("submit_reset_rancher_pwd_btn")
	block = slack.MsgOptionBlocks(
		headerGitSection,
		inputBlock,
		addUserButton,
	)

	return block, nil
}

func GetRancherOptionBlock() (*slack.ActionBlock, error) {

	var block *slack.ActionBlock
	//begin create cluster option
	clusters, err := GetRancherData("clusters")

	if err != nil {
		fmt.Printf("Some things Error in getting clusters")
		return block, err

	}

	clusterOption, err := createRancherOptionsBlock(clusters, "", "clusterBlock")

	if err != nil {
		fmt.Println("debug cluster option...")
		return block, err
	}

	//end create cluster option

	//begin create clusterRole Option
	clusterProjectsRoles, err := GetRancherData("clusterProjectRoles")

	if err != nil {
		fmt.Printf("Some things Error")
		return block, err
	}

	clusterRolesOption, err := createRancherOptionsBlock(clusterProjectsRoles, "cluster", "clusterRoleBlock")

	if err != nil {
		fmt.Println("debug...")
		return block, err
	}

	//end create clusterRole Option

	//begin create project option
	projects, err := GetRancherData("projects")

	if err != nil {
		fmt.Printf("Some things Error")
		return block, err
	}
	// //projectRoles := rancher.GetRancherData("projectRoles")

	projectOption, err := createRancherOptionsBlock(projects, "", "projectBlock")

	if err != nil {
		fmt.Printf("Some things Error")
		return block, err
	}

	//end create project option

	//begin create projectsRole Option

	projectRolesOption, err := createRancherOptionsBlock(clusterProjectsRoles, "project", "projectRoleBlock")

	if err != nil {
		fmt.Println("debug...")
		return block, err
	}

	//end create clusterRole Option

	//fmt.Println(projectRoles.String())
	block = slack.NewActionBlock("options", clusterOption, clusterRolesOption, projectOption, projectRolesOption)

	return block, err
}

func createRancherOptionsBlock(datas []RancherObject, roles string, blockType string) (*slack.SelectBlockElement, error) {

	var ranObj RancherObject

	//for loop to get options

	options := []*slack.OptionBlockObject{}

	// flag check Role

	// init a initalOptionBlock

	var initBtn *slack.TextBlockObject
	var initialOption *slack.OptionBlockObject

	for i := 0; i < len(datas); i++ {
		ranObj = datas[i]
		id := GetFieldString(&ranObj, "id")
		name := GetFieldString(&ranObj, "name")

		//if context is None, => "" is return
		context := GetFieldString(&ranObj, "context")

		tempTxt := slack.NewTextBlockObject("plain_text", name, false, false)
		tempOption := slack.NewOptionBlockObject(id, tempTxt, nil)

		if blockType == "clusterBlock" {
			if name != "dev" {
				continue
			}
		}

		if blockType == "clusterRoleBlock" {
			if name != "Cluster Viewer" {
				continue
			}
		}

		if blockType == "projectRoleBlock" {

			checkContain := false
			if strings.Contains(name, "Tiki") {
				checkContain = true
			}

			if strings.Contains(name, "View") {
				checkContain = true
			}

			if !checkContain {
				continue
			}
		}

		if roles == "" {
			options = append(options, tempOption)
			if name == "dev" || name == "marketplace" {
				//fmt.Println("Go to option blocks with name: ", name)
				initBtn = slack.NewTextBlockObject("plain_text", name, true, false)
				initialOption = slack.NewOptionBlockObject(id, initBtn, nil)
			}
		}

		if roles == "cluster" && context == "cluster" {
			options = append(options, tempOption)
			if name == "Cluster Viewer" {
				//fmt.Println("Go to option blocks with name: ", name)
				initBtn = slack.NewTextBlockObject("plain_text", name, true, false)
				initialOption = slack.NewOptionBlockObject(id, initBtn, nil)
			}
		}

		//project and cluster have the same path but context
		if roles == "project" && context == "project" {

			options = append(options, tempOption)

			if name == "Tiki Developer" {
				//fmt.Println("Go to option blocks with name: ", name)
				initBtn = slack.NewTextBlockObject("plain_text", name, true, false)
				initialOption = slack.NewOptionBlockObject(id, initBtn, nil)
			}

		}

	}
	//manageTxt := slack.NewTextBlockObject("plain_text", "Manage", true, false)

	availableOption := common.NewOptionsSelectBlockElementWithInitOptions("static_select", blockType, initialOption, options...)
	//optionBlock := slack.NewActionBlock("", availableOption)

	err := errors.New("error: some things when wrong")

	print(err)
	return availableOption, nil
}
