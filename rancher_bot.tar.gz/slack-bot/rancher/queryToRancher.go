package rancher

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"

	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

func SendRollbackToRancher(url, deploymentName string) error {
	apiUrl := os.Getenv("ENDPOINT")
	path := ""
	replicaSetID := ""
	if strings.Contains(url, apiUrl) {
		pathSplit := strings.Split(url, apiUrl)

		if len(pathSplit) != 2 {
			return errors.New("url redeploy not correct " + url)
		}
		path = pathSplit[1]

		replicaSetID = strings.Split(strings.Split(path, "workloads/")[1], "?action=")[0]

		path = strings.Replace(path, "replicaset", "deployment", 1)
		splitWorkload := strings.Split(path, "/workloads/")
		workloadID := "deployment:" + strings.Split(replicaSetID, ":")[1] + ":" + deploymentName
		path = splitWorkload[0] + "/workloads/" + workloadID + "?action=rollback"
		log.Println(path, replicaSetID)

	}

	if path == "" || replicaSetID == "" {
		return errors.New("url redeploy not correct " + url)
	}

	data := make(map[string]interface{})

	//fmt.Printf("%+v", deployment)

	data["replicaSetId"] = replicaSetID
	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("POST", path, string(json_req))

	if err != nil {
		return err
	}

	// TODO: check err
	defer resp.Body.Close()
	fmt.Print(err)
	if err != nil {
		return err
	}

	if resp.StatusCode != 200 {
		return errors.New("Error query to rancher with status code " + strconv.Itoa(resp.StatusCode))
	}

	return nil

}

func getRevisionData(deployment Data) (RevisionContainers, error) {
	var revisionData RevisionContainers

	log.Printf("%+v", deployment)

	resp, err := initRancherHttpReq("GET", "/project/"+deployment.ProjectID+"/workloads/deployment"+":"+deployment.NamespaceId+":"+deployment.Name+"/revisions", `{}`)

	if err != nil {
		return revisionData, err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return revisionData, err
	}
	json.Unmarshal(body, &revisionData)

	//log.Println(string(body))
	//log.Println(revisionData)

	if len(revisionData.RevisionData) == 0 {
		return revisionData, errors.New("cannot get any data of deployment " + deployment.Name)
	}

	return revisionData, nil
}

func GetRancherContainers(deployment Data) (ContainerData, map[string]interface{}, error) {

	var envRancher map[string]interface{}
	var containers DeploymentContainers
	var curContainer ContainerData

	//log.Println("project log", deployment.ProjectID, deployment.NamespaceId, deployment.Name)

	if deployment.Type == "" {
		deployment.Type = "deployment"
	}
	resp, err := initRancherHttpReq("GET", "/project/"+deployment.ProjectID+"/workloads/"+deployment.Type+":"+deployment.NamespaceId+":"+deployment.Name, `{}`)

	if err != nil {
		return curContainer, envRancher, err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return curContainer, envRancher, err
	}
	json.Unmarshal(body, &containers)

	//log.Printf("%+v", containers)
	if len(containers.Container) > 0 {

		for _, container := range containers.Container {

			log.Println("Log con, ", container.Name)
			if container.Name == deployment.Name {
				curContainer = container
				break
			}
		}

		if curContainer.Name == "" {
			return curContainer, envRancher, errors.New("cannot find workload ID " + deployment.Name)
		}

	} else {
		return curContainer, envRancher, errors.New("cannot find container " + deployment.Name + " please make sure container is running then retry")
	}

	//get env rancher
	var result map[string]interface{}
	json.Unmarshal(body, &result)
	rancherData := result["containers"].([]interface{})

	for _, data := range rancherData {
		rancherData := data.(map[string]interface{})

		if rancherData["name"] == deployment.Name {

			//envRancherData := rancherData["environment"]
			envRancherData := rancherData["environment"]

			//break if enviroments data is nil
			if envRancherData == nil {
				log.Println("Not found any env")
				break
			}
			envRancher = envRancherData.(map[string]interface{})
			// log.Println(convertMap)
			//envRancher = envRancherData.(map[string]interface{})
			break
		}
	}
	//log.Println("Vault: ", rancherData[1])

	//log.Println("Rancher env is ", envRancher)
	return curContainer, envRancher, nil
}

func redeployDeploymentWithProjectIdAndDeploymentID(projectID, deploymentID string) error {
	resp, err := initRancherHttpReq("POST", "/project/"+projectID+"/workloads/"+deploymentID+"?action=redeploy", `{}`)

	if err != nil {
		return err
	}
	log.Println(resp.StatusCode)

	//fmt.Println("Still here")

	// TODO: check err
	defer resp.Body.Close()
	fmt.Print(err)
	if err != nil {
		return err
	}

	if resp.StatusCode != 200 {
		return errors.New("Error query to rancher with status code " + strconv.Itoa(resp.StatusCode))
	}

	return nil
}

func queryToRedeployDeployment(deployment Deployment) int {

	//fmt.Printf("%+v", deployment)

	resp, err := initRancherHttpReq("POST", "/project/"+deployment.ProjectID+"/workloads/"+deployment.ID+"?action=redeploy", `{}`)

	log.Println(resp.StatusCode)

	//fmt.Println("Still here")

	// TODO: check err
	defer resp.Body.Close()
	fmt.Print(err)
	if err != nil {
		return 500
	}

	return resp.StatusCode

}

func updateDeploymentDataCommand(deployment Deployment) int {
	data := make(map[string]interface{})

	//fmt.Printf("%+v", deployment)

	data["name"] = deployment.Name

	data["namespaceId"] = deployment.NamespaceId

	data["scale"] = deployment.Scale
	//data["projectId"] = hpaData.ProjectID

	json_req, _ := json.Marshal(data)

	resp, err := initRancherHttpReq("PUT", "/project/"+deployment.ProjectID+"/workloads/deployment:"+deployment.NamespaceId+":"+deployment.Name, string(json_req))

	log.Println(resp.StatusCode)

	//fmt.Println("Still here")

	// TODO: check err
	defer resp.Body.Close()
	fmt.Print(err)
	if err != nil {
		return 500
	}

	return resp.StatusCode
}
func updateHpaDataCommand(hpaData Data) int {

	var err error
	data := make(map[string]interface{})
	data["id"] = strings.ReplaceAll(hpaData.ID, "@", ":")
	data["maxReplicas"] = hpaData.TempMaxReplicas
	data["minReplicas"] = hpaData.TempMinReplicas
	data["projectId"] = hpaData.ProjectID

	data["workloadId"], err = getWorkloadId(hpaData)

	if err != nil {
		return 0
	}
	json_req, _ := json.Marshal(data)

	//log.Println("path: /" + hpaData.ProjectID + "/horizontalPodAutoscalers/" + hpaData.ID)
	resp, err := initRancherHttpReq("PUT", "/project/"+hpaData.ProjectID+"/horizontalPodAutoscalers/"+strings.ReplaceAll(hpaData.ID, "@", ":"), string(json_req))

	log.Println(resp.StatusCode)

	//fmt.Println("Still here")

	// TODO: check err
	defer resp.Body.Close()
	fmt.Print(err)
	if err != nil {
		return 500
	}

	return resp.StatusCode
}

func getWorkloadId(hpaData Data) (string, error) {
	var hpas RancherHpas
	resp, err := initRancherHttpReq("GET", "/projects/"+hpaData.ProjectID+"/horizontalpodautoscalers?id="+strings.ReplaceAll(hpaData.ID, "@", ":"), `{}`)

	if err != nil {
		return "", err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	json.Unmarshal(body, &hpas)
	if len(hpas.Data) > 0 {
		if hpas.Data[0].ID != "" {

			output := hpas.Data[0].WorkloadID
			return output, nil
		}
	}

	return "", errors.New("cannot find workload ID")
}

func queryRancherHpaWithDeployment(deploymment Deployment) (bool, error) {
	var hpas RancherHpas

	wordloadID := deploymment.ID

	resp, err := initRancherHttpReq("GET", "/projects/"+deploymment.ProjectID+"/horizontalpodautoscalers?workloadId="+wordloadID, `{}`)

	if err != nil {
		return false, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	json.Unmarshal(body, &hpas)
	//fmt.Println("Still here")

	if len(hpas.Data) > 0 {
		if hpas.Data[0].ID != "" {
			return true, nil
		}
	}

	defer resp.Body.Close()

	//log.Println("checkHpa exist status code", resp.StatusCode)
	//fmt.Println(hpas)

	return false, nil
}

func getStatefulSetWithProjectId(projectID, statefulSetName, namespaceID string) (RancherDeployment, error) {
	var deployments RancherDeployment

	//log.Println("Project id", projectID, deploymentName, namespaceID)
	var err error
	var resp *http.Response

	deployType := "statefulsets"

	if statefulSetName == "" || namespaceID == "" {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/"+deployType, `{}`)
	} else {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/"+deployType+"?name="+statefulSetName+"&namespaceId="+namespaceID, `{}`)
	}

	if err != nil {
		return deployments, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return deployments, err
	}
	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &deployments)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(hpas)
	if resp.StatusCode == 200 {
		return deployments, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get deployment list of " + projectID
		return deployments, errors.New(errmsg)
	}
}

func getDeploymentWithProjectId(projectID, deploymentName, namespaceID string) (RancherDeployment, error) {
	var deployments RancherDeployment

	//log.Println("Project id", projectID, deploymentName, namespaceID)
	var err error
	var resp *http.Response

	deployType := "deployment"

	if deploymentName == "" || namespaceID == "" {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/"+deployType, `{}`)
	} else {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectID+"/"+deployType+"?name="+deploymentName+"&namespaceId="+namespaceID, `{}`)
	}

	if err != nil {
		return deployments, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return deployments, err
	}
	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &deployments)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(hpas)
	if resp.StatusCode == 200 {
		return deployments, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get deployment list of " + projectID
		return deployments, errors.New(errmsg)
	}
}

func getHpaWithProjectId(projectId string, wordloadID string) (RancherHpas, error) {
	var hpas RancherHpas
	var resp *http.Response
	var err error
	if wordloadID == "" {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectId+"/horizontalPodAutoscalers", `{}`)
	} else {
		resp, err = initRancherHttpReq("GET", "/projects/"+projectId+"/horizontalPodAutoscalers?workloadId="+wordloadID, `{}`)
	}

	if err != nil {
		return hpas, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return hpas, err
	}

	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &hpas)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(hpas)
	if resp.StatusCode == 200 {
		return hpas, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get hpas list of " + projectId
		return hpas, errors.New(errmsg)
	}
}

func GetClusterIdWithClusterName(clusterName string) (string, error) {
	return getClusterIdWithClusterName(clusterName)
}

func getClusterIdWithClusterName(clusterName string) (string, error) {
	var clusters RancherClusters
	resp, err := initRancherHttpReq("GET", "/clusters?name="+clusterName, `{}`)

	if err != nil {
		return "", err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return "", err
	}
	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &clusters)
	//fmt.Println(teams)

	if len(clusters.Data) < 1 {
		errmsg := "cluster not found in get cluster " + clusterName
		return "", errors.New(errmsg)
	}

	defer resp.Body.Close()

	//fmt.Println(projects)
	if resp.StatusCode == 200 {
		return clusters.Data[0].ID, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get cluster ID"
		return "", errors.New(errmsg)
	}

}

func GetProjectWithProjectID(projectID string) (RancherProject, error) {
	var rancherProject RancherProject

	resp, err := initRancherHttpReq("GET", "/projects/"+projectID, `{}`)

	if err != nil {
		return rancherProject, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return rancherProject, err
	}

	json.Unmarshal(body, &rancherProject)
	//fmt.Println(teams)

	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		return rancherProject, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get projects id " + projectID
		return rancherProject, errors.New(errmsg)
	}
}

func GetProjectWithClusterID(projectName string, clusterID string) (RancherProjects, error) {
	return getProjectWithClusterID(projectName, clusterID)
}

func getProjectWithClusterID(projectName string, clusterID string) (RancherProjects, error) {
	var projects RancherProjects
	var err error
	var resp *http.Response

	if projectName != "" && clusterID != "" {
		resp, err = initRancherHttpReq("GET", "/projects?name="+projectName+"&clusterId="+clusterID, `{}`)
	} else if projectName == "" {
		resp, err = initRancherHttpReq("GET", "/projects?clusterId="+clusterID, `{}`)
	}
	//resp, err = initRancherHttpReq("GET", "/projects?name="+projectName+"&clusterId="+clusterID, `{}`)

	if err != nil {
		return projects, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &projects)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(projects)
	if resp.StatusCode == 200 {
		return projects, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get projects list"
		return projects, errors.New(errmsg)
	}

}

func getClusters() (RancherClusters, error) {
	var clusters RancherClusters

	resp, err := initRancherHttpReq("GET", "/clusters?sort=description", `{}`)

	if err != nil {
		return clusters, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return clusters, err
	}

	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &clusters)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(projects)
	if resp.StatusCode == 200 {
		return clusters, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get projects list"
		return clusters, errors.New(errmsg)
	}
}
func getProjects() (RancherProjects, error) {
	var projects RancherProjects

	resp, err := initRancherHttpReq("GET", "/projects?sort=description", `{}`)

	if err != nil {
		return projects, err
	}

	body, err := ioutil.ReadAll(resp.Body)

	//fmt.Println("Still here")

	//fmt.Printf("Response: \n %s", body)

	json.Unmarshal(body, &projects)
	//fmt.Println(teams)

	defer resp.Body.Close()

	//fmt.Println(projects)
	if resp.StatusCode == 200 {
		return projects, nil
	} else {
		errmsg := "error code " + strconv.Itoa(resp.StatusCode) + " in get projects list"
		return projects, errors.New(errmsg)
	}
}

func initRancherHttpReq(method string, querryCmd string, readerInput string) (*http.Response, error) {

	var httpResp *http.Response
	godotenv.Load(".env")

	apiUrl := os.Getenv("ENDPOINT")
	querryCommmand := apiUrl + querryCmd

	accessKey := os.Getenv("ACCESS_KEY")

	secretKey := os.Getenv("SECRET_KEY")

	client := &http.Client{Timeout: 10 * time.Second}

	reader := strings.NewReader(readerInput)

	request, err := http.NewRequest(method, querryCommmand, reader)

	if err != nil {
		fmt.Println(err)
		return httpResp, errors.New("could not run request to rancher")
	}

	request.Header.Add("Content-Type", "application/json")
	request.Header.Add("Accept", "application/json")
	request.SetBasicAuth(accessKey, secretKey)

	httpResp, err = client.Do(request)

	if err != nil {
		return httpResp, errors.New("could not run request to rancher, please check connection")
	}

	return httpResp, nil
}
