package rancher

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/common"
	"sort"
	"strconv"
	"strings"

	"github.com/jedib0t/go-pretty/table"
	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/spf13/viper"
)

func HandleDeploymentUpdateLocalFile() error {
	//first, read from local file to find deployment

	log.Println("Update local file")
	var deployments []Deployment
	file_name := os.Getenv("DEPLOYMENT_FIND_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("file not exist, create an empty file")
	}

	//clear data
	err = HandleClearLocalFile("deployment")
	if err != nil {
		return err
	}
	clusters, err := getClusters()
	if err != nil {
		return err
	}

	projects, err := getProjects()

	if err != nil {
		return err
	}

	projects = enrichProjects(clusters, projects)

	for _, project := range projects.Data {

		if strings.Contains(project.ID, "c-rm8np") {
			continue
		}

		//get deployment
		curdeployments, err := getDeploymentWithProjectId(project.ID, "", "")
		if err != nil {
			return err
		}

		if len(curdeployments.Deployment) > 0 {
			for _, tempDeployment := range curdeployments.Deployment {
				tempDeployment.ClusterName = project.ClusterName
				tempDeployment.ProjectName = project.Name
				tempDeployment.Type = "deployment"
				deployments = append(deployments, tempDeployment)
			}
		}

		//get stateful sets
		statefulSets, err := getStatefulSetWithProjectID(project.ID, "", "")
		if err != nil {
			return err
		}

		if len(statefulSets.Deployment) > 0 {
			for _, tempStatefulSet := range statefulSets.Deployment {
				tempStatefulSet.ClusterName = project.ClusterName
				tempStatefulSet.ProjectName = project.Name
				tempStatefulSet.Type = "statefulset"

				log.Printf("current stateful set: %+v", tempStatefulSet)

				deployments = append(deployments, tempStatefulSet)
			}
		}

	}

	for _, deployment := range deployments {
		key := deployment.ClusterName + "@" + deployment.ProjectName + "@" + deployment.NamespaceId + "@" + deployment.Name + "@" + deployment.ProjectID + "@" + deployment.Type

		value := ""
		if deployment.Type == "deployment" {
			value = deployment.State + "|" + strconv.Itoa(deployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(deployment.DeploymentStatus.Replicas)

		} else {

			log.Println("is stateful set", deployment.StatefulSetStatus)

			value = deployment.State + "|" + strconv.Itoa(deployment.StatefulSetStatus.ReadyReplicas) + "|" + strconv.Itoa(deployment.StatefulSetStatus.Replicas)

		}

		v.Set(key, value)
	}

	v.WriteConfig()
	//write to file

	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil
}

func SendRedeploDeploymentToRancher(data string) error {
	var statusCode int

	fmt.Println("Input ", data)

	var deployment Deployment

	dataSplit := strings.Split(data, "|")

	deployment.ProjectID = dataSplit[0]
	deployment.ID = dataSplit[1]

	statusCode = queryToRedeployDeployment(deployment)

	if statusCode != 200 {
		return errors.New("error when send deployment update request to rancher")
	}

	return nil
}

func GetRedeployDeploymentData(blockAc map[string]map[string]slack.BlockAction) (string, string, error) {
	var msgBlock strings.Builder
	var outputToSendRancher strings.Builder
	input := blockAc["redeploy_input"]["redeploy_input"].Value

	fmt.Println(input)
	input = strings.TrimSpace(input)
	input = strings.ReplaceAll(input, "'", "")
	input = strings.ReplaceAll(input, "\"", "")

	log.Println(input)
	dataSplit := strings.Split(input, "|")

	if len(dataSplit) != 6 {
		return "", "", errors.New("Data length not connect!!!")
	}

	index := 1
	var deployment Deployment

	deployment.ClusterName = dataSplit[index]
	index++
	deployment.ProjectName = dataSplit[index]
	index++
	deployment.NamespaceId = dataSplit[index]
	index++
	deployment.Name = dataSplit[index]
	index++

	clusterID, err := getClusterIdWithClusterName(deployment.ClusterName)

	if err != nil {
		return "", "", errors.New("Cluster " + deployment.ClusterName + " not found!!!")
	}

	project, err := getProjectWithClusterID(deployment.ProjectName, clusterID)

	if err != nil {
		return "", "", err
	}

	if len(project.Data) != 1 {
		//retry with project name upper case
		log.Println("Check project name", strings.Title(deployment.ProjectName))
		project, err = getProjectWithClusterID(strings.Title(deployment.ProjectName), clusterID)

		if err != nil {
			return "", "", err
		}
	}

	if len(project.Data) != 1 {
		return "", "", errors.New("Project " + deployment.ProjectName + " not found!!!")
	}

	deployment.ProjectID = project.Data[0].ID

	tempDeployment, err := getDeploymentWithProjectId(deployment.ProjectID, deployment.Name, deployment.NamespaceId)

	if len(tempDeployment.Deployment) == 0 {
		return "", "", errors.New("Deployment " + deployment.Name + " not found!!!")
	}

	deployment.ID = tempDeployment.Deployment[0].ID
	deployment.DeploymentStatus.ReadyReplicas = tempDeployment.Deployment[0].DeploymentStatus.ReadyReplicas
	deployment.DeploymentStatus.Replicas = tempDeployment.Deployment[0].DeploymentStatus.Replicas

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	msgBlock.WriteString("```")

	t.AppendHeader(table.Row{"Cluster", "Project", "ID", "Replicas", "Desired Replicas"})

	outputToSendRancher.WriteString(deployment.ProjectID + "|" + deployment.ID)

	t.AppendRow([]interface{}{deployment.ClusterName, deployment.ProjectName, deployment.ID,
		deployment.DeploymentStatus.ReadyReplicas, deployment.DeploymentStatus.Replicas})

	msgBlock.WriteString(t.Render())

	msgBlock.WriteString("```")
	return msgBlock.String(), outputToSendRancher.String(), nil
}

func SendScaleManuallyToRancher(data string) error {
	var statusCode int
	var err error

	fmt.Println("Input ", data)
	deployment := strings.Split(data, " ")

	println("length of hpa data: ", len(deployment))
	for i := range deployment {
		if deployment[i] == "" {
			continue
		}
		splitData := strings.Split(deployment[i], "=")
		if len(splitData) != 2 {
			return errors.New("somethings wrong with data")
		}
		key := splitData[0]
		value := splitData[1]

		keySplit := strings.Split(key, "@")
		valueSplit := strings.Split(value, "|")

		if len(valueSplit) != 3 {
			return errors.New("somethings wrong with data value")
		}

		//update deployment
		if valueSplit[0] == "false" {
			var deployment Deployment

			if len(keySplit) != 2 {
				return errors.New("somethings wrong with data value")
			}

			deployment.ProjectID = keySplit[0]
			deployment.ID = keySplit[1]

			deployment.Name = strings.Split(deployment.ID, ":")[2]
			deployment.NamespaceId = strings.Split(deployment.ID, ":")[1]
			deployment.Scale, err = strconv.Atoi(valueSplit[1])

			if err != nil {
				return err
			}

			statusCode = updateDeploymentDataCommand(deployment)

		} else if valueSplit[0] == "true" {
			var hpa Data

			if len(keySplit) != 2 {
				return errors.New("somethings wrong with data value")
			}

			hpa.ProjectID = keySplit[0]
			hpa.ID = strings.SplitAfterN(keySplit[1], ":", 2)[1]
			hpa.TempMinReplicas, err = strconv.Atoi(valueSplit[1])
			if err != nil {
				return err
			}

			hpa.TempMaxReplicas, err = strconv.Atoi(valueSplit[2])
			if err != nil {
				return err
			}

			statusCode = updateHpaDataCommand(hpa)
		}

		if statusCode != 200 {
			return errors.New("error when send deployment update request to rancher")
		}
	}

	return nil
}

func GetScaleManuallyData(blockAc map[string]map[string]slack.BlockAction) (string, string, error) {
	var msg string
	var err error
	var outputToSendRancher strings.Builder
	input := blockAc["scale_manual_input"]["scale_manual_input"].Value

	fmt.Println(input)
	strimInput := strings.TrimSpace(input)
	strimInput = strings.ReplaceAll(input, "'", "")
	strimInput = strings.ReplaceAll(input, "\"", "")

	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return msg, "", errors.New("Notthing to do!!!")
	}

	if len(lines) > 25 {
		return msg, "", errors.New("Currently Support maximum 25 lines!!!")
	}

	var output strings.Builder

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	output.WriteString("```")

	t.AppendHeader(table.Row{"Cluster", "Project", "ID", "Is HPA", "Current Replicas", "Min Replicas", "Max Replicas"})

	for _, line := range lines {
		var tempDeployment Data

		strimInput := strings.TrimSpace(line)
		strimInput = strings.ReplaceAll(strimInput, "'", "")
		strimInput = strings.ReplaceAll(strimInput, "\"", "")
		value := strings.Split(strimInput, "|")

		if len(value) == 8 {

			index := 1
			tempDeployment.ClusterName = value[index]
			index++
			tempDeployment.ProjectName = value[index]
			index++
			tempDeployment.NamespaceId = value[index]
			index++
			tempDeployment.Name = value[index]
			tempDeployment.ID = "deployment:" + tempDeployment.NamespaceId + ":" + value[index]
			index++
			tempDeployment.MinReplicas, err = strconv.Atoi(value[index])
			if err != nil || tempDeployment.MinReplicas < 1 || tempDeployment.MinReplicas > 1000 {
				return msg, "", errors.New("input data not correct for min replicas :" + value[index])
			}
			index++
			tempDeployment.MaxReplicas, err = strconv.Atoi(value[index])
			if err != nil || tempDeployment.MaxReplicas < 1 || tempDeployment.MaxReplicas > 1000 || tempDeployment.MinReplicas > tempDeployment.MaxReplicas {
				return msg, "", errors.New("input data not correct for max replicas: " + value[index])
			}

			clusterID, err := getClusterIdWithClusterName(tempDeployment.ClusterName)
			if err != nil {
				return msg, "", errors.New("Cannot get cluster ID with cluster Name " + tempDeployment.ClusterName)
			}

			project, err := getProjectWithClusterID(tempDeployment.ProjectName, clusterID)

			if len(project.Data) == 0 || project.Data == nil {
				//retry with project name upper case
				project, err = getProjectWithClusterID(strings.Title(tempDeployment.ProjectName), clusterID)

				if err != nil {
					return "", "", err
				}
			}

			if err != nil {
				return msg, "", errors.New("Cannot get project ID with project Name " + tempDeployment.ProjectName)
			}

			if len(project.Data) != 1 {
				return msg, "", errors.New("Cannot get project ID with project Name " + tempDeployment.ProjectName)
			}

			tempDeployment.ProjectID = project.Data[0].ID

			getHpa, err := getHpaWithProjectId(tempDeployment.ProjectID, tempDeployment.ID)

			if err != nil {
				return msg, "", errors.New("Error when getting project hpa")
			}

			if len(getHpa.Data) == 1 {
				tempDeployment.IsHpa = true
				tempDeployment.CurrentReplicas = getHpa.Data[0].CurrentReplicas
			}

			if tempDeployment.IsHpa == false {
				rancherDeployment, err := getDeploymentWithProjectId(tempDeployment.ProjectID, tempDeployment.Name, tempDeployment.NamespaceId)

				if err != nil {
					return msg, "", errors.New("Error when getting deployment")
				}

				if len(rancherDeployment.Deployment) != 1 {
					return msg, "", errors.New("Error when getting deployment")
				}
				tempDeployment.CurrentReplicas = rancherDeployment.Deployment[0].DeploymentStatus.ReadyReplicas
			}

			t.AppendRow([]interface{}{tempDeployment.ClusterName, tempDeployment.ProjectName, tempDeployment.ID,
				tempDeployment.IsHpa, tempDeployment.CurrentReplicas, tempDeployment.MinReplicas, tempDeployment.MaxReplicas})

			outputToSendRancher.WriteString(tempDeployment.ProjectID + "@" + tempDeployment.ID + "=" + strconv.FormatBool(tempDeployment.IsHpa) + "|" + strconv.Itoa(tempDeployment.MinReplicas) + "|" + strconv.Itoa(tempDeployment.MaxReplicas) + " \n")

		} else {
			return msg, "", errors.New("input data not correct")
		}

	}

	output.WriteString(t.Render())
	output.WriteString("```")

	msg = output.String()
	return msg, outputToSendRancher.String(), nil
}

func getDeploymentConfirmedValue(deploymentData string) (Deployment, error) {
	var deployment Deployment
	var err error
	splitInput := strings.Split(deploymentData, "=")

	if deploymentData == "" {
		return deployment, errors.New("nothing to do!!!")
	}

	if len(splitInput) != 2 {
		return deployment, errors.New("somethings wrong with data " + deploymentData)
	}

	key := strings.Split(splitInput[0], "@")
	if len(key) != 4 {
		return deployment, errors.New("somethings wrong with data " + deploymentData)
	}

	deployment.ClusterName = key[0]
	deployment.ProjectName = key[1]
	deployment.NamespaceId = key[2]
	deployment.Name = key[3]

	value := strings.Split(splitInput[1], "|")

	if len(value) != 3 {
		return deployment, errors.New("somethings wrong with data " + deploymentData)
	}

	deployment.Scale, err = strconv.Atoi(value[2])

	if err != nil {
		return deployment, err
	}

	return deployment, nil
}

func SendDeploymentDataToRancher(deploymentsInput string) error {
	var statusCode int
	deployment := strings.Split(deploymentsInput, " ")

	println("length of hpa data: ", len(deployment))
	for i := range deployment {

		deploymentData, err := getDeploymentConfirmedValue(deployment[i])

		if err != nil {
			return err
		}

		if deploymentData.ProjectName == "" {
			return errors.New("cannot get projectName")
		}

		if deploymentData.ClusterName == "" {
			return errors.New("cannot get clusterName")
		}

		if deploymentData.NamespaceId == "" {
			return errors.New("cannot get namespaceID")
		}

		clusterID, err := getClusterIdWithClusterName(deploymentData.ClusterName)
		if err != nil {
			return err
		}
		projects, err := getProjectWithClusterID(deploymentData.ProjectName, clusterID)

		if err != nil {
			return err
		}

		if len(projects.Data) == 0 || projects.Data == nil {
			//retry with project name upper case
			projects, err = getProjectWithClusterID(strings.Title(deploymentData.ProjectName), clusterID)

			if err != nil {
				return err
			}
		}

		if len(projects.Data) == 0 || projects.Data == nil {
			return errors.New("project not found: " + projects.Data[i].Name)
		}

		deploymentData.ProjectID = projects.Data[0].ID

		statusCode = updateDeploymentDataCommand(deploymentData)

		if statusCode != 200 {
			return errors.New("error when send deployment update request to rancher")
		}
	}

	return nil
}

func GetDeploymentScale(scaleType string) ([]slack.MsgOption, string, error) {

	var msgData []slack.MsgOption

	msgTextResponse, dataResponse, err := GetDeploymentList("active", scaleType)

	if err != nil {
		return nil, msgTextResponse, err
	}

	msgData, err = getDeploymentConfirmedBlock(msgTextResponse)

	//msg := slack.MsgOptionText(msgResponse, true)

	if err != nil {
		return msgData, dataResponse, err
	}

	return msgData, dataResponse, nil

}

func GetDeploymentFindInputData(input string) (string, string, string, error) {
	var output strings.Builder
	var deploymentReturnData string
	var deploymentDataReturn string
	//var deployments []Deployment

	input = strings.ToLower(input)
	input = strings.TrimSpace(input)
	input = strings.ReplaceAll(input, "'", "")
	input = strings.ReplaceAll(input, "\"", "")

	// err := common.ValidateInput(input, "name")

	// if err != nil {
	// 	return "", deploymentReturnData, deploymentDataReturn, err
	// }

	//first, read from local file to find deployment

	file_name := os.Getenv("DEPLOYMENT_FIND_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return "File not exist, create an empty file", deploymentReturnData, deploymentDataReturn, nil
	}

	keys := v.AllKeys()

	if len(keys) == 0 {
		err := HandleDeploymentUpdateLocalFile()

		if err != nil {
			return "", "", "", err
		}
		return "Data file is init successfully, please find deployment again", "", deploymentDataReturn, nil

	}

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	output.WriteString("```")
	t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "State", "Current Replica", "Desired Replica"})

	count := 0
	for _, key := range keys {
		if strings.Contains(strings.Split(key, "@")[3], input) {

			count++
			keyData := strings.Split(key, "@")
			if len(keyData) != 6 {
				return "", deploymentReturnData, deploymentDataReturn, errors.New("key value not correct at " + key)
			}

			deployType := keyData[5]
			newValue := ""

			if deployType == "deployment" {
				tempDeployment, err := getDeploymentWithProjectId(keyData[4], keyData[3], keyData[2])

				if err != nil {
					return "", deploymentReturnData, deploymentDataReturn, err
				}

				if len(tempDeployment.Deployment) != 1 {

					if err := os.Truncate(path+"/"+file_name, 0); err != nil {
						log.Printf("Failed to truncate: %v", err)

						return "", deploymentReturnData, deploymentDataReturn, err
					}

					return "Data need to rewrite for changed because of currupt or invalid local key value", "", deploymentDataReturn, nil

				}

				t.AppendRow([]interface{}{keyData[0], keyData[1], keyData[2], keyData[3], tempDeployment.Deployment[0].State,
					tempDeployment.Deployment[0].DeploymentStatus.ReadyReplicas, tempDeployment.Deployment[0].DeploymentStatus.Replicas})

				newValue = tempDeployment.Deployment[0].State + "|" + strconv.Itoa(tempDeployment.Deployment[0].DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(tempDeployment.Deployment[0].DeploymentStatus.Replicas)

				deploymentReturnData += keyData[3] + ","
				deploymentDataReturn = keyData[4] + "|" + keyData[2]
			} else if deployType == "statefulset" {
				tempStatefulSet, err := getStatefulSetWithProjectId(keyData[4], keyData[3], keyData[2])

				if err != nil {
					return "", deploymentReturnData, deploymentDataReturn, err
				}

				if len(tempStatefulSet.Deployment) != 1 {

					if err := os.Truncate(path+"/"+file_name, 0); err != nil {
						log.Printf("Failed to truncate: %v", err)

						return "", deploymentReturnData, deploymentDataReturn, err
					}

					return "Data need to rewrite for changed because of currupt or invalid local key value", "", deploymentDataReturn, nil

				}

				t.AppendRow([]interface{}{keyData[0], keyData[1], keyData[2], keyData[3], tempStatefulSet.Deployment[0].State,
					tempStatefulSet.Deployment[0].StatefulSetStatus.ReadyReplicas, tempStatefulSet.Deployment[0].StatefulSetStatus.Replicas})

				newValue = tempStatefulSet.Deployment[0].State + "|" + strconv.Itoa(tempStatefulSet.Deployment[0].StatefulSetStatus.ReadyReplicas) + "|" + strconv.Itoa(tempStatefulSet.Deployment[0].StatefulSetStatus.Replicas)

				deploymentReturnData += keyData[3] + ","
				deploymentDataReturn = keyData[4] + "|" + keyData[2]

			}

			v.Set(key, newValue)
			if count == 30 {
				break
			}
		}
	}

	//v.WriteConfig()
	//write to file

	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	if count == 0 {

		err = HandleDeploymentUpdateLocalFile()

		if err != nil {
			log.Println(err)
		}

		return "", deploymentReturnData, deploymentDataReturn, errors.New("Not match any deployment, if it's new, please retry after 3 seconds!!!")
	}
	if count == 25 {
		return "", deploymentReturnData, deploymentDataReturn, errors.New("Question is too generic!!!")
	}

	output.WriteString(t.Render())
	output.WriteString("\n```")
	return output.String(), deploymentReturnData, deploymentDataReturn, nil
}

// func GetDeploymentListInputData() (string, error) {

// 	var output strings.Builder

// 	godotenv.Load(".env")

// 	file_name := os.Getenv("DEPLOYMENT_FILE_NAME")
// 	path := os.Getenv("DEPLOYMENT_PATH")
// 	v := viper.New()
// 	v.SetConfigName(file_name)
// 	v.SetConfigType("properties")
// 	v.AddConfigPath(path)
// 	err := v.ReadInConfig() // Find and read the config file
// 	if err != nil {         // Handle errors reading the config file
// 		return output.String(), err
// 	}

// 	localFile := v.AllKeys()
// 	sort.Strings(localFile)

// 	t := table.NewWriter()
// 	t.SetOutputMirror(os.Stdout)
// 	output.WriteString("```")

// 	t.AppendHeader(table.Row{"Name", "Status", "Current", "Desired", "Normal Rep", "Event Rep"})

// 	count := 0
// 	for i := range localFile {

// 		convertInput := strings.Replace(projectSelected, ":", "@", 1)

// 		if strings.Contains(localFile[i], convertInput) {
// 			value := v.GetString(localFile[i])

// 			valueData := strings.Split(value, "|")

// 			fmt.Println(valueData)
// 			if len(valueData) != 5 {
// 				return output.String(), errors.New("somethings wrong with data " + localFile[i])
// 			}

// 			t.AppendRow([]interface{}{localFile[i], valueData[0], valueData[1], valueData[2], valueData[3], valueData[4]})
// 			count++

// 		}

// 	}

// 	output.WriteString(t.Render())
// 	output.WriteString("```")
// 	return output.String(), nil
// }

func GetDeploymentAddInputData(blockAc map[string]map[string]slack.BlockAction) error {
	input := blockAc["deployment_input"]["deployment_input"].Value

	fmt.Println(input)
	strimInput := strings.TrimSpace(input)
	strimInput = strings.ReplaceAll(input, "'", "")
	strimInput = strings.ReplaceAll(input, "\"", "")

	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return errors.New("notthing to do!!!")
	}

	godotenv.Load(".env")

	file_name := os.Getenv("DEPLOYMENT_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	// Handle errors reading the config file
	if err != nil { // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("file not exist, create an empty file")
	}

	//update hpa local file from rancher before update multi data
	// //_, _, err = GetDeploymentList("all", "all")

	// if err != nil {
	// 	return err
	// }

	for i := 0; i < len(lines); i++ {
		lines[i] = strings.TrimSpace(lines[i])
		lines[i] = strings.ReplaceAll(lines[i], "'", "")
		lines[i] = strings.ReplaceAll(lines[i], "\"", "")
		data := strings.Split(lines[i], "=")

		var key string
		var valueUpdateSplit []string
		var tempDeployment Deployment
		if len(data) != 2 {
			secondInputType := strings.Split(lines[i], "|")

			// fmt.Println("length: ", len(secondInputType))
			// fmt.Printf("%+v", secondInputType)
			if len(secondInputType) == 9 {
				key = secondInputType[1] + "@" + secondInputType[2] + "@" + secondInputType[3] + "@" + secondInputType[4]
				tempDeployment.ClusterName = secondInputType[1]
				tempDeployment.ProjectName = secondInputType[2]
				tempDeployment.NamespaceId = secondInputType[3]
				tempDeployment.Name = secondInputType[4]
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[5])
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[6])
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[7])
			} else {
				return errors.New("Data input not right " + lines[i])
			}
		} else {
			key = strings.SplitAfterN(strings.ReplaceAll(data[0], "|", "@"), "@", 2)[1]

			tempDeployment, err = getDeploymentFromKeyAndValue(key, "enableForBot|1|1|1|1")

			if err != nil {
				return err
			}
			valueUpdateSplit = strings.Split(data[1], "|")
		}
		//get current value's key
		currentValue := v.GetString(key)

		if currentValue != "" {
			return errors.New("deployment key exist, please check again, deployment invalid is: " + key)

		}

		if len(valueUpdateSplit) != 3 {
			return errors.New("This value not correct: " + data[1])
		}

		fmt.Printf("%+v\n", tempDeployment)

		clusterID, err := getClusterIdWithClusterName(tempDeployment.ClusterName)

		project, err := getProjectWithClusterID(tempDeployment.ProjectName, clusterID)

		if err != nil {
			return err
		}

		if len(project.Data) == 0 || project.Data == nil {
			//retry with project name upper case
			project, err = getProjectWithClusterID(strings.Title(tempDeployment.ProjectName), clusterID)

			if err != nil {
				return err
			}
		}

		if len(project.Data) != 1 {
			return errors.New("unable to get project " + tempDeployment.ProjectName)
		}

		//log.Println("cur deployment", tempDeployment)
		queryDeployment, err := getDeploymentWithProjectId(project.Data[0].ID, tempDeployment.Name, tempDeployment.NamespaceId)

		if err != nil {
			return err
		}

		// if len(queryDeployment.Deployment) != 1 {
		// 	return errors.New("deployment not found")
		// }

		if len(queryDeployment.Deployment) != 1 {
			return errors.New("deployment " + tempDeployment.Name + " not found")
		}

		//fmt.Println(enableHpaForBot)

		currentReplica := queryDeployment.Deployment[0].DeploymentStatus.ReadyReplicas

		desiredReplica := queryDeployment.Deployment[0].DeploymentStatus.Replicas

		index := 0
		enableForBot := valueUpdateSplit[index]
		if enableForBot != "enable" {
			if enableForBot != "disable" {
				return errors.New("This value not correct: " + enableForBot + " in " + key)
			}
		}
		index++
		normalReplica := valueUpdateSplit[index]
		index++
		eventReplica := valueUpdateSplit[index]
		index++

		norRepInt, err := strconv.Atoi(normalReplica)

		if err != nil {
			return errors.New("This value not correct: " + normalReplica + " key " + key)
		}

		eventRep, err := strconv.Atoi(eventReplica)

		if err != nil {
			return errors.New("This value not correct: " + eventReplica + " value " + key)
		}

		if norRepInt < 0 || eventRep < 0 || norRepInt > 980 || eventRep > 980 {
			return errors.New("Min Rep and Max Rep cannot less than 0 or greater than 980 pods")
		}

		value := enableForBot + "|" + strconv.Itoa(currentReplica) + "|" + strconv.Itoa(desiredReplica) + "|" + normalReplica + "|" + eventReplica

		v.Set(key, value)

	}

	//write to file
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	return nil

}

func GetDeploymentEditInputData(blockAc map[string]map[string]slack.BlockAction) error {
	input := blockAc["deployment_input"]["deployment_input"].Value

	fmt.Println(input)
	strimInput := strings.TrimSpace(input)
	strimInput = strings.ReplaceAll(input, "'", "")
	strimInput = strings.ReplaceAll(input, "\"", "")

	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return errors.New("Notthing to do!!!")
	}

	godotenv.Load(".env")

	file_name := os.Getenv("DEPLOYMENT_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}

	//update hpa local file from rancher before update multi data
	// //_, _, err = GetDeploymentList("all", "all")

	// if err != nil {
	// 	return err
	// }

	for i := 0; i < len(lines); i++ {
		lines[i] = strings.TrimSpace(input)
		lines[i] = strings.ReplaceAll(lines[i], "'", "")
		lines[i] = strings.ReplaceAll(lines[i], "\"", "")

		data := strings.Split(lines[i], "=")

		var key string
		var valueUpdateSplit []string
		var tempDeployment Deployment
		if len(data) != 2 {
			secondInputType := strings.Split(lines[i], "|")

			// fmt.Println("length: ", len(secondInputType))
			// fmt.Printf("%+v", secondInputType)
			if len(secondInputType) == 9 {
				key = secondInputType[1] + "@" + secondInputType[2] + "@" + secondInputType[3] + "@" + secondInputType[4]
				tempDeployment.ClusterName = secondInputType[1]
				tempDeployment.ProjectName = secondInputType[2]
				tempDeployment.NamespaceId = secondInputType[3]
				tempDeployment.Name = secondInputType[4]
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[5])
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[6])
				valueUpdateSplit = append(valueUpdateSplit, secondInputType[7])
			} else {
				return errors.New("Data input not right " + lines[i])
			}
		} else {
			key = strings.SplitAfterN(strings.ReplaceAll(data[0], "|", "@"), "@", 2)[1]

			tempDeployment, err = getDeploymentFromKeyAndValue(key, "enableForBot|1|1|1|1")

			if err != nil {
				return err
			}
			valueUpdateSplit = strings.Split(data[1], "|")
		}

		currentValueInterface := v.GetString(key)
		currentValue := fmt.Sprintf("%v", currentValueInterface)

		if currentValue == "" {
			return errors.New("deployment key not exist, please check again, deployment invalid is: " + key)

		}

		valueLocalSplit := strings.Split(currentValue, "|")

		if len(valueUpdateSplit) != 3 {
			return errors.New("This value not correct: " + key)
		}

		index := 0

		enableForBot := valueUpdateSplit[index]

		if enableForBot != "enable" {
			if enableForBot != "disable" {

				return errors.New("This value not correct: " + enableForBot + " in key " + key)
			}
		}
		//fmt.Println(enableHpaForBot)
		index++
		currentReplica := valueLocalSplit[index]
		index++
		desiredReplica := valueLocalSplit[index]
		index++

		index = 1
		normalReplica := valueUpdateSplit[index]
		index++
		eventReplica := valueUpdateSplit[index]
		index++

		norRepInt, err := strconv.Atoi(normalReplica)

		if err != nil {
			return errors.New("This value not correct: " + normalReplica + " key " + key)
		}

		eventRep, err := strconv.Atoi(eventReplica)

		if err != nil {
			return errors.New("This value not correct: " + eventReplica + " key " + key)
		}

		if norRepInt < 1 || eventRep < 1 || norRepInt > 990 || eventRep > 990 {
			return errors.New("Replicas cannot smaller than 1 or greater than 990 :aaa:")
		}

		value := enableForBot + "|" + currentReplica + "|" + desiredReplica + "|" + normalReplica + "|" + eventReplica

		v.Set(key, value)

	}

	//write to file
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	return nil

}

// func GetDeploymentListBlock() (slack.MsgOption, error) {

// 	msg, err := getDeploymentListBlock()
// 	return msg, err
// }

func GetDeploymentFindBlock() (slack.MsgOption, error) {

	msg, err := getDeploymentFindBlock()
	return msg, err
}

func GetDeploymentEditBlock() (slack.MsgOption, error) {

	msg, err := getDeploymentEditBlock()
	return msg, err
}

func GetDeploymentAddBlock() (slack.MsgOption, error) {

	msg, err := getDeploymentAddBlock()
	return msg, err
}

func GetDeploymentList(deployOption string, scaleType string) (string, string, error) {
	var outputTextBlock strings.Builder
	var outputDeployment strings.Builder
	//var attachmentFields []slack.AttachmentField

	godotenv.Load(".env")
	//get all local key

	path := os.Getenv("DEPLOYMENT_PATH")
	file_name := os.Getenv("DEPLOYMENT_FILE_NAME")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig()
	// Find and read the config file
	if err != nil { // Handle errors reading the config file
		os.Create(path + file_name)
		return "", "", errors.New("File not exist, create an empty file")
	}
	keys := v.AllKeys()

	//sort alphabet
	sort.Strings(keys)

	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	outputTextBlock.WriteString("```")
	if scaleType == "all" {
		t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "State", "Current", "Desired", "Normal Rep", "Event Rep"})
	} else if scaleType == "event" {
		t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "Current", "Desired", "Event Rep"})

	} else if scaleType == "normal" {
		t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "Current", "Desired", "Normal Rep"})
	}
	count := 0

	//get cluster and project for check and query local file to rancher
	clusters, err := getClusters()

	if err != nil {
		return "", "", err
	}
	projects, err := getProjects()

	if err != nil {
		return "", "", err
	}

	projects = enrichProjects(clusters, projects)

	for _, key := range keys {
		value := v.GetString(key)
		var curDeployment Deployment
		curDeployment, err := getDeploymentFromKeyAndValue(key, value)
		//update deployment value from rancher
		curDeployment, valueUpdated, err := updateDeploymentValueFromRancher(curDeployment, clusters, projects)

		if err != nil {
			return "", "", err
		}

		//set value updated to local file
		v.Set(key, valueUpdated)

		if deployOption == "active" {
			if strings.Contains(value, "enable") {
				if scaleType == "all" {
					t.AppendRow([]interface{}{curDeployment.ClusterName, curDeployment.ProjectName, curDeployment.NamespaceId, curDeployment.Name,
						curDeployment.State, curDeployment.DeploymentStatus.ReadyReplicas, curDeployment.DeploymentStatus.Replicas, curDeployment.NormalReplicas, curDeployment.EventReplicas})
				} else if scaleType == "event" {
					t.AppendRow([]interface{}{curDeployment.ClusterName, curDeployment.ProjectName, curDeployment.NamespaceId, curDeployment.Name,
						curDeployment.DeploymentStatus.ReadyReplicas, curDeployment.DeploymentStatus.Replicas, curDeployment.EventReplicas})
					outputDeployment.WriteString(key + "=" + strconv.Itoa(curDeployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(curDeployment.DeploymentStatus.Replicas) + "|" + strconv.Itoa(curDeployment.EventReplicas))
					outputDeployment.WriteString("\n")
				} else if scaleType == "normal" {
					t.AppendRow([]interface{}{curDeployment.ClusterName, curDeployment.ProjectName, curDeployment.NamespaceId, curDeployment.Name,
						curDeployment.DeploymentStatus.ReadyReplicas, curDeployment.DeploymentStatus.Replicas, curDeployment.NormalReplicas})
					outputDeployment.WriteString(key + "=" + strconv.Itoa(curDeployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(curDeployment.DeploymentStatus.Replicas) + "|" + strconv.Itoa(curDeployment.NormalReplicas))
					outputDeployment.WriteString("\n")
				}
				count++
			}
		} else if deployOption == "all" {
			t.AppendRow([]interface{}{curDeployment.ClusterName, curDeployment.ProjectName, curDeployment.NamespaceId, curDeployment.Name,
				curDeployment.EnableForBot, curDeployment.DeploymentStatus.ReadyReplicas, curDeployment.DeploymentStatus.Replicas, curDeployment.NormalReplicas, curDeployment.EventReplicas})
			outputDeployment.WriteString(key + "=" + value)
			outputDeployment.WriteString("\n")
			count++
		}

		//becase slack tear text into segments when line > 35, so need to separate if ans too long
		if count == 29 {
			outputTextBlock.WriteString(t.Render())
			outputTextBlock.WriteString("```\n```")
			// if i/29 > 1 {
			// 	output.WriteString("\n")
			// }
			t = table.NewWriter()

			if scaleType == "all" {
				t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "Status", "Current", "Desired", "Normal Rep", "Event Rep"})
			} else if scaleType == "event" {
				t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "Current", "Desired", "Event Rep"})

			} else if scaleType == "normal" {
				t.AppendHeader(table.Row{"Cluster", "Project", "Namespace", "Deployment", "Current", "Desired", "Normal Rep"})
			}
			count = 1
		}

	}

	outputTextBlock.WriteString(t.Render())
	outputTextBlock.WriteString("\n```")
	//msg.Color = "#00cc00"

	//write to file value updated
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)

	return outputTextBlock.String(), outputDeployment.String(), nil

}

func updateDeploymentValueFromRancher(curDeployment Deployment, clusters RancherClusters, projects RancherProjects) (Deployment, string, error) {
	var deployment Deployment
	var clusterName string
	var projectName string

	for _, cluster := range clusters.Data {

		if cluster.Name == curDeployment.ClusterName {
			clusterName = cluster.Name
			deployment.ClusterName = clusterName
			break
		}
	}

	if clusterName == "" {
		return deployment, "", errors.New("Cluster " + curDeployment.ClusterName + " not found")
	}

	log.Println("Current Cluter Name", clusterName, curDeployment)
	for _, project := range projects.Data {

		if strings.Title(project.Name) == strings.Title(curDeployment.ProjectName) && project.ClusterName == curDeployment.ClusterName {
			//log.Println("ProjectID", project)
			projectName = project.Name
			deployment.ProjectID = project.ID
			break
		}
	}

	if projectName == "" {
		return deployment, "", errors.New("Project " + curDeployment.ProjectName + " not found")
	}
	//log.Println("Deployment local ", curDeployment)
	//log.Println("Deployment get", deployment)
	deployments, err := getDeploymentWithProjectId(deployment.ProjectID, curDeployment.Name, curDeployment.NamespaceId)

	//log.Println("Deployment get", deployments)
	if err != nil {
		return deployment, "", err
	}

	if len(deployments.Deployment) != 1 {
		return deployment, "", errors.New("Deployment " + curDeployment.Name + " not found")
	}

	// if len(deployments.Deployment) != 1 {
	// 	return deployment, "", errors.New("deployment not found")
	// }

	deployment = deployments.Deployment[0]
	deployment.ProjectName = projectName
	deployment.ClusterName = clusterName
	deployment.EnableForBot = curDeployment.EnableForBot
	deployment.NormalReplicas = curDeployment.NormalReplicas
	deployment.EventReplicas = curDeployment.EventReplicas
	updatedValue := curDeployment.EnableForBot + "|" + strconv.Itoa(deployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(deployment.DeploymentStatus.Replicas) + "|" + strconv.Itoa(curDeployment.NormalReplicas) + "|" + strconv.Itoa(curDeployment.EventReplicas)
	return deployment, updatedValue, nil
}

func getDeploymentFromKeyAndValue(key string, value string) (Deployment, error) {

	index := 0
	var deployment Deployment
	var err error

	keySplit := strings.Split(key, "@")

	//current format is cluster@project@namespaceID@deployment
	if len(keySplit) != 4 {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}

	deployment.ClusterName = keySplit[index]
	index++
	deployment.ProjectName = keySplit[index]
	index++
	deployment.NamespaceId = keySplit[index]
	index++
	deployment.Name = keySplit[index]
	index++

	valueSplit := strings.Split(value, "|")

	//current format is enable|replica|desired|nor Rep|event Rep

	if len(valueSplit) != 5 {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}

	//reset index for value
	index = 0
	deployment.EnableForBot = valueSplit[index]
	index++
	deployment.DeploymentStatus.ReadyReplicas, err = strconv.Atoi(valueSplit[index])
	if err != nil {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}
	index++
	deployment.DeploymentStatus.Replicas, err = strconv.Atoi(valueSplit[index])
	if err != nil {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}
	index++
	deployment.NormalReplicas, err = strconv.Atoi(valueSplit[index])
	if err != nil {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}
	index++
	deployment.EventReplicas, err = strconv.Atoi(valueSplit[index])
	if err != nil {
		return deployment, errors.New("something wrong with data " + key + " value " + value)
	}

	return deployment, nil
}

func updateDeploymentLocalFile(deployments []RancherDeployment, hpaKeys []string) error {

	godotenv.Load(".env")

	file_name := os.Getenv("DEPLOYMENT_FILE_NAME")
	path := os.Getenv("DEPLOYMENT_PATH")

	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig()
	// Find and read the config file
	if err != nil { // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}
	//loop to check deployList is Exist on deployLocal file, if exist => update value, if not, create default value

	for i := range deployments {
		if len(deployments[i].Deployment) > 0 {
			for j := range deployments[i].Deployment {

				//updateInfo(hpaList[i].Data[j])
				//because properties separate by character `:` => need to replace by another
				//hpaName := strings.Replace(hpaList[i].Data[j].ID, ":", "@", 1)

				//only get active hpa
				// if hpaList[i].Data[j].State == "active" {

				deploymentNameSplit := strings.SplitAfterN(deployments[i].Deployment[j].ID, ":", 2)

				deploymentName := fmt.Sprintf("%v", strings.Replace(deploymentNameSplit[1], ":", "@", 1))

				deploymentName = deployments[i].Deployment[j].ClusterName + "@" + deployments[i].Deployment[j].ProjectName + "@" + deploymentName

				//ignore argocd and hpa
				if common.Contains(hpaKeys, deploymentName) || strings.Contains(deploymentName, "argocd") || strings.Contains(deploymentName, "cicd") {

					//fmt.Println("found hpa or not track data")
					continue
				}

				deploymentLocalValue := v.Get(deploymentName)

				key, value, err := initDeploymentDataKeyAndValue(deployments[i].Deployment[j], deploymentLocalValue)

				//ignore key-value that not appear on deployment local file

				//fmt.Println(value)

				if err != nil {
					return err
				}

				if value == "" {
					continue
				}

				v.Set(key, value)

				// }
			}
		}
	}

	//write to file
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil

}

func initDeploymentDataKeyAndValue(deployment Deployment, localValue interface{}) (string, string, error) {
	returnvalue := ""

	deploymentNameSplit := strings.SplitAfterN(deployment.ID, ":", 2)
	key := fmt.Sprintf("%v", strings.Replace(deploymentNameSplit[1], ":", "@", 1))

	key = deployment.ClusterName + "@" + deployment.ProjectName + "@" + key
	//fmt.Println(deployment)

	if localValue != nil {

		value := fmt.Sprintf("%v", localValue)

		//fmt.Println(value)

		valueLocalSplit := strings.Split(value, "|")

		if len(valueLocalSplit) != 5 {
			return "", "", errors.New("error line " + key + " value " + value)
		}

		//validate local value
		if valueLocalSplit[0] != "enable" {
			if valueLocalSplit[0] != "disable" {
				valueLocalSplit[0] = "disable"
			}
		}
		if valueLocalSplit[0] == "enable" {
			norRep, err := strconv.Atoi(valueLocalSplit[3])

			if err != nil {
				return key, value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[3])
			}

			eventRep, err := strconv.Atoi(valueLocalSplit[4])

			if err != nil {
				return key, value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[4])
			}

			if norRep < 1 || eventRep < 1 {
				return key, value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[3] + " " + valueLocalSplit[4])
			}
		}

		returnvalue = valueLocalSplit[0] + "|" + strconv.Itoa(deployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(deployment.DeploymentStatus.Replicas) + "|" + valueLocalSplit[3] + "|" + valueLocalSplit[4]
	}

	//currently
	// else {

	// 	//
	// 	fmt.Println("new key assign ")
	// 	// returnvalue ""
	// 	returnvalue = "disable" + "|" + strconv.Itoa(deployment.DeploymentStatus.ReadyReplicas) + "|" + strconv.Itoa(deployment.DeploymentStatus.Replicas) + "|1|1"

	// }

	return key, returnvalue, nil
}
