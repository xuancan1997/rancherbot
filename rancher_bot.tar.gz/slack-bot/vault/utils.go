package vault

import (
	"errors"
	"log"
	"os"
	"slack-bot/common"
	"slack-bot/rancher"

	"github.com/joho/godotenv"
)

func createNewKeyDBVault(cluster, namespaceID, keydbName string) error {

	secretVaultName := keydbName
	vaultDataInput := make(map[string]string)

	//gen pwd random
	minSpecialChar := 0
	minNum := 1
	minUpperCase := 3
	passwordLength := 12
	password := common.GeneratePassword(passwordLength, minSpecialChar, minNum, minUpperCase)
	vaultDataInput["REDIS_PASSWORD"] = password
	vaultDataInput["REDIS_CONNECTION_URL"] = "redis://:" + password + "@" + keydbName + ":6379"

	data := rancher.Data{
		ClusterName: cluster,
		NamespaceId: namespaceID,
	}

	//err := checkVaultClusterPath(cluster, namespaceID)

	// if err != nil {
	// 	return err
	// }
	_, _, err := createVault(vaultDataInput, data, secretVaultName)

	if err != nil {
		return err
	}

	return nil
}

func checkVaultClusterPath(cluster, namespaceID string) error {
	mountPoint := "/v1/kv/data/k8s/" + cluster + "/" + namespaceID
	authVaultAddr := os.Getenv("AUTH_VAULT_ADDR")
	authVaultPath := os.Getenv("AUTH_VAULT_PATH")
	authVaultRole := os.Getenv("AUTH_VAULT_ROLE")

	v, err := ClientK8sLogin(authVaultAddr, authVaultPath, authVaultRole)

	isFalse := false
	if err != nil {
		isFalse = true
		log.Println(err)
	}

	token := ""
	//for test from local
	if isFalse {
		godotenv.Load(".env")
		token = os.Getenv("VAULT_TOKEN")
	} else {
		token = v.Token()
	}

	//log.Println("Current token: ", token)

	if token == "" {
		return errors.New("cannot get vault token")
	}

	//testing
	//mountPointSec = "/v1/rancher-bot/data/foo"

	_, _, err = querryToVault(token, mountPoint)

	if err != nil {
		return err
	}
	return nil
}
