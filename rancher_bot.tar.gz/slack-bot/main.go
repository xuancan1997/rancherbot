package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"slack-bot/db"
	"slack-bot/lib"
	"slack-bot/rancher"
	"strings"

	"github.com/joho/godotenv"
	"github.com/robfig/cron/v3"
	"github.com/slack-go/slack"
	"github.com/slack-go/slack/slackevents"
	"github.com/slack-go/slack/socketmode"
)

func main() {

	//get slack api & client

	client, api, err := lib.ConnectToSlackViaSocketMode()

	if err != nil {

		fmt.Printf("Could not connect to Slack!!!")
		os.Exit(1)

	}

	//run command from args trigger
	go executeArgsCmd()

	// Create a context that can be used to cancel goroutine
	ctx, cancel := context.WithCancel(context.Background())

	// Make this cancel called properly in a real program , graceful shutdown etc
	defer cancel()

	go func(ctx context.Context, client *slack.Client, socketClient *socketmode.Client) {

		//update normal scale if updated
		go updateNormalScaleData(client)
		//run scale optimize cronjob
		go executeScaleDownCronJob(client)
		//run scale normal cronjob
		go executeScaleNormalCronJob(client)
		//run scale optimize cronjob 2
		go executeScaleDownCronJob2(client)

		//reset user self redeploy
		go resetUserSelfRedeploy(client)

		//run daily check cost
		go dailyCheckCostGCP(client)
		//run remind sys event
		err = rancher.HandleRemindSysAboutReplicas(client)

		if err != nil {
			os.Exit(1)
		}
		// Create a for loop that selects either the context cancellation or the events incomming
		for {
			select {
			// inscase context cancel is called exit the goroutine
			case <-ctx.Done():
				log.Println("Shutting down socketmode listener")
				return
			case event := <-socketClient.Events:
				// We have a new Events, let's type switch the event
				// Add more use cases here if you want to listen to other events.
				switch event.Type {

				// handle EventAPI events
				case socketmode.EventTypeEventsAPI:
					// The Event sent on the channel is not the same as the EventAPI events so we need to type cast it
					eventsAPIEvent, ok := event.Data.(slackevents.EventsAPIEvent)
					if !ok {
						log.Printf("Could not type cast the event to the EventsAPIEvent: %v\n", event)
						continue
					}

					// We need to send an Acknowledge to the slack server
					socketClient.Ack(*event.Request)
					// Now we have an Events API event, but this event type can in turn be many types, so we actually need another type switch
					//log.Println(eventsAPIEvent)

					fmt.Println("Go eventypeEventAPi now")
					lib.HandleEventMessage(eventsAPIEvent, client)

				case socketmode.EventTypeInteractive:

					log.Println("Go to interraction")

					interaction, ok := event.Data.(slack.InteractionCallback)

					if !ok {
						log.Printf("Could not type cast the message to a Interaction callback: %v\n", interaction)
						continue
					}

					err := lib.HandleInteractionEvent(interaction, client)
					if err != nil {
						log.Fatal(err)
					}
					socketClient.Ack(*event.Request)

				default:
					//log.Println("go to here")
				}

			}

		}
	}(ctx, api, client)

	client.Run()

}

func updateNormalScaleData(client *slack.Client) {
	c := cron.New()
	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	_, err := c.AddFunc("0 22 * * *", func() {
		msg, err := rancher.UpdateScaleNormalData()

		if err != nil {
			sendError(err, client)
			c.Stop()
		} else {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionAttachments(msg))
		}

		log.Println("run updated normal scale data okay")
	})

	if err != nil {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()
}

func executeArgsCmd() {
	argsWithoutProg := os.Args[1:]

	log.Println(argsWithoutProg)

	//do somethings when trigger go with args
	if len(argsWithoutProg) > 0 {

		command := argsWithoutProg[0]

		if command == "scale" {
			err := rancher.HandleScaleArgs(argsWithoutProg)

			if err != nil {
				log.Println(err)
			}
		}

	}

}

func resetUserSelfRedeploy(client *slack.Client) {
	c := cron.New()
	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	cronJobOptimize := os.Getenv("USER_DEPLOY_RESET_HOUR")
	_, err := c.AddFunc(cronJobOptimize, func() {
		err := rancher.ResetUserSelfRedeploy()

		if err != nil {

			sendError(err, client)
			c.Stop()
		} else {

			//update local file
			//log.Println("Update local file")
			err = rancher.HandleDeploymentUpdateLocalFile()

			if err != nil {
				log.Println(err)
			}

			// err = rancher.HandleDeploymentUpdateLocalFile()
			// if err != nil {
			// 	log.Println(err)
			// }

			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Cronjob has been reset user redeploy time`", false))
		}

		log.Println("reset user redeploy time success")
	})

	if err != nil {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()
}

func dailyCheckCostGCP(client *slack.Client) {
	c := cron.New()

	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")

	_, err := c.AddFunc("30 15 * * *", func() {
		err := db.DisplayCostCheckDaily(client)

		if err != nil {

			sendError(err, client)
			c.Stop()
		} else {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Daily check cost has already ran today`", false))
		}

		log.Println("Run daily check cost okay")
	})

	if err != nil {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()

}

func executeScaleNormalCronJob(client *slack.Client) {
	c := cron.New()

	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	cronJobOptimize := os.Getenv("TIME_RUN_SCALE_NORMAL")
	_, err := c.AddFunc(cronJobOptimize, func() {
		err := rancher.ScaleDownCronJob(client, "normal")

		if err != nil {

			sendError(err, client)
			c.Stop()
		} else {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Cronjob has already ran Scale Normal today`", false))
		}

		log.Println("Scale optimize cost success")
	})

	if err != nil {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()

}

func executeScaleDownCronJob(client *slack.Client) {
	c := cron.New()

	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	cronJobOptimize := os.Getenv("TIME_RUN_SCALE_OPTIMIZE")
	_, err := c.AddFunc(cronJobOptimize, func() {
		err := rancher.ScaleDownCronJob(client, "reduce cost")

		if err != nil {
			sendError(err, client)
			c.Stop()
		} else {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Cronjob has already ran Optimize cost for today`", false))
		}
		log.Println("Scale optimize cost success")
	})

	if err != nil {
		log.Println(err)
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()

}

func executeScaleDownCronJob2(client *slack.Client) {
	c := cron.New()

	godotenv.Load(".env")
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	cronJobOptimize := os.Getenv("TIME_RUN_SCALE_OPTIMIZE_2")
	_, err := c.AddFunc(cronJobOptimize, func() {
		err := rancher.ScaleDownCronJob(client, "reduce cost 2")

		if err != nil {
			sendError(err, client)
			c.Stop()
		} else {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Cronjob has already ran Optimize cost for today`", false))
		}
		log.Println("Scale optimize cost success")
	})

	if err != nil {
		log.Println(err)
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("Cronjob has error: "+err.Error(), false))
		c.Stop()
	}
	c.Start()

}

func sendError(err error, client *slack.Client) {
	log.Println(err)
	CHANNEL_ID := os.Getenv("CHANNEL_ID")
	PIC_USER := os.Getenv("PIC_USER")

	users := strings.Split(PIC_USER, ",")

	if len(users) == 0 {
		client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`Cannot get users to send warnings`", false))
	}

	log.Println("user pic ", users)
	userMsg := ""
	for i := range users {
		tmpUser, err := client.GetUserByEmail(strings.TrimSpace(users[i]))

		if err != nil {
			client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`"+err.Error()+"`", false))
		}

		userMsg += "<@" + tmpUser.ID + "> "
	}
	client.PostMessage(CHANNEL_ID, slack.MsgOptionText("`"+err.Error()+" "+userMsg+" for scale optimizing, please check`", false))
}
