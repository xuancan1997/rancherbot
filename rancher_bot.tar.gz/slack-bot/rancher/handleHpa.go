package rancher

import (
	"errors"
	"fmt"
	"log"
	"os"
	"slack-bot/sheet"
	"sort"
	"strconv"
	"strings"

	"github.com/jedib0t/go-pretty/table"
	"github.com/joho/godotenv"
	"github.com/slack-go/slack"
	"github.com/spf13/viper"
)

func GetGoogleSheetData() {
	sheet, err := sheet.GetGoogleSheetData()

	if err != nil {
		log.Println(err)
	}

	var hpaKeys []string
	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err = v.ReadInConfig() // Find and read the config file// Find and read the config file
	if err != nil {
		log.Println(err)

	}

	hpaKeys = v.AllKeys()

	count := 1
	//countCol := 0
	var output []string
	for _, key := range hpaKeys {

		value := v.GetString(key)
		keySplit := strings.Split(key, "@")
		output = append(output, keySplit...)
		valueSplit := strings.Split(value, "|")
		output = append(output, valueSplit...)

		for i := 0; i < count; i++ {
			sheet.Update(count, i, output[i])
		}
		count++
	}

}

func getAllHpaKey() ([]string, error) {

	var hpaKeys []string
	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file// Find and read the config file
	if err != nil {
		os.Create(path + file_name)
		return hpaKeys, errors.New("File not exist, create an empty file") // Handle errors reading the config file
	}

	hpaKeys = v.AllKeys()

	return hpaKeys, nil
}

func GetHpaMultiEditInputData(blockAc map[string]map[string]slack.BlockAction) error {
	input := blockAc["input"]["input"].Value

	//fmt.Println(input)
	strimInput := strings.ReplaceAll(input, " ", "")
	strimInput = strings.ReplaceAll(input, "'", "")
	strimInput = strings.ReplaceAll(input, "\"", "")

	lines := strings.Split(strimInput, "\n")

	if len(lines) == 1 && lines[0] == "" {
		return errors.New("Notthing to do!!!")
	}
	//Println(strimInput)

	godotenv.Load(".env")

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file// Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}

	//update hpa local file from rancher before update multi data
	_, _, err = GetHpaList("all", "all")

	if err != nil {
		return err
	}

	for i := 0; i < len(lines); i++ {
		lines[i] = strings.ReplaceAll(lines[i], " ", "")
		lines[i] = strings.ReplaceAll(lines[i], "'", "")
		lines[i] = strings.ReplaceAll(lines[i], "\"", "")
		data := strings.Split(lines[i], "=")

		var key string
		var value string
		if len(data) == 2 {
			key = data[0]
			value = data[1]
		} else {
			secondTypeEditInput := strings.Split(lines[i], "|")

			if len(secondTypeEditInput) != 11 {
				return errors.New("Data length is not connect, please check again!!!")
			}

			key = secondTypeEditInput[1] + "@" + secondTypeEditInput[2] + "@" + secondTypeEditInput[3] + "@" + secondTypeEditInput[4]

			value = secondTypeEditInput[5] + "|" + secondTypeEditInput[6] + "|" + secondTypeEditInput[7] + "|" + secondTypeEditInput[8] + "|" + secondTypeEditInput[9]
		}

		if value == "" {
			return errors.New("hpa key not exist, please check again, hpa invalid is: " + key)

		}

		hpaData, err := getHpaDataFromKeyAndValue(key, v.GetString(key))

		if err != nil {
			return err
		}

		valueSplit := strings.Split(value, "|")
		if len(valueSplit) != 5 {
			return errors.New("This key value not correct: " + key)
		}

		status := hpaData.State

		index := 0
		enableHpaForBot := valueSplit[0]
		index++

		if enableHpaForBot != "enable" {
			if enableHpaForBot != "disable" {
				return errors.New("This value not correct: " + data[1] + " in " + enableHpaForBot)
			}
		}
		//fmt.Println(enableHpaForBot)

		currentReplica := hpaData.CurrentReplicas

		desiredReplica := hpaData.DesiredReplicas

		curMinRep := hpaData.MinReplicas

		curMaxRep := hpaData.MaxReplicas

		norMinRep := valueSplit[index]
		index++
		norMaxRep := valueSplit[index]
		index++
		eventMinHpa := valueSplit[index]
		index++
		eventMaxHpa := valueSplit[index]
		index++

		norMinRepInt, err := strconv.Atoi(norMinRep)

		if err != nil {
			return errors.New("This value not correct: " + norMinRep + " value " + data[1])
		}

		norMaxRepInt, err := strconv.Atoi(norMaxRep)

		if err != nil {
			return errors.New("This value not correct: " + norMaxRep + " value " + data[1])
		}

		eventMaxRepInt, err := strconv.Atoi(eventMaxHpa)

		if err != nil {
			return errors.New("This value not correct: " + eventMaxHpa + " value " + data[1])
		}

		eventMinRepInt, err := strconv.Atoi(eventMinHpa)

		if err != nil {
			return errors.New("This value not correct: " + eventMinHpa + " value " + data[1])
		}

		if eventMinRepInt > eventMaxRepInt || norMinRepInt > norMaxRepInt {
			return errors.New("hpaMin cannot greater than hpaMax :aaa:")
		}

		valueWrite := status + "|" + enableHpaForBot + "|" + strconv.Itoa(currentReplica) + "|" + strconv.Itoa(desiredReplica) + "|" + strconv.Itoa(curMinRep) + "|" + strconv.Itoa(curMaxRep) + "|" + norMinRep + "|" + norMaxRep + "|" + eventMinHpa + "|" + eventMaxHpa

		v.Set(key, valueWrite)

	}

	//write to file
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil

}
func GetHpaMultiEditBlock() (slack.MsgOption, error) {

	msg, err := getHpaMultiEditBlock()
	return msg, err
}

func SendHPADataToRancher(hpaData string) error {
	var statusCode int
	hpaDataInput := strings.Split(hpaData, " ")

	for i := range hpaDataInput {

		// if hpaDataInput[i] == "" {
		// 	continue
		// }
		hpaData, err := getHpaConfirmedValue(hpaDataInput[i])

		if err != nil {
			return err
		}

		if hpaData.ProjectName == "" {
			return errors.New("cannot get projectName")
		}

		if hpaData.ClusterName == "" {
			return errors.New("cannot get clusterName")
		}

		clusterID, err := getClusterIdWithClusterName(hpaData.ClusterName)
		if err != nil {
			return err
		}

		projects, err := getProjectWithClusterID(hpaData.ProjectName, clusterID)

		if err != nil {
			return err
		}

		if len(projects.Data) == 0 || projects.Data == nil {
			//retry with project name upper case
			projects, err = getProjectWithClusterID(strings.Title(hpaData.ProjectName), clusterID)

			if err != nil {
				return err
			}

			if len(projects.Data) == 0 || projects.Data == nil {
				return errors.New("project not found: " + hpaData.ProjectName)
			}
		}

		hpaData.ProjectID = projects.Data[0].ID

		statusCode = updateHpaDataCommand(hpaData)

		if statusCode != 200 {
			return errors.New("error when send hpa update request to rancher")
		}
	}

	return nil
}

func getHpaConfirmedValue(input string) (Data, error) {
	var hpaData Data
	var err error
	splitInput := strings.Split(input, "=")

	if input == "" {
		return hpaData, errors.New("nothing to do!!!")
	}
	//convert @-> : and no need cluster name, so need to remove it

	keyData := strings.Split(splitInput[0], "@")

	hpaData.ClusterName = keyData[0]
	hpaData.ProjectName = keyData[1]
	hpaData.ID = keyData[2] + ":" + keyData[3]

	//example checkout@merchant-portal-app=1|1|1|1
	value := strings.Split(splitInput[1], "|")

	if len(value) != 4 || hpaData.ID == "" {
		return hpaData, errors.New("somethings wrong with data input")
	}

	hpaData.MinReplicas, err = strconv.Atoi(value[0])

	if err != nil {
		return hpaData, errors.New("somethings wrong with data input")
	}

	hpaData.MaxReplicas, err = strconv.Atoi(value[1])
	if err != nil {
		return hpaData, errors.New("somethings wrong with data input")
	}
	hpaData.TempMinReplicas, err = strconv.Atoi(value[2])
	if err != nil {
		return hpaData, errors.New("somethings wrong with data input")
	}
	hpaData.TempMaxReplicas, err = strconv.Atoi(value[3])
	if err != nil {
		return hpaData, errors.New("somethings wrong with data input")
	}

	return hpaData, nil
}

func GetHpaScale(scaleType string) ([]string, string, error) {

	msgHpaTextResponse, hpaDataResponse, err := GetHpaList("active", scaleType)

	if err != nil {
		return nil, hpaDataResponse, err
	}

	//msg := slack.MsgOptionText(msgResponse, true)

	if err != nil {
		return msgHpaTextResponse, hpaDataResponse, err
	}

	return msgHpaTextResponse, hpaDataResponse, nil

}

func GetHpaEditData(blockAc map[string]map[string]slack.BlockAction) error {

	var hpaData Data
	var err error

	hpaData.ClusterName = blockAc["hpa_edit_choose"]["hpa_edit_cluster_choose"].SelectedOption.Value

	hpaData.ProjectName = blockAc["hpa_edit_choose"]["hpa_edit_project_choose"].SelectedOption.Value

	hpaData.ID = blockAc["hpa_edit_choose"]["hpa_edit_deployment_choose"].SelectedOption.Value

	//fmt.Println(interraction.BlockActionState)

	hpaData.Enabled = blockAc["rep_options"]["enable_bot_hpa"].SelectedOption.Value

	hpaData.NormalMinReplicas, err = strconv.Atoi(blockAc["rep2_options"]["min_nor_rep"].SelectedOption.Value)

	if err != nil {
		return err
	}
	hpaData.NormalMaxReplicas, err = strconv.Atoi(blockAc["rep2_options"]["max_nor_rep"].SelectedOption.Value)
	if err != nil {
		return err
	}
	hpaData.EventMinReplicas, err = strconv.Atoi(blockAc["rep2_options"]["min_event_rep"].SelectedOption.Value)
	if err != nil {
		return err
	}
	hpaData.EventMaxReplicas, err = strconv.Atoi(blockAc["rep2_options"]["max_event_rep"].SelectedOption.Value)
	if err != nil {
		return err
	}

	if hpaData.NormalMinReplicas == 0 || hpaData.NormalMaxReplicas == 0 || hpaData.EventMinReplicas == 0 || hpaData.EventMaxReplicas == 0 {
		return errors.New("Replica cannot be zero, please check again!!!")
	}

	if hpaData.NormalMinReplicas > hpaData.NormalMaxReplicas || hpaData.EventMinReplicas > hpaData.EventMaxReplicas {
		return errors.New("Min replica cannot smaller than max replica, please check again!!!")
	}

	err = updateLocalHpaDataWithName(hpaData)

	if err != nil {
		return err
	}
	return nil
}

func updateLocalHpaDataWithName(hpaData Data) error {

	//var attachmentFields []slack.AttachmentField
	godotenv.Load(".env")

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}

	hpaData.ID = strings.ReplaceAll(hpaData.ID, ":", "@")

	key := hpaData.ClusterName + "@" + hpaData.ProjectName + "@" + hpaData.ID
	currentHpaValue := v.GetString(key)

	curHpaData, err := getHpaValue(currentHpaValue)

	if err != nil {
		return err
	}

	newValue := curHpaData.State + "|" + hpaData.Enabled + "|" + strconv.Itoa(curHpaData.CurrentReplicas) + "|" + strconv.Itoa(curHpaData.DesiredReplicas) + "|" +
		strconv.Itoa(curHpaData.MinReplicas) + "|" + strconv.Itoa(curHpaData.MaxReplicas) + "|" +
		strconv.Itoa(hpaData.NormalMinReplicas) + "|" + strconv.Itoa(hpaData.NormalMaxReplicas) + "|" +
		strconv.Itoa(hpaData.EventMinReplicas) + "|" + strconv.Itoa(hpaData.EventMaxReplicas)

	//fmt.Println("hpa Data write :", hpaData.ID)
	v.Set(key, newValue)

	//newConfig := viper.AllSettings()
	//fmt.Printf("All settings #2 %+v\n\n", newConfig)

	err = v.WriteConfig()
	if err != nil {
		return errors.New("somethings wrong when write to local hpa config file")
	}

	return nil
}

func GetHpaInputData(interraction slack.InteractionCallback) (slack.MsgOption, error) {

	input := interraction.BlockActionState.Values["hpa_options"]["hpa_options"].SelectedOption.Value

	//fmt.Println("Hpa option:", input)

	msg, err := CreateHpaResponseBlock(input)

	if err != nil {
		return msg, nil
	}
	return msg, nil
}

func getHpaValue(input string) (Data, error) {
	var data Data
	var err error
	splitInput := strings.Split(input, "|")

	fmt.Println(splitInput)

	if len(splitInput) != 10 {
		return data, errors.New("something wrong with data")
	}

	index := 0
	data.State = splitInput[index]
	index++
	data.Enabled = splitInput[index]
	index++

	if data.Enabled != "enable" {
		if data.Enabled != "disable" {
			return data, errors.New("This value not correct: " + input + " in " + data.Enabled)
		}
	}
	data.CurrentReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.DesiredReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.MinReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.MaxReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.NormalMinReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.NormalMaxReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.EventMinReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}
	data.EventMaxReplicas, err = strconv.Atoi(splitInput[index])
	index++
	if err != nil {
		return data, err
	}

	return data, nil
}
func GetHpaList(hpaOption string, scaleType string) ([]string, string, error) {
	var msg []string
	var hpaList []RancherHpas
	var outputTextBlock strings.Builder
	var outputHpa strings.Builder
	//var attachmentFields []slack.AttachmentField
	godotenv.Load(".env")

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")

	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return msg, "", errors.New("File not exist, create an empty file")
	}

	clusters, err := getClusters()

	if err != nil {
		return msg, "", err
	}
	projects, err := getProjects()

	log.Println(projects)
	if err != nil {
		return msg, "", err
	}

	projects = enrichProjects(clusters, projects)
	//get all Hpa from projects
	for i := range projects.Data {

		if projects.Data[i].Name == "Istio" {
			continue
		}
		hpa, err := getHpaWithProjectId(projects.Data[i].ID, "")

		//fmt.Println(projects.Data[i].ID + projects.Data[i].Name)
		if err != nil {
			return msg, "", err
		}

		//update clustername for projects
		for j := range hpa.Data {
			hpa.Data[j].ClusterName = projects.Data[i].ClusterName
			hpa.Data[j].ProjectName = projects.Data[i].Name
		}

		hpaList = append(hpaList, hpa)
	}

	//fmt.Println(hpaList)

	//update local file
	err = updateHpaLocalFile(hpaList)

	if err != nil {
		return msg, "", err
	}

	//get all local key
	keys := v.AllKeys()

	//sort alphabet
	sort.Strings(keys)
	t := table.NewWriter()
	t.SetOutputMirror(os.Stdout)
	outputTextBlock.WriteString("```")
	if scaleType == "all" {
		t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Cur", "Min", "Max", "NMin", "NMax", "EMin", "EMax"})
	} else if scaleType == "event" {
		t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Current", "Current Min", "Current Max", "Event Min", "Event Max"})

	} else if scaleType == "normal" {
		t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Current", "Current Min", "Current Max", "Normal Min", "Normal Max"})
	}
	count := 0
	for _, key := range keys {

		value := v.GetString(key)

		tempHpa, err := getHpaDataFromKeyAndValue(key, value)

		if err != nil {
			return msg, "", err
		}
		//only active and hpa state is active could manual hpa
		if hpaOption == "active" && tempHpa.State == "active" {
			if strings.Contains(value, "enable") {
				if scaleType == "all" {

					t.AppendRow([]interface{}{tempHpa.ClusterName, tempHpa.ProjectName, tempHpa.ID, tempHpa.State,
						tempHpa.CurrentReplicas, tempHpa.MinReplicas, tempHpa.MaxReplicas, tempHpa.NormalMinReplicas, tempHpa.NormalMaxReplicas,
						tempHpa.EventMinReplicas, tempHpa.EventMaxReplicas})
				} else if scaleType == "event" {
					t.AppendRow([]interface{}{tempHpa.ClusterName, tempHpa.ProjectName, tempHpa.ID, tempHpa.State,
						tempHpa.CurrentReplicas, tempHpa.MinReplicas, tempHpa.MaxReplicas, tempHpa.EventMinReplicas, tempHpa.EventMaxReplicas})

					outputHpa.WriteString(key + "=" + strconv.Itoa(tempHpa.MinReplicas) + "|" + strconv.Itoa(tempHpa.MaxReplicas) + "|" + strconv.Itoa(tempHpa.EventMinReplicas) + "|" + strconv.Itoa(tempHpa.EventMaxReplicas))
					outputHpa.WriteString("\n")
				} else if scaleType == "normal" {
					t.AppendRow([]interface{}{tempHpa.ClusterName, tempHpa.ProjectName, tempHpa.ID, tempHpa.State,
						tempHpa.CurrentReplicas, tempHpa.MinReplicas, tempHpa.MaxReplicas, tempHpa.NormalMinReplicas, tempHpa.NormalMaxReplicas})
					outputHpa.WriteString(key + "=" + strconv.Itoa(tempHpa.MinReplicas) + "|" + strconv.Itoa(tempHpa.MaxReplicas) + "|" + strconv.Itoa(tempHpa.NormalMinReplicas) + "|" + strconv.Itoa(tempHpa.NormalMaxReplicas))

					outputHpa.WriteString("\n")
				}
				count++
			}
		} else if hpaOption == "all" {

			// if len(tempHpa.ID) > 35 {
			// 	tempData := common.SplitSubN(tempHpa.ID)
			// 	tempHpa.ID = tempData[0] + "..." + tempData[1]
			// }

			t.AppendRow([]interface{}{tempHpa.ClusterName, tempHpa.ProjectName, tempHpa.ID, tempHpa.State,
				tempHpa.Enabled, tempHpa.CurrentReplicas, tempHpa.MinReplicas, tempHpa.MaxReplicas, tempHpa.NormalMinReplicas, tempHpa.NormalMaxReplicas,
				tempHpa.EventMinReplicas, tempHpa.EventMaxReplicas})
			outputHpa.WriteString(key + "=" + value)
			outputHpa.WriteString("\n")
			count++
		}

		//becase slack tear text into segments when line > 35, so need to separate if ans too long
		if count == 24 {
			outputTextBlock.WriteString(t.Render())
			outputTextBlock.WriteString("```")

			msg = append(msg, outputTextBlock.String())
			outputTextBlock.Reset()
			outputTextBlock.WriteString("```")
			// if i/29 > 1 {
			// 	output.WriteString("\n")
			// }
			t = table.NewWriter()

			if scaleType == "all" {
				t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Stt", "Cur", "Min", "Max", "NMin", "NMax", "EMin", "EMax"})
			} else if scaleType == "event" {
				t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Current", "Current Min", "Current Max", "Event Min", "Event Max"})

			} else if scaleType == "normal" {
				t.AppendHeader(table.Row{"Cluster", "Project", "HPA ID", "State", "Current", "Current Min", "Current Max", "Normal Min", "Normal Max"})
			}
			count = 0
		}

	}
	outputTextBlock.WriteString(t.Render())
	outputTextBlock.WriteString("```")
	msg = append(msg, outputTextBlock.String())
	//msg.Color = "#00cc00"

	return msg, outputHpa.String(), nil

}

func getHpaDataFromKeyAndValue(key string, value string) (Data, error) {
	var hpaData Data

	var err error

	keySplit := strings.Split(key, "@")

	//fmt.Println(keySplit)
	if len(keySplit) != 4 {
		return hpaData, errors.New("key format is not correct")
	}

	hpaData.ClusterName = keySplit[0]
	hpaData.ProjectName = keySplit[1]
	hpaData.ID = keySplit[2] + "@" + keySplit[3]

	valueSplit := strings.Split(value, "|")

	if len(valueSplit) != 10 {
		return hpaData, errors.New("something wrong with data key " + key)
	}
	index := 0

	hpaData.State = valueSplit[index]
	index++
	hpaData.Enabled = valueSplit[index]
	//fmt.Println(enableHpaForBot)
	index++
	hpaData.CurrentReplicas, err = strconv.Atoi(valueSplit[index])

	if err != nil {
		return hpaData, err
	}

	index++
	hpaData.DesiredReplicas, err = strconv.Atoi(valueSplit[index])

	if err != nil {
		return hpaData, err
	}
	index++
	hpaData.MinReplicas, err = strconv.Atoi(valueSplit[index])
	index++
	hpaData.MaxReplicas, err = strconv.Atoi(valueSplit[index])
	index++
	hpaData.NormalMinReplicas, err = strconv.Atoi(valueSplit[index])
	index++
	hpaData.NormalMaxReplicas, err = strconv.Atoi(valueSplit[index])
	index++
	hpaData.EventMinReplicas, err = strconv.Atoi(valueSplit[index])
	index++
	hpaData.EventMaxReplicas, err = strconv.Atoi(valueSplit[index])
	index++

	return hpaData, nil
}

func updateHpaLocalFile(hpaList []RancherHpas) error {

	godotenv.Load(".env")

	file_name := os.Getenv("HPA_FILE_NAME")
	path := os.Getenv("HPA_PATH")
	v := viper.New()
	v.SetConfigName(file_name)
	v.SetConfigType("properties")
	v.AddConfigPath(path)
	err := v.ReadInConfig() // Find and read the config file// Find and read the config file
	if err != nil {         // Handle errors reading the config file
		os.Create(path + file_name)
		return errors.New("File not exist, create an empty file")
	}

	var key string
	var value string
	//loop to check hpaList is Exist on hpaLocal file, if exist => update value, if not, create default value
	for i := range hpaList {
		if len(hpaList[i].Data) > 0 {
			for j := range hpaList[i].Data {
				//updateInfo(hpaList[i].Data[j])
				//because properties separate by character `:` => need to replace by another
				//hpaName := strings.Replace(hpaList[i].Data[j].ID, ":", "@", 1)

				//only get active hpa
				// if hpaList[i].Data[j].State == "active" {

				if hpaList[i].Data[j].ClusterName == "" || hpaList[i].Data[j].ProjectName == "" || hpaList[i].Data[j].ID == "" {
					return errors.New("somethings wrong with data " + hpaList[i].Data[j].ClusterName + hpaList[i].Data[j].ProjectName + hpaList[i].Data[j].ID)
				}
				key = hpaList[i].Data[j].ClusterName + "@" + hpaList[i].Data[j].ProjectName + "@" + strings.ReplaceAll(hpaList[i].Data[j].ID, ":", "@")

				value = v.GetString(key)

				value, err := initHpaDataKeyAndValue(hpaList[i].Data[j], key, value)
				if err != nil {
					return err
				}
				v.Set(key, value)
				// }
			}
		}
	}

	//write to file
	v.WriteConfig()
	//if file not exist, not write
	v.WriteConfigAs(path + file_name)
	return nil

}

func initHpaDataKeyAndValue(hpaData HpaData, key string, localValue string) (string, error) {

	var value string

	if localValue != "" {
		valueLocalSplit := strings.Split(localValue, "|")

		if len(valueLocalSplit) == 10 {

			//fmt.Println(valueLocalSplit)
			//validate local value
			if valueLocalSplit[1] != "enable" {
				if valueLocalSplit[1] != "disable" {
					valueLocalSplit[1] = "disable"
				}
			}
			if valueLocalSplit[1] == "enable" {
				norMinRep, err := strconv.Atoi(valueLocalSplit[6])

				if err != nil {
					return value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[5])
				}

				norMaxRep, err := strconv.Atoi(valueLocalSplit[7])

				if err != nil {
					return value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[6])
				}
				eventMinRep, err := strconv.Atoi(valueLocalSplit[8])
				if err != nil {
					return value, errors.New("error while init data localfile with data " + key + " value " + valueLocalSplit[7])
				}

				eventMaxRep, err := strconv.Atoi(valueLocalSplit[9])

				if err != nil {
					return value, errors.New("error while init data localfile with data " + key)
				}

				if norMinRep > norMaxRep {
					return value, errors.New("error while init data localfile with data " + key)
				}

				if eventMinRep > eventMaxRep {
					return value, errors.New("error while init data localfile with data " + key)
				}
			}

			value = hpaData.State + "|" + valueLocalSplit[1] + "|" + strconv.Itoa(hpaData.CurrentReplicas) + "|" + strconv.Itoa(hpaData.DesiredReplicas) + "|" + strconv.Itoa(hpaData.MinReplicas) + "|" + strconv.Itoa(hpaData.MaxReplicas) + "|" + valueLocalSplit[6] + "|" + valueLocalSplit[7] + "|" + valueLocalSplit[8] + "|" + valueLocalSplit[9]

		} else {
			return value, errors.New("error while split value hpa data " + key)
		}
	} else {
		value = hpaData.State + "|" + "disable" + "|" + strconv.Itoa(hpaData.CurrentReplicas) + "|" + strconv.Itoa(hpaData.DesiredReplicas) + "|" + strconv.Itoa(hpaData.MinReplicas) + "|" + strconv.Itoa(hpaData.MaxReplicas) + "|" + strconv.Itoa(hpaData.MinReplicas) + "|" + strconv.Itoa(hpaData.MaxReplicas) + "|" + strconv.Itoa(hpaData.MinReplicas) + "|" + strconv.Itoa(hpaData.MaxReplicas)

	}

	return value, nil
}
